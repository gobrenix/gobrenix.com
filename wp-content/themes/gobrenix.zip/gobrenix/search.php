<?php
/**
* The page for displaying search results
 *
 * @package gobrenix
 */
get_header(); ?>
<h1>Page</h1>
<?php get_footer(); ?>
