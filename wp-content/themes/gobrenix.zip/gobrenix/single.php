<?php
/**
* The page for displaying search results
 *
 * @package gobrenix
 */
get_header(); ?>
<h1>The template for displaying all single posts.</h1>
<?php get_footer(); ?>
