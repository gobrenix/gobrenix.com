<?php
    /**
    * Helper functions for use in other areas of the theme
    */
    require get_template_directory() . 'lib/theme-helper.php';

    /**
    * Filter Yoast SEO Metabox Priority
    */
    add_filter('wpseo_metabox_prio', 'gx_filter_yoast_seo_metabox');
    function gx_filter_yoast_seo_metabox() {
	   return 'low';
    }
