<?php
/**
 *
 * The template for displaying the front page.
 *
 * This is the template that displays on the front page only.
 *
 * @package gobrenix
 */
get_header(); ?>
<h1>Frontpage</h1>
<?php get_footer(); ?>
