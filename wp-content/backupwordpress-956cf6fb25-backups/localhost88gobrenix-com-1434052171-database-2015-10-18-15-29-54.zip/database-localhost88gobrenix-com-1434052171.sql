# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `gx_commentmeta`
#

DROP TABLE IF EXISTS `gx_commentmeta`;


#
# Table structure of table `gx_commentmeta`
#

CREATE TABLE `gx_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_commentmeta (1 records)
#
 
INSERT INTO `gx_commentmeta` VALUES (2, 2, 'akismet_history', 'a:4:{s:4:"time";d:1434062129.7948729991912841796875;s:5:"event";s:11:"check-error";s:4:"user";s:5:"admin";s:4:"meta";a:1:{s:8:"response";s:7:"invalid";}}') ;
#
# End of data contents of table gx_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------


#
# Delete any existing table `gx_comments`
#

DROP TABLE IF EXISTS `gx_comments`;


#
# Table structure of table `gx_comments`
#

CREATE TABLE `gx_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_comments (2 records)
#
 
INSERT INTO `gx_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-06-11 19:30:32', '2015-06-11 17:30:32', 'Hallo, das hier ist ein Kommentar.<br />Um Kommentare zu bearbeiten, müssen Sie sich anmelden und zur Übersicht der Beiträge gehen. Dort bekommen Sie dann die Gelegenheit sie zu verändern oder zu löschen.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `gx_comments` VALUES (2, 2, 'admin', 'gobrenix@gmail.com', '', '::1', '2015-06-12 00:35:29', '2015-06-11 22:35:29', 'Test Kommentar :)', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36', '', 0, 1) ;
#
# End of data contents of table gx_comments
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------


#
# Delete any existing table `gx_links`
#

DROP TABLE IF EXISTS `gx_links`;


#
# Table structure of table `gx_links`
#

CREATE TABLE `gx_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_links (0 records)
#

#
# End of data contents of table gx_links
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------


#
# Delete any existing table `gx_lockdowns`
#

DROP TABLE IF EXISTS `gx_lockdowns`;


#
# Table structure of table `gx_lockdowns`
#

CREATE TABLE `gx_lockdowns` (
  `lockdown_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lockdown_IP` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`lockdown_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table gx_lockdowns (0 records)
#

#
# End of data contents of table gx_lockdowns
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------


#
# Delete any existing table `gx_login_fails`
#

DROP TABLE IF EXISTS `gx_login_fails`;


#
# Table structure of table `gx_login_fails`
#

CREATE TABLE `gx_login_fails` (
  `login_attempt_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `login_attempt_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_IP` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`login_attempt_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table gx_login_fails (0 records)
#

#
# End of data contents of table gx_login_fails
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------


#
# Delete any existing table `gx_options`
#

DROP TABLE IF EXISTS `gx_options`;


#
# Table structure of table `gx_options`
#

CREATE TABLE `gx_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=408 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_options (190 records)
#
 
INSERT INTO `gx_options` VALUES (1, 'siteurl', 'http://localhost:88/gobrenix.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (2, 'home', 'http://localhost:88/gobrenix.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (3, 'blogname', 'Gobrenix Productions', 'yes') ; 
INSERT INTO `gx_options` VALUES (4, 'blogdescription', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (5, 'users_can_register', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (6, 'admin_email', 'gobrenix@gmail.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (7, 'start_of_week', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (8, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (9, 'use_smilies', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (10, 'require_name_email', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (11, 'comments_notify', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (12, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `gx_options` VALUES (13, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (14, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (15, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (16, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `gx_options` VALUES (17, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `gx_options` VALUES (18, 'default_category', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (19, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `gx_options` VALUES (20, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `gx_options` VALUES (21, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `gx_options` VALUES (23, 'date_format', 'j. F Y', 'yes') ; 
INSERT INTO `gx_options` VALUES (24, 'time_format', 'G:i', 'yes') ; 
INSERT INTO `gx_options` VALUES (25, 'links_updated_date_format', 'j. F Y G:i', 'yes') ; 
INSERT INTO `gx_options` VALUES (26, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (27, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes') ; 
INSERT INTO `gx_options` VALUES (29, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (30, 'hack_file', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (31, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `gx_options` VALUES (32, 'moderation_keys', '', 'no') ; 
INSERT INTO `gx_options` VALUES (33, 'active_plugins', 'a:12:{i:0;s:43:"admin-color-schemes/admin-color-schemes.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:4;s:43:"floating-social-bar/floating-social-bar.php";i:5;s:9:"hello.php";i:6;s:31:"list-subpages/list-subpages.php";i:7;s:32:"login-lockdown/loginlockdown.php";i:8;s:25:"sucuri-scanner/sucuri.php";i:9;s:43:"the-events-calendar/the-events-calendar.php";i:10;s:24:"wordpress-seo/wp-seo.php";i:11;s:25:"wp-members/wp-members.php";i:12;s:23:"wp-smushit/wp-smush.php";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `gx_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `gx_options` VALUES (38, 'gmt_offset', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `gx_options` VALUES (41, 'template', 'gobrenix', 'yes') ; 
INSERT INTO `gx_options` VALUES (42, 'stylesheet', 'gobrenix', 'yes') ; 
INSERT INTO `gx_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `gx_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `gx_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `gx_options` VALUES (49, 'db_version', '33055', 'yes') ; 
INSERT INTO `gx_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `gx_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `gx_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `gx_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `gx_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `gx_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `gx_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `gx_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `gx_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `gx_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `gx_options` VALUES (67, 'image_default_link_type', 'none', 'yes') ; 
INSERT INTO `gx_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `gx_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `gx_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `gx_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `gx_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `gx_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `gx_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (82, 'uninstall_plugins', 'a:1:{s:43:"floating-social-bar/floating-social-bar.php";a:2:{i:0;s:19:"floating_social_bar";i:1;s:9:"uninstall";}}', 'no') ; 
INSERT INTO `gx_options` VALUES (83, 'timezone_string', 'Europe/Zurich', 'yes') ; 
INSERT INTO `gx_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (88, 'initial_db_version', '31535', 'yes') ; 
INSERT INTO `gx_options` VALUES (89, 'gx_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:102:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;s:16:"edit_tribe_event";b:1;s:16:"read_tribe_event";b:1;s:18:"delete_tribe_event";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:24:"edit_others_tribe_events";b:1;s:26:"delete_others_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:27:"delete_private_tribe_events";b:1;s:25:"edit_private_tribe_events";b:1;s:25:"read_private_tribe_events";b:1;s:16:"edit_tribe_venue";b:1;s:16:"read_tribe_venue";b:1;s:18:"delete_tribe_venue";b:1;s:19:"delete_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:24:"edit_others_tribe_venues";b:1;s:26:"delete_others_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:27:"delete_private_tribe_venues";b:1;s:25:"edit_private_tribe_venues";b:1;s:25:"read_private_tribe_venues";b:1;s:20:"edit_tribe_organizer";b:1;s:20:"read_tribe_organizer";b:1;s:22:"delete_tribe_organizer";b:1;s:23:"delete_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;s:28:"edit_others_tribe_organizers";b:1;s:30:"delete_others_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;s:31:"delete_private_tribe_organizers";b:1;s:29:"edit_private_tribe_organizers";b:1;s:29:"read_private_tribe_organizers";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:74:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:16:"edit_tribe_event";b:1;s:16:"read_tribe_event";b:1;s:18:"delete_tribe_event";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:24:"edit_others_tribe_events";b:1;s:26:"delete_others_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:27:"delete_private_tribe_events";b:1;s:25:"edit_private_tribe_events";b:1;s:25:"read_private_tribe_events";b:1;s:16:"edit_tribe_venue";b:1;s:16:"read_tribe_venue";b:1;s:18:"delete_tribe_venue";b:1;s:19:"delete_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:24:"edit_others_tribe_venues";b:1;s:26:"delete_others_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:27:"delete_private_tribe_venues";b:1;s:25:"edit_private_tribe_venues";b:1;s:25:"read_private_tribe_venues";b:1;s:20:"edit_tribe_organizer";b:1;s:20:"read_tribe_organizer";b:1;s:22:"delete_tribe_organizer";b:1;s:23:"delete_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;s:28:"edit_others_tribe_organizers";b:1;s:30:"delete_others_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;s:31:"delete_private_tribe_organizers";b:1;s:29:"edit_private_tribe_organizers";b:1;s:29:"read_private_tribe_organizers";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:34:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:16:"edit_tribe_event";b:1;s:16:"read_tribe_event";b:1;s:18:"delete_tribe_event";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:16:"edit_tribe_venue";b:1;s:16:"read_tribe_venue";b:1;s:18:"delete_tribe_venue";b:1;s:19:"delete_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:20:"edit_tribe_organizer";b:1;s:20:"read_tribe_organizer";b:1;s:22:"delete_tribe_organizer";b:1;s:23:"delete_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:20:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:16:"edit_tribe_event";b:1;s:16:"read_tribe_event";b:1;s:18:"delete_tribe_event";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:16:"edit_tribe_venue";b:1;s:16:"read_tribe_venue";b:1;s:18:"delete_tribe_venue";b:1;s:19:"delete_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:20:"edit_tribe_organizer";b:1;s:20:"read_tribe_organizer";b:1;s:22:"delete_tribe_organizer";b:1;s:23:"delete_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:5:{s:4:"read";b:1;s:7:"level_0";b:1;s:16:"read_tribe_event";b:1;s:20:"read_tribe_organizer";b:1;s:16:"read_tribe_venue";b:1;}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (90, 'WPLANG', 'de_CH', 'yes') ; 
INSERT INTO `gx_options` VALUES (91, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (92, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (93, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (94, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (95, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (96, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (98, 'cron', 'a:8:{i:1445188500;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1445189432;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1445189458;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1445205871;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1445207729;a:1:{s:24:"akismet_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1445378400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"bac2a2be1c518053b1f7bf98ae752a19";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:10:"1434052171";}s:8:"interval";i:604800;}}}s:20:"wp_batch_split_terms";a:9:{i:1441907042;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441907043;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441907044;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441907045;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441907059;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441907063;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441907070;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441907087;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441907107;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (107, '_transient_random_seed', 'b1e10ff43b1c48ecff43482eb1a01eee', 'yes') ; 
INSERT INTO `gx_options` VALUES (127, '_transient_timeout_plugin_slugs', '1441993499', 'no') ; 
INSERT INTO `gx_options` VALUES (128, '_transient_plugin_slugs', 'a:14:{i:0;s:43:"admin-color-schemes/admin-color-schemes.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:42:"bwp-google-xml-sitemaps/bwp-simple-gxs.php";i:4;s:43:"floating-social-bar/floating-social-bar.php";i:5;s:9:"hello.php";i:6;s:31:"list-subpages/list-subpages.php";i:7;s:32:"login-lockdown/loginlockdown.php";i:8;s:25:"sucuri-scanner/sucuri.php";i:9;s:43:"the-events-calendar/the-events-calendar.php";i:10;s:33:"w3-total-cache/w3-total-cache.php";i:11;s:25:"wp-members/wp-members.php";i:12;s:23:"wp-smushit/wp-smush.php";i:13;s:24:"wordpress-seo/wp-seo.php";}', 'no') ; 
INSERT INTO `gx_options` VALUES (132, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1434043876;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (133, 'current_theme', 'Gobrenix', 'yes') ; 
INSERT INTO `gx_options` VALUES (134, 'theme_mods_gobrenix', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (135, 'theme_switched', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (136, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (137, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (139, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (140, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (144, '_transient__mbbasetheme_categories', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (147, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `gx_options` VALUES (158, 'fsb_global_option', 'a:9:{s:8:"services";a:5:{s:8:"linkedin";a:1:{s:2:"on";b:0;}s:9:"pinterest";a:1:{s:2:"on";b:0;}s:8:"facebook";a:2:{s:2:"on";b:1;s:5:"order";i:0;}s:7:"twitter";a:2:{s:2:"on";b:1;s:5:"order";i:1;}s:6:"google";a:2:{s:2:"on";b:1;s:5:"order";i:2;}}s:5:"label";s:0:"";s:7:"show_on";a:1:{i:0;s:4:"post";}s:7:"twitter";s:0:"";s:9:"transient";i:1800;s:7:"pinback";s:0:"";s:6:"static";i:0;s:8:"position";s:5:"above";s:9:"socialite";i:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (159, 'loginlockdownAdminOptions', 'a:6:{s:17:"max_login_retries";s:1:"3";s:14:"retries_within";s:1:"5";s:14:"lockout_length";s:2:"60";s:25:"lockout_invalid_usernames";s:2:"no";s:17:"mask_login_errors";s:2:"no";s:16:"show_credit_link";s:2:"no";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (160, 'loginlockdown_db_version', '1.0', 'no') ; 
INSERT INTO `gx_options` VALUES (161, 'wpseo', 'a:20:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:7:"version";s:5:"2.3.4";s:11:"alexaverify";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (162, 'wpseo_permalinks', 'a:13:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (163, 'wpseo_titles', 'a:54:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:1;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (164, 'wpseo_social', 'a:21:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"296b130d5ffbca1916a049f28a5b2c75";s:13:"facebook_site";s:33:"https://www.facebook.com/gobrenix";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:20:"Gobrenix Productions";s:17:"og_frontpage_desc";s:78:"This is Gobrenix Records, the leading Goa & Progressive label from swizterland";s:18:"og_frontpage_image";s:103:"http://localhost:88/gobrenix.com/wp-content/uploads/2015/06/10968747_852590338115812_1938437724_o-1.jpg";s:9:"opengraph";b:1;s:10:"googleplus";b:0;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (165, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (166, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:2:"»";s:23:"post_types-post-maintax";i:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (167, 'wpseo_xml', 'a:15:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (168, 'wpmembers_settings', 'a:28:{i:0;s:13:"WPMEM_VERSION";i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;s:1:"1";i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;s:7:"version";s:5:"3.0.4";s:5:"block";a:2:{s:4:"post";i:0;s:4:"page";i:0;}s:12:"show_excerpt";a:2:{s:4:"post";i:0;s:4:"page";i:0;}s:8:"show_reg";a:2:{s:4:"post";i:1;s:4:"page";i:1;}s:10:"show_login";a:2:{s:4:"post";i:1;s:4:"page";i:1;}s:6:"notify";i:0;s:7:"mod_reg";i:0;s:7:"captcha";s:1:"1";s:7:"use_exp";i:0;s:9:"use_trial";i:0;s:8:"warnings";i:0;s:10:"user_pages";a:3:{s:7:"profile";s:0:"";s:8:"register";s:0:"";s:5:"login";s:0:"";}s:6:"cssurl";b:0;s:5:"style";s:87:"http://localhost:88/gobrenix.com/wp-content/plugins/wp-members/css/generic-no-float.css";s:6:"autoex";a:2:{s:7:"auto_ex";i:0;s:11:"auto_ex_len";s:0:"";}s:6:"attrib";s:1:"0";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (169, 'wpmembers_fields', 'a:16:{i:0;a:7:{i:0;i:1;i:1;s:10:"First Name";i:2;s:10:"first_name";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:1;a:7:{i:0;i:2;i:1;s:9:"Last Name";i:2;s:9:"last_name";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:2;a:7:{i:0;i:3;i:1;s:9:"Address 1";i:2;s:5:"addr1";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:3;a:7:{i:0;i:4;i:1;s:9:"Address 2";i:2;s:5:"addr2";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"n";i:6;s:1:"n";}i:4;a:7:{i:0;i:5;i:1;s:4:"City";i:2;s:4:"city";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:5;a:7:{i:0;i:6;i:1;s:5:"State";i:2;s:8:"thestate";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:6;a:7:{i:0;i:7;i:1;s:3:"Zip";i:2;s:3:"zip";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:7;a:7:{i:0;i:8;i:1;s:7:"Country";i:2;s:7:"country";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:8;a:7:{i:0;i:9;i:1;s:9:"Day Phone";i:2;s:6:"phone1";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:9;a:7:{i:0;i:10;i:1;s:5:"Email";i:2;s:10:"user_email";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:10;a:7:{i:0;i:11;i:1;s:13:"Confirm Email";i:2;s:13:"confirm_email";i:3;s:4:"text";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:11;a:7:{i:0;i:12;i:1;s:7:"Website";i:2;s:8:"user_url";i:3;s:4:"text";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"y";}i:12;a:7:{i:0;i:13;i:1;s:17:"Biographical Info";i:2;s:11:"description";i:3;s:8:"textarea";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"y";}i:13;a:7:{i:0;i:14;i:1;s:8:"Password";i:2;s:8:"password";i:3;s:8:"password";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:14;a:7:{i:0;i:15;i:1;s:16:"Confirm Password";i:2;s:16:"confirm_password";i:3;s:8:"password";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:15;a:9:{i:0;i:16;i:1;s:3:"TOS";i:2;s:3:"tos";i:3;s:8:"checkbox";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";i:7;s:5:"agree";i:8;s:1:"n";}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (170, 'wpmembers_dialogs', 'a:9:{i:0;s:119:"This content is restricted to site members.  If you are an existing user, please log in.  New users may register below.";i:1;s:50:"Sorry, that username is taken, please try another.";i:2;s:74:"Sorry, that email address already has an account.<br />Please try another.";i:3;s:124:"Congratulations! Your registration was successful.<br /><br />You may now log in using the password that was emailed to you.";i:4;s:29:"Your information was updated!";i:5;s:53:"Passwords did not match.<br /><br />Please try again.";i:6;s:30:"Password successfully changed!";i:7;s:65:"Either the username or email address do not exist in our records.";i:8;s:135:"Password successfully reset!<br /><br />An email containing a new password has been sent to the email address on file for your account.";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (171, 'wpmembers_tos', 'Put your TOS (Terms of Service) text here.  You can use HTML markup.', 'yes') ; 
INSERT INTO `gx_options` VALUES (172, 'wpmembers_email_newreg', 'a:2:{s:4:"subj";s:37:"Your registration info for [blogname]";s:4:"body";s:268:"Thank you for registering for [blogname]

Your registration information is below.
You may wish to retain a copy for your records.

username: [username]
password: [password]

You may login here:
[reglink]

You may change your password here:
[members-area]
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (173, 'wpmembers_email_newmod', 'a:2:{s:4:"subj";s:40:"Thank you for registering for [blogname]";s:4:"body";s:173:"Thank you for registering for [blogname]. 
Your registration has been received and is pending approval.
You will receive login instructions upon approval of your account
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (174, 'wpmembers_email_appmod', 'a:2:{s:4:"subj";s:50:"Your registration for [blogname] has been approved";s:4:"body";s:299:"Your registration for [blogname] has been approved.

Your registration information is below.
You may wish to retain a copy for your records.

username: [username]
password: [password]

You may login and change your password here:
[members-area]

You originally registered at:
[reglink]
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (175, 'wpmembers_email_repass', 'a:2:{s:4:"subj";s:34:"Your password reset for [blogname]";s:4:"body";s:157:"Your password for [blogname] has been reset

Your new password is included below. You may wish to retain a copy for your records.

password: [password]
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (176, 'wpmembers_email_notify', 'a:2:{s:4:"subj";s:36:"New user registration for [blogname]";s:4:"body";s:196:"The following user registered for [blogname]:
	
username: [username]
email: [email]

[fields]
This user registered here:
[reglink]

user IP: [user-ip]
	
activate user: [activate-user]
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (177, 'wpmembers_email_footer', '----------------------------------
This is an automated message from [blogname]
Please do not reply to this address', 'no') ; 
INSERT INTO `gx_options` VALUES (178, 'wpmembers_style', 'http://localhost:88/gobrenix.com/wp-content/plugins/wp-members/css/generic-no-float.css', 'yes') ; 
INSERT INTO `gx_options` VALUES (180, 'sucuriscan_datastore_path', '/Applications/MAMP/htdocs/gobrenix.com/wp-content/uploads/sucuri', 'yes') ; 
INSERT INTO `gx_options` VALUES (183, '_transient_yoast_i18n_wordpress-seo_promo_hide', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (188, 'sucuriscan_emails_sent', '2', 'yes') ; 
INSERT INTO `gx_options` VALUES (189, 'sucuriscan_last_email_at', '1441907135', 'yes') ; 
INSERT INTO `gx_options` VALUES (203, 'wpmembers_attrib', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (204, 'wpmembers_msurl', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (205, 'wpmembers_regurl', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (206, 'wpmembers_logurl', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (207, 'wpmembers_autoex', 'a:2:{s:7:"auto_ex";i:0;s:11:"auto_ex_len";s:0:"";}', 'no') ; 
INSERT INTO `gx_options` VALUES (215, 'hmbkp_schedule_1434052171', 'a:5:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";d:1434492000;s:11:"max_backups";i:7;s:5:"email";a:1:{s:5:"email";s:18:"gobrenix@gmail.com";}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (217, 'hmbkp_plugin_version', '3.2.7', 'yes') ; 
INSERT INTO `gx_options` VALUES (228, 'hmbkp_notices', 'a:1:{s:13:"backup_errors";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (229, 'hmbkp_schedule_1434052240', 'a:7:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:8:"manually";s:5:"email";a:1:{s:5:"email";s:18:"gobrenix@gmail.com";}s:11:"max_backups";i:2;s:8:"excludes";a:85:{i:0;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:1;s:5:".git/";i:2;s:5:".svn/";i:3;s:9:".DS_Store";i:4;s:6:".idea/";i:5;s:10:"backwpup-*";i:6;s:7:"updraft";i:7;s:12:"wp-snapshots";i:8;s:19:"backupbuddy_backups";i:9;s:14:"pb_backupbuddy";i:10;s:9:"backup-db";i:11;s:14:"Envato-backups";i:12;s:8:"managewp";i:13;s:25:"backupwordpress-*-backups";i:14;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:15;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:16;s:5:".git/";i:17;s:5:".svn/";i:18;s:9:".DS_Store";i:19;s:6:".idea/";i:20;s:10:"backwpup-*";i:21;s:7:"updraft";i:22;s:12:"wp-snapshots";i:23;s:19:"backupbuddy_backups";i:24;s:14:"pb_backupbuddy";i:25;s:9:"backup-db";i:26;s:14:"Envato-backups";i:27;s:8:"managewp";i:28;s:25:"backupwordpress-*-backups";i:29;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:30;s:59:"/Applications/MAMP/htdocs/gobrenix.com/wp-config-sample.php";i:31;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:32;s:5:".git/";i:33;s:5:".svn/";i:34;s:9:".DS_Store";i:35;s:6:".idea/";i:36;s:10:"backwpup-*";i:37;s:7:"updraft";i:38;s:12:"wp-snapshots";i:39;s:19:"backupbuddy_backups";i:40;s:14:"pb_backupbuddy";i:41;s:9:"backup-db";i:42;s:14:"Envato-backups";i:43;s:8:"managewp";i:44;s:25:"backupwordpress-*-backups";i:45;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:46;s:59:"/Applications/MAMP/htdocs/gobrenix.com/wp-config-sample.php";i:47;s:52:"/Applications/MAMP/htdocs/gobrenix.com/liesmich.html";i:48;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:49;s:5:".git/";i:50;s:5:".svn/";i:51;s:9:".DS_Store";i:52;s:6:".idea/";i:53;s:10:"backwpup-*";i:54;s:7:"updraft";i:55;s:12:"wp-snapshots";i:56;s:19:"backupbuddy_backups";i:57;s:14:"pb_backupbuddy";i:58;s:9:"backup-db";i:59;s:14:"Envato-backups";i:60;s:8:"managewp";i:61;s:25:"backupwordpress-*-backups";i:62;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:63;s:59:"/Applications/MAMP/htdocs/gobrenix.com/wp-config-sample.php";i:64;s:52:"/Applications/MAMP/htdocs/gobrenix.com/liesmich.html";i:65;s:50:"/Applications/MAMP/htdocs/gobrenix.com/readme.html";i:66;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:67;s:5:".git/";i:68;s:5:".svn/";i:69;s:9:".DS_Store";i:70;s:6:".idea/";i:71;s:10:"backwpup-*";i:72;s:7:"updraft";i:73;s:12:"wp-snapshots";i:74;s:19:"backupbuddy_backups";i:75;s:14:"pb_backupbuddy";i:76;s:9:"backup-db";i:77;s:14:"Envato-backups";i:78;s:8:"managewp";i:79;s:25:"backupwordpress-*-backups";i:80;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:81;s:59:"/Applications/MAMP/htdocs/gobrenix.com/wp-config-sample.php";i:82;s:52:"/Applications/MAMP/htdocs/gobrenix.com/liesmich.html";i:83;s:50:"/Applications/MAMP/htdocs/gobrenix.com/readme.html";i:84;s:48:"/Applications/MAMP/htdocs/gobrenix.com/README.md";}s:14:"duration_total";i:1;s:16:"backup_run_count";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (239, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (246, 'widget_akismet_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (247, 'widget_widget_wpmemwidget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (263, 'tribe_events_calendar_options', 'a:33:{s:27:"recurring_events_are_hidden";s:6:"hidden";s:19:"tribeEventsTemplate";s:20:"templates/events.php";s:21:"tribeEventsBeforeHTML";s:0:"";s:20:"tribeEventsAfterHTML";s:0:"";s:21:"previous_ecp_versions";a:2:{i:0;s:1:"0";i:1;s:5:"3.9.3";}s:18:"latest_ecp_version";s:6:"3.12.1";s:10:"viewOption";s:4:"list";s:11:"donate-link";b:0;s:12:"postsPerPage";s:1:"5";s:17:"liveFiltersUpdate";b:1;s:12:"showComments";b:0;s:20:"showEventsInMainLoop";b:0;s:10:"eventsSlug";s:6:"events";s:15:"singleEventSlug";s:5:"event";s:14:"multiDayCutoff";s:5:"00:00";s:21:"defaultCurrencySymbol";s:3:"CHF";s:23:"reverseCurrencyPosition";b:1;s:15:"embedGoogleMaps";b:1;s:19:"embedGoogleMapsZoom";s:2:"15";s:11:"debugEvents";b:0;s:16:"stylesheetOption";s:5:"tribe";s:16:"tribeEnableViews";a:3:{i:0;s:4:"list";i:1;s:5:"month";i:2;s:3:"day";}s:20:"tribeDisableTribeBar";b:0;s:16:"monthEventAmount";s:1:"3";s:18:"dateWithYearFormat";s:6:"j. F Y";s:21:"dateWithoutYearFormat";s:3:"F j";s:18:"monthAndYearFormat";s:3:"F Y";s:17:"dateTimeSeparator";s:3:" @ ";s:18:"timeRangeSeparator";s:3:" - ";s:16:"datepickerFormat";s:1:"4";s:13:"earliest_date";s:19:"2015-06-20 17:00:00";s:11:"latest_date";s:19:"2015-09-10 17:00:00";s:14:"schema-version";s:6:"3.12.1";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (264, 'tribe_events_db_version', '3.0.0', 'yes') ; 
INSERT INTO `gx_options` VALUES (266, 'tribe_events_suite_versions', 'a:1:{s:19:"TribeEventsCalendar";s:5:"3.9.3";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (269, 'tribe_last_save_post', '1445174994', 'yes') ; 
INSERT INTO `gx_options` VALUES (276, 'tribe_events_cat_children', 'a:2:{i:3;a:3:{i:0;i:4;i:1;i:5;i:2;i:6;}i:7;a:1:{i:0;i:8;}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (314, 'bwp_gxs_generator', 'a:1:{s:15:"input_cache_dir";s:0:"";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (315, 'bwp_gxs_version', '1.3.1', 'yes') ; 
INSERT INTO `gx_options` VALUES (316, 'bwp_gxs_log', 'a:2:{s:3:"log";a:0:{}s:7:"sitemap";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (328, 'dismiss_smush_upgrade', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (329, 'sucuriscan_ads_visibility', 'disabled', 'yes') ; 
INSERT INTO `gx_options` VALUES (351, '_transient_timeout_online_users', '1441908068', 'no') ; 
INSERT INTO `gx_options` VALUES (352, '_transient_online_users', 'a:1:{i:0;a:6:{s:7:"user_id";i:1;s:10:"user_login";s:5:"admin";s:10:"user_email";s:18:"gobrenix@gmail.com";s:15:"user_registered";s:19:"2015-06-11 17:30:32";s:13:"last_activity";d:1441913468;s:11:"remote_addr";s:9:"127.0.0.1";}}', 'no') ; 
INSERT INTO `gx_options` VALUES (353, '_site_transient_timeout_browser_241c2ec76c9f201b86d5b16dc40c8a72', '1442511070', 'yes') ; 
INSERT INTO `gx_options` VALUES (354, '_site_transient_browser_241c2ec76c9f201b86d5b16dc40c8a72', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"45.0.2454.85";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (355, '_transient_timeout_feed_9d60b69c1d2c0d4e76c5c4146b9dba24', '1441949471', 'no') ; 
INSERT INTO `gx_options` VALUES (356, '_transient_feed_9d60b69c1d2c0d4e76c5c4146b9dba24', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:19:"
	
	
	
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Modern Tribe Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:13:"http://tri.be";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress event plugins for people who kick ass";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2015 18:10:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:27:"http://wordpress.org/?v=4.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:5:"image";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:3:"url";a:1:{i:0;a:5:{s:4:"data";s:68:"http://tri.be/wp-content/themes/moderntribe/images/branding/logo.png";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:37:"http://tri.be/category/products/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 10 Sep 2015 17:31:11 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";a:2:{i:0;s:15:"Accept-Encoding";i:1;s:6:"Cookie";}s:13:"cache-control";s:29:"max-age=3353, must-revalidate";s:12:"x-powered-by";s:21:"PHP/5.3.23-1~dotdeb.0";s:10:"x-pingback";s:24:"http://tri.be/xmlrpc.php";s:13:"last-modified";s:29:"Wed, 29 Jul 2015 18:10:37 GMT";s:4:"etag";s:34:""1c48a92d4d1e60caa6583389e44f250d"";s:16:"content-encoding";s:4:"gzip";}s:5:"build";s:14:"20150611172108";}', 'no') ; 
INSERT INTO `gx_options` VALUES (357, '_transient_timeout_feed_mod_9d60b69c1d2c0d4e76c5c4146b9dba24', '1441949471', 'no') ; 
INSERT INTO `gx_options` VALUES (358, '_transient_feed_mod_9d60b69c1d2c0d4e76c5c4146b9dba24', '1441906271', 'no') ; 
INSERT INTO `gx_options` VALUES (359, '_transient_timeout_feed_2c2fe0099a2578688413800ea68677d6', '1441949471', 'no') ; 
INSERT INTO `gx_options` VALUES (360, '_transient_feed_2c2fe0099a2578688413800ea68677d6', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"ButlerBlog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://www.butlerblog.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:20:"chad butler\'s weblog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 12 Jun 2015 16:00:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=4.2.4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"5 Articles to Help You Manage WordPress Better";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/-HQU00er-qs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.butlerblog.com/2015/06/11/articles-to-help-you-manage-wordpress-better/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Jun 2015 15:59:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:11:"development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3436";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1776:"Here are some posts that I have done on the site to help you manage WordPress better.   Maybe you&#8217;re a writer or designer, and not a developer. Then you are in luck! These posts are to help the...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=-HQU00er-qs:sLeSOeyZpBU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=-HQU00er-qs:sLeSOeyZpBU:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=-HQU00er-qs:sLeSOeyZpBU:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/-HQU00er-qs" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.butlerblog.com/2015/06/11/articles-to-help-you-manage-wordpress-better/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:82:"http://www.butlerblog.com/2015/06/11/articles-to-help-you-manage-wordpress-better/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Don’t Let This Mistake Kill Your Business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/AFPMDwe6Lv8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.butlerblog.com/2015/06/04/dont-let-this-mistake-kill-your-business/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Jun 2015 14:00:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:4:"fear";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"freelance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:12:"productivity";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3370";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1770:"It&#8217;s called &#8220;Perfectionism&#8221; and it effects many new writers, developers, and freelancers. At some point, it effects almost everyone who attempts to launch their business online...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=AFPMDwe6Lv8:pK0kUdPxMmA:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=AFPMDwe6Lv8:pK0kUdPxMmA:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=AFPMDwe6Lv8:pK0kUdPxMmA:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/AFPMDwe6Lv8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.butlerblog.com/2015/06/04/dont-let-this-mistake-kill-your-business/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.butlerblog.com/2015/06/04/dont-let-this-mistake-kill-your-business/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Is your site ready for mobilegeddon?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/mgXl7Q4PrM8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:82:"http://www.butlerblog.com/2015/04/20/is-your-site-ready-for-mobilegeddon/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Apr 2015 03:34:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"Web";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3393";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1771:"Is your site currently mobile friendly?  How fast does it load on mobile devices? Dubbed &#8220;Mobilegeddon,&#8221; Google will be making changes to its search algorithm on Tuesday to take into...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=mgXl7Q4PrM8:77HxzmE4DWw:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=mgXl7Q4PrM8:77HxzmE4DWw:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=mgXl7Q4PrM8:77HxzmE4DWw:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/mgXl7Q4PrM8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.butlerblog.com/2015/04/20/is-your-site-ready-for-mobilegeddon/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:73:"http://www.butlerblog.com/2015/04/20/is-your-site-ready-for-mobilegeddon/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:69:"
		
		
		
		
		
				
		
		
		
		
		
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"Personal Brand Building with Your Own URL Shortener";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/ISeEKBHBNSU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:92:"http://www.butlerblog.com/2015/02/05/personal-brand-building-your-own-url-shortener/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Feb 2015 14:00:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:12:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:14:"Brand Building";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:11:"Brand Image";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"branding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:17:"Personal Branding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:14:"Shortened Urls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:9;a:5:{s:4:"data";s:5:"tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:10;a:5:{s:4:"data";s:6:"webdev";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:11;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3297";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1775:"You may have noticed that last year I started the process of reinforcing my personal brand image, placing a larger importance on personal branding.  This included a web site makeover, a new logo for...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=ISeEKBHBNSU:dx5Efy0GcqQ:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=ISeEKBHBNSU:dx5Efy0GcqQ:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=ISeEKBHBNSU:dx5Efy0GcqQ:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/ISeEKBHBNSU" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:89:"http://www.butlerblog.com/2015/02/05/personal-brand-building-your-own-url-shortener/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:84:"http://www.butlerblog.com/2015/02/05/personal-brand-building-your-own-url-shortener/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Schedule Your Day to Improve Productivity in 3 Easy Steps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/M8lGPovanBo/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.butlerblog.com/2015/02/03/schedule-your-day-to-improve-productivity-in-3-easy-steps/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Feb 2015 13:00:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:11:"development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"freelance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3239";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1775:"I once wrote a post about the importance of avoiding distractions as a freelancer. It began with a little story about burning a pot of coffee and related that to how distractions can yield a similar...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=M8lGPovanBo:aXSUkrdH0YQ:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=M8lGPovanBo:aXSUkrdH0YQ:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=M8lGPovanBo:aXSUkrdH0YQ:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/M8lGPovanBo" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:100:"http://www.butlerblog.com/2015/02/03/schedule-your-day-to-improve-productivity-in-3-easy-steps/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:95:"http://www.butlerblog.com/2015/02/03/schedule-your-day-to-improve-productivity-in-3-easy-steps/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"5 Top Bloggers Teach You How to Drive Traffic to Your Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/LKX4GwZQzyE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:105:"http://www.butlerblog.com/2015/02/02/5-top-bloggers-teach-you-how-to-drive-traffic-to-your-blog/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Feb 2015 18:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3131";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1772:"These 5 top bloggers command top dollar for their advice and expertise. Here is an opportunity for you to get some of their best advice on how to get more blog traffic. And you don&#8217;t have to...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=LKX4GwZQzyE:mtZt7OT42PU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=LKX4GwZQzyE:mtZt7OT42PU:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=LKX4GwZQzyE:mtZt7OT42PU:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/LKX4GwZQzyE" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:101:"http://www.butlerblog.com/2015/02/02/5-top-bloggers-teach-you-how-to-drive-traffic-to-your-blog/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:96:"http://www.butlerblog.com/2015/02/02/5-top-bloggers-teach-you-how-to-drive-traffic-to-your-blog/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:63:"
		
		
		
		
		
				
		
		
		
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"Building Successful Membership Sites: What You Need To Know";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/Kxe5VDIbYxg/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:86:"http://www.butlerblog.com/2015/01/30/how-to-build-successful-membership-sites/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Jan 2015 15:54:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:10:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:14:"Building Trust";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"Business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:17:"Business Modeling";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:16:"membership-sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:8:"monetize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:15:"Premium Content";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:9;a:5:{s:4:"data";s:16:"Web Entrepreneur";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://www.butlerblog.com/?page_id=3302";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1774:"Many web entrepreneurs and freelancers would argue that the membership site is the ultimate business model. As someone who has utilized this concept for coming close to two decades, I would agree. I...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=Kxe5VDIbYxg:fzdF2-4qX-w:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=Kxe5VDIbYxg:fzdF2-4qX-w:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=Kxe5VDIbYxg:fzdF2-4qX-w:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/Kxe5VDIbYxg" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.butlerblog.com/2015/01/30/how-to-build-successful-membership-sites/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.butlerblog.com/2015/01/30/how-to-build-successful-membership-sites/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"Change WordPress email settings to reduce spam rejection";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/UXBYB7kQsxM/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.butlerblog.com/2014/11/24/change-wordpress-email-settings-to-reduce-spam-rejection/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 24 Nov 2014 16:41:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"webdev";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:29:"Wordpress Email Configuration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:7:"wp_mail";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3263";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1774:"I have several other posts on how to improve the reliability of email sent via wp_mail and how to troubleshoot your WordPress email settings, most of which has focused on the sending end. A common...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=UXBYB7kQsxM:4_c9_4U2EAY:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=UXBYB7kQsxM:4_c9_4U2EAY:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=UXBYB7kQsxM:4_c9_4U2EAY:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/UXBYB7kQsxM" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:99:"http://www.butlerblog.com/2014/11/24/change-wordpress-email-settings-to-reduce-spam-rejection/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:94:"http://www.butlerblog.com/2014/11/24/change-wordpress-email-settings-to-reduce-spam-rejection/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:36:"
		
		
		
		
		
				

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Weekend Reading List";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/7lanse57Iro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.butlerblog.com/2014/10/25/weekend-reading-list-3/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 25 Oct 2014 15:00:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1772:"One of these weeks, I&#8217;m going to get the Weekend Reading List out on a Friday like it&#8217;s supposed to be! But at least this is closer (Saturday morning).  I&#8217;ve got a great list of...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=7lanse57Iro:ra3rzd2c9vI:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=7lanse57Iro:ra3rzd2c9vI:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=7lanse57Iro:ra3rzd2c9vI:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/7lanse57Iro" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://www.butlerblog.com/2014/10/25/weekend-reading-list-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.butlerblog.com/2014/10/25/weekend-reading-list-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Weekend Reading List";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/B16V7TM1ZY8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.butlerblog.com/2014/10/17/weekend-reading-list-2/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Oct 2014 16:35:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:15:"Weekend Reading";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"clickbank";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"freelance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3196";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1763:"This week&#8217;s weekend reading list has some great posts on content creation and copywriting.   The first is from KISSmetrics &#8211; How to Steal Killer Sales Copy Straight from Your...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=B16V7TM1ZY8:GPC8YEFff7w:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=B16V7TM1ZY8:GPC8YEFff7w:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=B16V7TM1ZY8:GPC8YEFff7w:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/B16V7TM1ZY8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://www.butlerblog.com/2014/10/17/weekend-reading-list-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.butlerblog.com/2014/10/17/weekend-reading-list-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:38:"http://feeds.feedburner.com/butlerblog";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:10:"butlerblog";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:10:"butlerblog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:29:"https://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"wdo9Tck1Iu5K3iM3z7CKWh1KtIw";s:13:"last-modified";s:29:"Thu, 10 Sep 2015 16:01:00 GMT";s:16:"content-encoding";s:4:"gzip";s:4:"date";s:29:"Thu, 10 Sep 2015 17:31:11 GMT";s:7:"expires";s:29:"Thu, 10 Sep 2015 17:31:11 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";}s:5:"build";s:14:"20150611172108";}', 'no') ; 
INSERT INTO `gx_options` VALUES (361, '_transient_timeout_feed_mod_2c2fe0099a2578688413800ea68677d6', '1441949471', 'no') ; 
INSERT INTO `gx_options` VALUES (362, '_transient_feed_mod_2c2fe0099a2578688413800ea68677d6', '1441906271', 'no') ; 
INSERT INTO `gx_options` VALUES (363, '_site_transient_timeout_available_translations', '1441917105', 'yes') ; 
INSERT INTO `gx_options` VALUES (364, '_site_transient_available_translations', 'a:59:{s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-26 06:57:37";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-27 06:36:25";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:22:"Продължение";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-08 17:43:43";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-08 11:08:34";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-03 00:26:43";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:12:"Forts&#230;t";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-13 14:52:11";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:12:"de_DE_formal";a:8:{s:8:"language";s:12:"de_DE_formal";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-26 14:36:24";s:12:"english_name";s:15:"German (Formal)";s:11:"native_name";s:13:"Deutsch (Sie)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.1.7/de_DE_formal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-22 11:37:31";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/es_ES.zip";s:3:"iso";a:1:{i:1;s:2:"es";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/es_MX.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-04-25 13:39:01";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/es_PE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-04 19:47:01";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.0/es_CL.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"et";a:8:{s:8:"language";s:2:"et";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-05 20:09:08";s:12:"english_name";s:8:"Estonian";s:11:"native_name";s:5:"Eesti";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/et.zip";s:3:"iso";a:2:{i:1;s:2:"et";i:2;s:3:"est";}s:7:"strings";a:1:{s:8:"continue";s:6:"Jätka";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-15 10:49:37";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-10 14:16:27";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-05 17:37:43";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.0/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-26 15:20:27";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1.7/haz.zip";s:3:"iso";a:1:{i:3;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-12 08:05:04";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:12:"להמשיך";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-07 17:26:35";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-26 06:43:50";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:7:"Tovább";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:9:"続ける";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-04-23 15:23:08";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-26 15:57:42";s:12:"english_name";s:17:"Myanmar (Burmese)";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.7/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ေဆာင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-07 10:32:20";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-16 14:25:19";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nn_NO";a:8:{s:8:"language";s:5:"nn_NO";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-08 07:10:14";s:12:"english_name";s:19:"Norwegian (Nynorsk)";s:11:"native_name";s:13:"Norsk nynorsk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/nn_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nn";i:2;s:3:"nno";}s:7:"strings";a:1:{s:8:"continue";s:9:"Hald fram";}}s:3:"oci";a:8:{s:8:"language";s:3:"oci";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-10 17:07:58";s:12:"english_name";s:7:"Occitan";s:11:"native_name";s:7:"Occitan";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.2.2/oci.zip";s:3:"iso";a:2:{i:1;s:2:"oc";i:2;s:3:"oci";}s:7:"strings";a:1:{s:8:"continue";s:9:"Contunhar";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-09 10:15:05";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-29 22:19:48";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.7/ps.zip";s:3:"iso";a:2:{i:1;s:2:"ps";i:2;s:3:"pus";}s:7:"strings";a:1:{s:8:"continue";s:8:"دوام";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-22 10:25:51";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-08 14:53:48";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-31 11:58:44";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-26 09:29:23";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-26 16:25:46";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.7/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:10:"Nadaljujte";}}s:2:"sq";a:8:{s:8:"language";s:2:"sq";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-29 08:27:12";s:12:"english_name";s:8:"Albanian";s:11:"native_name";s:5:"Shqip";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/sq.zip";s:3:"iso";a:2:{i:1;s:2:"sq";i:2;s:3:"sqi";}s:7:"strings";a:1:{s:8:"continue";s:6:"Vazhdo";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-12 00:55:52";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:2:"tl";a:8:{s:8:"language";s:2:"tl";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-06 10:10:09";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/tl.zip";s:3:"iso";a:2:{i:1;s:2:"tl";i:2;s:3:"tgl";}s:7:"strings";a:1:{s:8:"continue";s:10:"Magpatuloy";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-22 10:57:52";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-26 16:45:38";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:9:"Uyƣurqə";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.7/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:2:"uk";a:8:{s:8:"language";s:2:"uk";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-05 10:51:50";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/uk.zip";s:3:"iso";a:2:{i:1;s:2:"uk";i:2;s:3:"ukr";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продовжити";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-04-29 06:37:03";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (377, 'akismet_strictness', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (378, 'akismet_show_user_comments_approved', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (379, 'wordpress_api_key', '4055b30fa7f6', 'yes') ; 
INSERT INTO `gx_options` VALUES (380, 'widget_tribe-events-list-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (381, '_transient_timeout_feed_0d102f2a1f4d6bc90eb8c6ffe18e56ed', '1441950021', 'no') ; 
INSERT INTO `gx_options` VALUES (382, '_transient_feed_0d102f2a1f4d6bc90eb8c6ffe18e56ed', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"The Events Calendar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:29:"https://theeventscalendar.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress event plugins for people who kick ass";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Sep 2015 17:27:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Release: The Events Calendar 3.12.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"https://theeventscalendar.com/release-the-events-calendar-3-12-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"https://theeventscalendar.com/release-the-events-calendar-3-12-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Sep 2015 16:07:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1003633";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:607:"<p>Hello and happy Thursday, friends! If you missed the buzz, we released The Events Calendar 3.12 this week and now we&#8217;re ready with a maintenance release for you. The Events Calendar 3.12.1 makes just one change to our core plugin: Tweak &#8211; Text domains updated for consistency with the plugin slug Fix &#8211; Restored normal operation&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-3-12-1/">Release: The Events Calendar 3.12.1</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2346:"<p>Hello and happy Thursday, friends! If you missed the buzz, we released The Events Calendar 3.12 this week and now we&#8217;re ready with a maintenance release for you.</p>
<p><strong><a href="https://wordpress.org/plugins/the-events-calendar/">The Events Calendar 3.12.1</a></strong> makes just one change to our core plugin:</p>
<ul>
<li><strong>Tweak</strong> &#8211; Text domains updated for consistency with the plugin slug</li>
<li><strong>Fix</strong> &#8211; Restored normal operation of the changelog reader (used within the update screen)</li>
</ul>
<p>So, why the update? WordPress.org <a href="https://make.wordpress.org/plugins/2015/09/01/plugin-translations-on-wordpress-org/">will soon start hosting language files for plugins</a> on translate.wordpress.org and is asking plugin authors to connect their code to it for the sake of being able to accept translation pushes when they&#8217;re available. We&#8217;re simply setting ourselves up for that change when it comes.</p>
<p>Please note that this change has no functional impact on the plugin. In other words, if you&#8217;ve already updated to 3.12, then updating to 3.12.1 will be smooth sailing for you. No customizations or template overrides will be impacted at all, especially if you are updating from 3.12.</p>
<p>If you haven&#8217;t moved to 3.12 yet, please do <a href="https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/">check out the release notes</a> for it as well as our <a href="https://theeventscalendar.com/the-events-calendar-pro-add-ons-3-12-things-to-be-aware-of/">post on high level changes</a> to be aware of. We&#8217;re also always happy to help you out with any questions you have about the updates. Premium license holders can hit us up directly here in <a href="https://theeventscalendar.com/support/forums">our forums</a> and any other questions can be sent in to the <a href="https://wordpress.org/support/plugin/the-events-calendar">forums at WordPress.org</a>, which we hit once a week.</p>
<p>Thanks a ton for your support and keep on rocking!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-3-12-1/">Release: The Events Calendar 3.12.1</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"https://theeventscalendar.com/release-the-events-calendar-3-12-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"Achievement Unlocked: Celebrating 2 Million Downloads of The Events Calendar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"https://theeventscalendar.com/2-million-downloads-the-events-calendar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:79:"https://theeventscalendar.com/2-million-downloads-the-events-calendar/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Sep 2015 15:38:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1001524";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:659:"<p>Our flagship product, The Events Calendar, has officially reached 2 million downloads! When we first added The Events Calendar to the WordPress.org repo 6 years ago, we knew we were onto something big. Within the first few months, our plugin had already been downloaded 25,000 times.  The demand for events calendar functionality within WordPress sites&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/2-million-downloads-the-events-calendar/">Achievement Unlocked: Celebrating 2 Million Downloads of The Events Calendar</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Jen Jamar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5012:"<p>Our flagship product, <a href="https://theeventscalendar.com/product/wordpress-events-calendar/">The Events Calendar</a>, has officially reached 2 million downloads!</p>
<p>When we first added The Events Calendar to the WordPress.org repo 6 years ago, we knew we were onto something big. Within the first few months, our plugin had already been downloaded 25,000 times.  The demand for events calendar functionality within WordPress sites has continued to grow over the years, and we&#8217;ve scaled right along with it, maintaining consistently high quality standards along the way.</p>
<p>As it stands right now, there are over 200,000 active installs of The Events Calendar, with more being added each day. An impressive 90% of reviewers have rated the plugin 4 stars or higher, with more than 700 perfect 5-star ratings. We want to thank everyone for those endorsements, so make sure to scroll down for one of our rare coupon codes.</p>
<h2>A Modern Tribe Milestone</h2>
<p>Milestones are important measurements for many companies, and <a href="http://tri.be/about/" target="_blank">Modern Tribe</a> is no exception. Milestones give us the opportunity to acknowledge the hard work of our team members and highlight their contributions leading up to the moment. They also help us appreciate the course we&#8217;ve taken to get where we are, view our current position through a new lens, and chart our forward trajectory into the rapidly approaching future.</p>
<p>With that said, the 2 million downloads milestone for The Events Calendar is more than just a notch in our belt. It&#8217;s proof that our daily grind pays off. Offering a free plugin is one thing, but providing support, adding new features, and keeping up with UI &amp; code updates takes dedication. Along with The Events Calendar, we have 9 other free plugins available in the repo, plus another 10 or so premium plugins that make up the core of our products business. Getting to 2 million downloads is awesome, but getting there with a reputation of building products that work out of the box, are secure, easy to customize, regularly updated, and have good support behind them is really at the core of what we do each and every day.</p>
<h2>Sending 2 Million Thanks</h2>
<p>That brings us to you and the other 2 million+ people we want to thank for helping us make this happen. The Events Calendar wouldn&#8217;t be as popular as it is today with the support of the WordPress community, which includes:</p>
<ul>
<li>Our <a href="https://theeventscalendar.com/the-team/" target="_blank">amazing team of WordPress developers, designers, QA, &amp; support</a></li>
<li>Fantastic <a href="https://github.com/moderntribe/the-events-calendar" target="_blank">contributors on GitHub</a> that help us maintain the code</li>
<li>Fine folks that leave us <a href="https://wordpress.org/support/view/plugin-reviews/the-events-calendar" target="_blank">ratings &amp; feedback</a> on .org</li>
<li>UserVoice users that <a href="https://tribe.uservoice.com/forums/195723-feature-ideas" target="_blank">suggest improvements &amp; features</a></li>
</ul>
<p>And, of course, all of the 2 million+ users that have downloaded The Events Calendar plugin. We know there are other choices for WordPress calendars out there, and we wholeheartedly appreciate that you consistently choose us over anyone else.</p>
<p><strong>Thank you for your support. </strong></p>
<p><em>Want to stay in the loop with our latest releases, updates, and announcements? <a href="http://m.tri.be/rm">Sign up for our email list</a>. You&#8217;ll get news about The Events Calendar delivered right to your inbox a couple times a month. </em></p>
<p><script type="text/javascript">// <![CDATA[
(function () { var e = document.createElement(\'script\'); e.type = \'text/javascript\'; e.async = true; e.src = (\'https:\' == document.location.protocol ? \'https\' : \'http\') + \'://btn.createsend1.com/js/sb.min.js?v=3\'; e.className = \'createsend-script\'; var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(e, s); })();
// ]]&gt;</script></p>
<h2>Save 20% on Pro + More</h2>
<p>It wouldn&#8217;t be a party without a little hospitality, right? Since we can&#8217;t serve drinks through the screen (yet), we&#8217;ll have to settle for providing a sweet discount on our products instead.</p>
<p>Now through Friday, September 11th 2015, use promo code <strong>celebrate_2million</strong> to take 20% off your entire purchase, including Events Calendar Pro and all of our other premium products.</p>
<p>We&#8217;ll keep the fine print simple, too &#8211; this code is valid for any license type of our premium plugins and cannot be combined with any other offers.</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/2-million-downloads-the-events-calendar/">Achievement Unlocked: Celebrating 2 Million Downloads of The Events Calendar</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"https://theeventscalendar.com/2-million-downloads-the-events-calendar/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"Release: Version 3.12 of The Events Calendar, PRO and all add-ons";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:94:"https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:103:"https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Sep 2015 23:33:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://theeventscalendar.com/?p=999636";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:631:"<p>It&#8217;s been just a little over a month since our last round of big updates and here we are with another batch of exciting new things for you. The Events Calendar 3.12 is now available, including updates to all the add-ons. There&#8217;s a whole lot of awesomeness to cover here, so let&#8217;s get right down&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/">Release: Version 3.12 of The Events Calendar, PRO and all add-ons</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:14709:"<p>It&#8217;s been just a little over a month <a href="https://theeventscalendar.com/release-version-3-11-of-the-events-calendar-pro-and-all-add-ons/">since our last round of big updates</a> and here we are with another batch of exciting new things for you. The Events Calendar 3.12 is now available, including updates to all the add-ons.</p>
<p>There&#8217;s a whole lot of awesomeness to cover here, so let&#8217;s get right down to it:</p>
<ul>
<li><a href="#core"><strong>The Events Calendar</strong></a></li>
<li><a href="#pro"><strong>Events Calendar PRO</strong></a></li>
<li><a href="#filter"><strong>Filter Bar</strong></a></li>
<li><a href="#community"><strong>Community Events</strong></a></li>
<li><a href="#ical"><strong>iCal Importer</strong></a></li>
<li><a href="#eventbrite"><strong>Eventbrite Tickets</strong></a></li>
<li><a href="#facebook"><strong>Facebook Events</strong></a></li>
<li><strong><a href="#apm">Advanced Post Manager</a></strong></li>
<li><a href="#woo"><strong>WooCommerce Tickets</strong></a></li>
<li><a href="#wpec"><strong>WPEC Tickets</strong></a></li>
<li><a href="#edd"><strong>EDD Tickets</strong></a></li>
<li><a href="#shopp"><strong>Shopp Tickets</strong></a></li>
</ul>
<hr />
<p>&nbsp;</p>
<h3 id="core">The Events Calendar 3.12</h3>
<h5>Security</h5>
<ul>
<li>Resolved JS vulnerability in minified JS by upgrading to uglifyjs 2.4.24</li>
</ul>
<h5>Performance</h5>
<ul>
<li>Greatly optimized the generation of Month View data</li>
</ul>
<h5>Features</h5>
<ul>
<li>Extended CSV importer fields to include full coverage of Event, Organizer, and Venue fields (Thank you Sean for the original UserVoice post!)</li>
<li>Added support for WPML, thanks for waiting!</li>
<li>Make the attendees report nav filterable with tribe_events_tickets_attendees_table_nav (Props to aaemnnosttv)</li>
<li>Add filters to the attendees report meta information(props to aaemnnosttv):
<ul>
<li><samp>tribe_events_tickets_attendees_event_summary_table_before</samp></li>
<li><samp>tribe_events_tickets_attendees_event_details_top</samp></li>
<li><samp>tribe_events_tickets_attendees_event_details_bottom</samp></li>
<li><samp>tribe_events_tickets_attendees_ticket_sales_top</samp></li>
<li><samp>tribe_events_tickets_attendees_ticket_sales_bottom</samp></li>
<li><samp>tribe_events_tickets_attendees_totals_top</samp></li>
<li><samp>tribe_events_tickets_attendees_totals_bottom</samp></li>
<li><samp>tribe_events_tickets_attendees_event_summary_table_after</samp></li>
</ul>
</li>
<li>Make the Tickets attendees report page title filterable with <samp>tribe_events_tickets_attendees_event_title</samp> (Props to aaemnnosttv)</li>
<li>Make the venue metabox template file filterable with <samp>tribe_events_venue_meta_box_template</samp> (props to aaemnnosttv)</li>
<li>Added a filter (<samp>tribe_show_organizer_email_obfuscation_alert</samp>) to make the organizer email obfuscation message optional (Thanks for the idea Cliffy!)</li>
<li>Added a filter (<samp>tribe_minutes_increment</samp>) that allows you to alter the minute incrementor used to generate the Minutes drop-down box (Thank you d4mation-!)</li>
<li>Added timezone support to allow different events to be set in different timezones</li>
</ul>
<h5>Minor Tweaks</h5>
<ul>
<li>Relocated event recurrence-specific JS to Events PRO where it belongs</li>
<li>Style nowrap on ticket forms with CSS rather than HTML attributes (Thanks Mark!)</li>
<li>Updated the attendees template to use divs to separate event data (Props to aaemnnosttv)</li>
<li>Display the order id with a proper link in the attendees report (Thank you aaemnnosttv!)</li>
<li>Pointed the &#8220;Add-on Documentation&#8221; link on the Event &gt; Settings &gt; Help page to a better location.</li>
<li>Pad SQL joins with spacing to avoid conflicts with other plugins that modify SQL (Props to jeremyfelt!)</li>
</ul>
<h5>Bugs Squashed</h5>
<ul>
<li>Fixed a problem where Google Maps coordinates failed on Venues (thank you Matt for the help!)</li>
<li>Fixed bug where category could be dropped from month view for a specific category when searching (Cheers to omni for the report!)</li>
<li>Resolved bug where executing <samp>wp_insert_post</samp> within a hook to <samp>publish_tribe_events</samp> prevented event meta from being saved appropriately (Thank you 37designs for the report!)</li>
<li>Fixed a fatal caused by attempting to use <samp>get_current_screen</samp> before it was available for use in some contexts (props to Enchiridion)</li>
<li>Fixed bug where <samp>Date_Utils::datetime_from_format</samp> converted dates with 1 character days/months incorrectly</li>
<li>Fixed issue with event title attributes not always escaping properly on List and Day views (Cheers to nobita for the report!)</li>
<li>Fixed issue with Event Costs not updating when a new ticket was only submitted via Ajax (Thanks Chris!)</li>
<li>Fixed an issue Twenty Fourteen and the event views being hidden in screen sizes smaller then 400px (Thank you for the help Hilary!)</li>
<li>Fixed an issue where the month view date selector became full window width when Skeleton styles were enabled</li>
<li>Fixed a notice on the plugin updater page</li>
<li>Fixed a localization issue in the settings environment (props to @tititou36 for highlighting the issue)</li>
<li>Fixed a problem which was resetting the &#8220;Show Google Map&#8221; option for events when they were re-imported via CSV (thanks to @jameswemyss for highlighting this)</li>
</ul>
<h5>Deprecated Stuff</h5>
<ul>
<li>The <samp>tribe_events_getLink</samp> is being deprecated in favor of <samp>tribe_events_get_link</samp>. Scheduled removal from source is v4.2</li>
<li><samp>The Tribe__Events__Advanced_Functions__Register_Meta::gmap_link()</samp> has been deprecated since 3.6 and has now been removed from source</li>
<li>The <samp>tribe_events_single_event_meta()</samp> function has been deprecated since 3.6 and has now been removed from source</li>
</ul>
<hr />
<h3 id="pro">The Events Calendar PRO 3.12</h3>
<h5>Security</h5>
<ul>
<li>Resolved JS vulnerability in minified JS by upgrading to uglifyjs 2.4.24</li>
</ul>
<h5>Performance</h5>
<ul>
<li>Removed a no-longer needed join from many queries to provide faster page loads</li>
</ul>
<h5>Features</h5>
<ul>
<li>Added support for the long awaited Arbitrary Recurrence! Creating recurring events with multiple granular rulesets is now possible.</li>
<li>Added support for WPML, thanks for waiting!</li>
<li>Extended CSV imports to include custom fields defined in events settings (Big thanks to zacwasielewski for submitting a similar pull request! You rock! <img src="https://theeventscalendar.com/wp-includes/images/smilies/simple-smile.png" alt=":)" class="wp-smiley" style="height: 1em; max-height: 1em;" /> )</li>
<li>Added none option for both Radio and Dropdown Additional Fields (Thanks to Justin on the forums!)</li>
<li>Added support for timezones following the introduction of timezone support in The Events Calendar</li>
</ul>
<h5>Minor Tweak</h5>
<ul>
<li>Pad SQL joins with spacing to avoid conflicts with other plugins that modify SQL (props to jeremyfelt)</li>
</ul>
<h5>Bugs Squashed</h5>
<ul>
<li>Fixed issue where generating recurring events did not trigger the rebuilding of the known date range</li>
<li>Fixed APM Start/End Date filters to stop showing SQL errors</li>
<li>Fixed an issue with additional fields not showing as selected when a symbol is included in the label (Props to Justin!)</li>
<li>Resolved issue where events without venues were showing up in Map View</li>
<li>Fixed a bug where the tribe-mini-calendar-today CSS class was not removed from some days in the mini calendar widget while clicking around (Thanks to mennstudio for the report!)</li>
<li>Resolved a bug where &#8220;Additional Fields&#8221; with a double quote in the title would be saved with a backslash</li>
<li>Fixed notices that were being thrown while configuring the Countdown Widget in the Customizer</li>
<li>Fixed a problem where recurring event updates did not properly complete (props to Ian for detecting this problem!)</li>
<li>Fixed a problem where the first event in a series of recurring events could be excluded from the &#8220;All Events&#8221; view (Cheers to Ian for reporting this!)</li>
</ul>
<h5>Deprecated Stuff</h5>
<ul>
<li>Functions that added useless SQL have been removed from source: <samp>Tribe__Events__Pro__Main::posts_fields()</samp> and <samp>Tribe__Events__Pro__Main::posts_join()</samp></li>
</ul>
<hr />
<h3 id="filter">Filter Bar 3.12</h3>
<h5>Security</h5>
<ul>
<li>Resolved JS vulnerability in minified JS by upgrading to uglifyjs 2.4.24</li>
</ul>
<h5>Bug Squashed</h5>
<ul>
<li>Resolved issue where using the filterbar inappropriately filtered events beyond the main event loop (i.e. events rendered within widgets)</li>
</ul>
<hr />
<p>&nbsp;</p>
<h3 id="core">Community Events 3.12</h3>
<h5>Security</h5>
<ul>
<li>Resolved JS vulnerability in minified JS by upgrading to uglifyjs 2.4.24</li>
</ul>
<h5>Features</h5>
<ul>
<li>Added support for Events PRO&#8217;s Arbitrary Recurrence for events in the event submission form</li>
<li>Added none option for both Radio and Dropdown Additional Fields (Thanks to Justin on the forums!)</li>
<li>Modified timezone handling to take advantage of new capabilities within The Events Calendar</li>
</ul>
<h5>Minor Tweaks</h5>
<ul>
<li>Added currency position field to the event submission form</li>
<li>Submitting a featured image that is too large will now generate an error</li>
<li>Relocated the ReCaptcha class to avoid conflicts with other ReCaptcha enabled plugins (Props to ryandc for the original report!)</li>
<li>Disable the organizer email obfuscation message on the Community Add form (Thank you cliffy for bringing this to our attention!)</li>
<li>Default Country been respected without locking the user options</li>
</ul>
<h5>Bugs Squashed</h5>
<ul>
<li>Resolved bug that prevented organizers from being identified as present in the submitted form when they were set as required fields  (That you Rob for the report!)</li>
<li>Fixed an issue with the admin bar showing for user roles that were blocked from admin</li>
<li>Fixed an issue with additional fields not showing as selected when a symbol is included in the label (Props to Justin!)</li>
<li>Fixed issue where the start and end dates for events were defaulted to the current hour on the Community Add form rather than the defaults used in the dashboard</li>
</ul>
<hr />
<h3 id="ical">iCal Importer 3.12</h3>
<h5>Security</h5>
<ul>
<li>Resolved JS vulnerability in minified JS by upgrading to uglifyjs 2.4.24</li>
</ul>
<h5>Minor Tweak</h5>
<ul>
<li>Eliminated generic error messages in favor of errors with more details</li>
<li>Conformed code to updated coding standards</li>
</ul>
<h5>Bugs Squashed</h5>
<ul>
<li>Fixed bug causing the saved recurring import editor to be cropped on smaller browser windows</li>
<li>Added missing text domains to strings so they can be translated as desired</li>
</ul>
<hr />
<h3 id="eventbrite">Eventbrite Tickets 3.12</h3>
<h5>Feature</h5>
<ul>
<li>Modified timezone handling to take advantage of new capabilities within The Events Calendar</li>
</ul>
<h5>Minor Tweaks</h5>
<ul>
<li>Modify the error messages to be presented in a more verbose way</li>
<li>Improvements on the sanitization on data coming from Eventbrite API</li>
<li>Use only include_fee true/false now that Eventbrite has deprecated the use of split_fee (Cheers to Alain for the report!)</li>
<li>Make Eventbrite the authoritative source for currency, listed status, shareable status, invite only status, and whether or not to show remaining tickets (Thank you Jessie!)<br />
Modify the way we import the Eventbrite description for better HTML results on WordPress-side Events (Thanks Carlos for the help!)</li>
</ul>
<h5>Bugs Squashed</h5>
<ul>
<li>Improve the way datepickers handle start and end dates boundries</li>
<li>Fixed a bug where the tickets iFrame was not respecting the Eventbrite privacy settings (Props to Michael for this!)</li>
<li>Fixed a price bug where some inactive numbers where been displayed (Thank you Ben for the report!)</li>
<li>Fixed the conditionals for Eventbrite import page, prevents redirect to list of blog posts</li>
<li>Fixed errors when permalinks are set to default</li>
</ul>
<hr />
<h3 id="facebook">Facebook Events 3.12</h3>
<h5>Feature</h5>
<ul>
<li>Modified timezone handling to take advantage of new capabilities within The Events Calendar</li>
</ul>
<h5>Bug Squashed</h5>
<ul>
<li>Fixed and removed some incorrectly exposed HTML from the admin environment</li>
</ul>
<hr />
<h3 id="apm">Advanced Post Manager</h3>
<h5>Bug Squashed</h5>
<ul>
<li>Don&#8217;t translate SQL &#8220;LIKE&#8221;. That&#8217;s just silly.</li>
</ul>
<hr />
<h3 id="woo">WooCommerce Tickets 3.12</h3>
<h5>Feature</h5>
<ul>
<li>Added additional attendee generation hooks: <samp>wootickets_attendee_insert_args</samp> and <samp>wootickets_get_ticket</samp> (Thanks to aaemnnosttv for this!)</li>
</ul>
<h5>Minor Tweaks</h5>
<ul>
<li>Build and provide an order ID link when generating the list of attendees (Props to aaemnnosttv!)</li>
<li>Added additional parameters to the following hooks (props to aaemnnosttv for this):
<ul>
<li><samp>wootickets_generate_ticket_attendee</samp></li>
<li><samp>wootickets_after_create_ticket</samp></li>
<li><samp>wootickets_after_update_ticket</samp></li>
<li><samp>wootickets_after_save_ticket</samp></li>
</ul>
</li>
<li>Use CSS rather than HTML attributes to set nowrap on the tickets table (Thanks to Mark for reporting this!)</li>
<li>Made ticket prices update via ajax the instant changes are made, instead of waiting for the WP Update button to trigger them (Cheers to Daniel and Chris!)</li>
</ul>
<hr />
<h3 id="wpec">WPEC Tickets 3.12</h3>
<h5>Minor Tweak</h5>
<ul>
<li>Use CSS rather than HTML attributes to set nowrap on the tickets table (Thank you Mark for highlighting this issue!)</li>
</ul>
<hr />
<h3 id="edd">EDD Tickets 3.12</h3>
<h5>Minor Tweak</h5>
<ul>
<li>Use CSS rather than HTML attributes to set nowrap on the tickets table (Thank you Mark for bringing this up!)</li>
</ul>
<hr />
<h3 id="shopp">Shopp Tickets 3.12</h3>
<h5>Minor Tweak</h5>
<ul>
<li>Use CSS rather than HTML attributes to set nowrap on the tickets table (Thank you Mark for the report!)</li>
</ul>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/">Release: Version 3.12 of The Events Calendar, PRO and all add-ons</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:99:"https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"3.12 Release Candidate code is now available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"https://theeventscalendar.com/version-3-12-release-candidate-code-is-now-available/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:92:"https://theeventscalendar.com/version-3-12-release-candidate-code-is-now-available/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 01 Sep 2015 22:25:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://theeventscalendar.com/?p=998905";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:631:"<p>Howdy folks! It&#8217;s been a super productive month since our last update. We&#8217;ve been hard at work on getting v 3.12 of The Events Calendar, Events Calendar PRO + all add-ons in your hands. We&#8217;re stoked to announce that release candidates for the upcoming versions are now available! There are some sweet new features in the mix&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/version-3-12-release-candidate-code-is-now-available/">3.12 Release Candidate code is now available</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1786:"<p>Howdy folks! It&#8217;s been a super productive month since our last update. We&#8217;ve been hard at work on getting <strong>v 3.12 of The Events Calendar, Events Calendar PRO + all add-ons</strong> in your hands. We&#8217;re stoked to announce that release candidates for the upcoming versions are now available!</p>
<p>There are some sweet new features in the mix in addition to a host of refinements that we&#8217;re really proud to show you. (For a full overview of what&#8217;s coming, <a href="https://theeventscalendar.com/the-events-calendar-pro-add-ons-3-12-things-to-be-aware-of/">see our blog post</a>). We&#8217;re making this release candidate available now for the sake of testing and getting a feel for what&#8217;s fresh in 3.12 and prepare for any possible impact it may have on your site. The Events Calendar is super extendable and we know many of you have customized the plugin, so this early access will help you and your team test things out in a safe environment before dishing everything to production.</p>
<p>The release candidate is available to all premium license holders. If you have an license for any of our premium plugins, you&#8217;ll see a list of release candidate plugins under <em>My Account &#8211;&gt; Downloads</em> when you log in right here on this site. The downloaded .zip can be uploaded to your site like any other plugin and tested from there.</p>
<p>We hope you enjoy the early release and look forward to hearing your feedback on the 3.12 releases!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/version-3-12-release-candidate-code-is-now-available/">3.12 Release Candidate code is now available</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:88:"https://theeventscalendar.com/version-3-12-release-candidate-code-is-now-available/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:98:"Here’s what coming in version 3.12 of The Events Calendar, The Events Calendar PRO + all add-ons";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"https://theeventscalendar.com/the-events-calendar-pro-add-ons-3-12-things-to-be-aware-of/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:98:"https://theeventscalendar.com/the-events-calendar-pro-add-ons-3-12-things-to-be-aware-of/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 31 Aug 2015 17:43:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://theeventscalendar.com/?p=999676";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:687:"<p>Hey folks! The soon-to-be-released version 3.12 of The Events Calendar, The Events Calendar PRO + all add-ons was focused on some really significant features requested by the community, plus a healthy dose of bug fixes. We&#8217;re stoked to get the latest updates in your hands but wanted to give you a high level idea of what&#8217;s&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/the-events-calendar-pro-add-ons-3-12-things-to-be-aware-of/">Here&#8217;s what coming in version 3.12 of The Events Calendar, The Events Calendar PRO + all add-ons</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Zach";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:9857:"<p>Hey folks! The soon-to-be-released version 3.12 of The Events Calendar, The Events Calendar PRO + all add-ons was focused on some really significant features requested by the community, plus a healthy dose of bug fixes. We&#8217;re stoked to get the latest updates in your hands but wanted to give you a high level idea of what&#8217;s coming so you have idea of what&#8217;s ahead, what to watch out for and, of course, to get as excited as we are for the shiny new features!</p>
<h3>1. Added new flexible recurrence patterns</h3>
<p>This has been one of our <a href="http://tribe.uservoice.com/forums/195723-feature-ideas/suggestions/3685762-random-free-form-recurring-events">most requested features</a>. We have added a lot more flexibility around recurrence and the custom patterns you can configure. You can now create an event that starts on September 1st and will last 9 hours. It will occur every Tuesday until November 30th; every month on the 1st until March 2016; and Yearly on the Second Monday in February with no end date; but it will <em>not</em> occur on February 8th, 2016. You can also have events that recur within a single day at multiple times. Get creative- the freedom is yours! <a href="https://theeventscalendar.com/knowledgebase/pro-recurring-events/">Learn more</a>.</p>
<h3>2. Improved WPML compatibility</h3>
<p>As our plugins have become more widely used, <a href="http://tribe.uservoice.com/forums/195723-feature-ideas/suggestions/5449720-integrate-with-wpml">we have heard a lot of concerns</a> about compatibility with the WordPress Multilingual plugin (WPML). We made a stack of changes to The Events Calendar and Events Calendar PRO to make them compatible with WPML. We also have new <a href="https://theeventscalendar.com/knowledgebase/">knowledgebase</a> articles that will help you get this setup!</p>
<h3>3. Improved timezone support</h3>
<p>We completely overhauled the timezone support throughout the plugins. Every event now has timezone data stored with it independent of the blog&#8217;s timezone. This allows events to be in different timezones and improves interaction with third party APIs. <a href="https://theeventscalendar.com/knowledgebase/working-with-timezones/">Learn more</a>.</p>
<h3>4. Extended CSV importer to respect more fields</h3>
<p>The CSV importer now supports currency position, currency symbol, tags, organizer, venue, and custom fields defined in events settings.</p>
<h3>5. Improved month view performance</h3>
<p>Since our complete rewrite of Month View in 3.10, we have struggled with this view&#8217;s performance. We are now proud to announce that we have streamlined this a lot! We did extensive testing with Month Views populated with 7,000 events and were able to get typical page load times down under 3s.</p>
<h3>6. New plugin coming soon: Community Tickets!</h3>
<p>Many who run Community Events <a href="http://tribe.uservoice.com/forums/195723-feature-ideas/suggestions/4409106-allow-community-events-users-to-add-tickets-via-fr">have inquired</a> about the possibility of empowering community organizers to sell tickets for their events. This functionality is coming soon and we are actively <a href="https://theeventscalendar.com/knowledgebase/how-to-signup-for-beta-access">running a beta</a> alongside this release. We hope it&#8217;ll be generally available in the coming weeks!</p>
<h3>7. A few dozen bug fixes and small tweaks</h3>
<p>As always we strive to right our wrongs and generally make things better. The details of what we&#8217;ve fixed or tweaked will be available in the full changelog, which we&#8217;ll be sure to publish when 3.12 ships.</p>
<h3>8. New actions</h3>
<ul>
<li><samp>wootickets_after_create_ticket</samp></li>
<li><samp>wootickets_after_update_ticket</samp></li>
<li><samp>wootickets_after_save_ticket</samp></li>
<li><samp>wootickets_generate_ticket_attendee</samp></li>
</ul>
<h3>9. New filters</h3>
<ul>
<li><samp>tribe_events_tickets_attendees_table_nav</samp></li>
<li><samp>tribe_events_tickets_attendees_event_summary_table_before</samp></li>
<li><samp>tribe_events_tickets_attendees_event_details_top</samp></li>
<li><samp>tribe_events_tickets_attendees_event_details_bottom</samp></li>
<li><samp>tribe_events_tickets_attendees_ticket_sales_top</samp></li>
<li><samp>tribe_events_tickets_attendees_ticket_sales_bottom</samp></li>
<li><samp>tribe_events_tickets_attendees_totals_top</samp></li>
<li><samp>tribe_events_tickets_attendees_totals_bottom</samp></li>
<li><samp>tribe_events_tickets_attendees_event_summary_table_after</samp></li>
<li><samp>tribe_events_tickets_attendees_event_title</samp></li>
<li><samp>tribe_events_venue_meta_box_template</samp></li>
<li><samp>tribe_show_organizer_email_obfuscation_alert</samp></li>
<li><samp>tribe_minutes_increment</samp></li>
</ul>
<h3>10. There is newly deprecated code</h3>
<p>In The Events Calendar, <samp>tribe_events_getLink</samp> is being deprecated in favor of <samp>tribe_events_get_link</samp>. Slated release for full retirement: 4.2</p>
<h3>11. Some old deprecated code has been removed.</h3>
<ul>
<li><samp>Tribe__Events__Advanced_Functions__Register_Meta::gmap_link()</samp> deprecated since 3.6 has been removed</li>
</ul>
<ul>
<li>Removed unused methods in <samp>Tribe__Events__Pro__Main</samp>: <samp>posts_fields()</samp> and <samp>posts_join()</samp>.</li>
</ul>
<h3>12. Updated views</h3>
<p>Each of the templates listed below have had changes. Particular attention should be paid to those with recommendations next to them. On all but the ones marked &#8220;important&#8221; we wouldn&#8217;t expect to see template overrides breaking if they were already compatible with 3.11 code.</p>
<h4>The Events Calendar</h4>
<ul>
<li><samp>single-event.php</samp> &#8211; removed conditional with deprecated filter</li>
<li><samp>day/single-event.php</samp> &#8211; Changed title attribute function from the_title() to the_title_attribute()</li>
<li><samp>list/single-event.php</samp> &#8211; Changed title attribute function from the_title() to the_title_attribute()</li>
</ul>
<h4>Events Calendar PRO</h4>
<ul>
<li><samp>pro/modules/meta/additional-fields.php</samp> &#8211; Escaping</li>
<li><samp>pro/widgets/mini-calendar-widget.php</samp> &#8211; Isolated tribe_show_month() query context so filters do not impact the Mini Calendar widget</li>
<li><samp>pro/widgets/venue-widget.php</samp> &#8211; Better translation support on &#8220;View all&#8221; link text</li>
</ul>
<h4>Community Events</h4>
<ul>
<li><samp>community/modules/custom.php</samp> &#8211; Added &#8220;None&#8221; option for radio and dropdown fields</li>
<li><samp>community/modules/image.php</samp> &#8211; Added error message when image size is too large</li>
<li><samp>community/edit-event.php</samp> &#8211; Support for Arbitrary Recurrence <strong>&#8211; important for continued support of recurrence!</strong></li>
<li><samp>community/modules/recurrence.php</samp> &#8211; Support for Arbitrary Recurrence <strong>&#8211; important for continued support of recurrence!</strong></li>
<li><samp>community/modules/custom.php</samp> &#8211; Bug fix to show additional field values as saved even when they have special characters</li>
<li><samp>community/modules/datepickers.php</samp> &#8211; Timezone support</li>
<li><samp>community/modules/cost.php</samp> &#8211; Add support for currency position</li>
</ul>
<h4>Eventbrite Tickets</h4>
<ul>
<li><samp>eventbrite/import-eventbrite-events.php</samp> &#8211; Timezone tweaks</li>
<li><samp>eventbrite/eb-admin-notices.php</samp> &#8211; New file for displaying Eventbrite notices</li>
</ul>
<h4>iCal Importer</h4>
<ul>
<li><samp>import-form.php</samp> &#8211; Datepicker format tweaks, better escaping</li>
<li><samp>hidden-messages.php</samp> &#8211; More specific error message, better escaping</li>
<li><samp>edit-saved-recurring.php</samp> &#8211; Better escaping</li>
<li><samp>ical-tab-content.php</samp> &#8211; Spacing</li>
<li><samp>one-time-buttons.php</samp> &#8211; Better escaping</li>
<li><samp>recurring-buttons.php</samp> &#8211; Better escaping, better translations</li>
<li><samp>saved-imports-table.php</samp> &#8211; Better escaping</li>
<li><samp>status-category-selector.php</samp> &#8211; Better escaping</li>
</ul>
<h4>WooCommerce Tickets, WP e-Commerce Tickets, Easy Digital Downloads Tickets, and Shopp Tickets</h4>
<ul>
<li><samp>[ticketpluginname]/tickets.php</samp> &#8211; Removed HTML nowrap attribute</li>
</ul>
<p>Users have told us that they like to see this list of high level changes to be aware of, so they can prepare their sites for the updates accordingly. We hope this serves you, too. If there’s anything we missed or that you think is important enough to get more explanation in this blog post, let us know and we’ll clarify as best we can. If you want to check out the code before we release, <a href="https://theeventscalendar.com/the-events-calendar-3-12-is-coming-help-us-test-backwards-compatibility/">we are taking volunteers to test backwards compatibility</a> and will post Release Candidates for 3.12 in the downloads area of your account when they are available.</p>
<p>We can’t wait to get this release in your hands, as our focus shifts to the big exciting changes coming in 4.0! We are excited about what&#8217;s in store and we hope you all will be too <img src="https://theeventscalendar.com/wp-includes/images/smilies/simple-smile.png" alt=":)" class="wp-smiley" style="height: 1em; max-height: 1em;" /></p>
<p>Happy updating!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/the-events-calendar-pro-add-ons-3-12-things-to-be-aware-of/">Here&#8217;s what coming in version 3.12 of The Events Calendar, The Events Calendar PRO + all add-ons</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:94:"https://theeventscalendar.com/the-events-calendar-pro-add-ons-3-12-things-to-be-aware-of/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"The Events Calendar 3.12 is coming: help us test backwards compatibility";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"https://theeventscalendar.com/the-events-calendar-3-12-is-coming-help-us-test-backwards-compatibility/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:111:"https://theeventscalendar.com/the-events-calendar-3-12-is-coming-help-us-test-backwards-compatibility/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 28 Aug 2015 23:43:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1000131";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:719:"<p>Howdy folks! We&#8217;re gearing up for another release in the coming weeks and are dotting the &#8220;i&#8221;s/crossing the &#8220;t&#8221;s. For those keeping track, the upcoming release will be version 3.12 and will include updates for every plugin in our calendaring suite. This release incorporates a few large-scale changes: the introduction of freeform recurring events, better&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/the-events-calendar-3-12-is-coming-help-us-test-backwards-compatibility/">The Events Calendar 3.12 is coming: help us test backwards compatibility</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:3:"Rob";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1614:"<p>Howdy folks! We&#8217;re gearing up for another release in the coming weeks and are dotting the &#8220;i&#8221;s/crossing the &#8220;t&#8221;s. For those keeping track, the upcoming release will be version 3.12 and will include updates for every plugin in our calendaring suite.</p>
<p>This release incorporates a few large-scale changes: the introduction of freeform recurring events, better timezone handling and additional fields support for our CSV importer. To make sure we&#8217;re respecting your customizations, <strong>we&#8217;re hoping to rope in a few Events Calendar PRO users with heavily customized sites who would be willing to test our 3.12 Release Candidates.</strong></p>
<p>If you&#8217;re interested, <a href="mailto:support@theeventscalendar.com">let us know</a>. Please provide a link to your customized site in your email and confirm that you have a test (staging) site where this will be run &#8212; it is not quite production-ready. We&#8217;re hoping you&#8217;ll install the release candidates on this staging site and let us know what (if anything) breaks, so that we can try to prevent such breakage in the final release.</p>
<p>We&#8217;re looking for feedback between now and <strong>Friday, September 4. </strong>Thanks in advance for your interest!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/the-events-calendar-3-12-is-coming-help-us-test-backwards-compatibility/">The Events Calendar 3.12 is coming: help us test backwards compatibility</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:107:"https://theeventscalendar.com/the-events-calendar-3-12-is-coming-help-us-test-backwards-compatibility/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Release: The Events Calendar 3.11.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"https://theeventscalendar.com/release-the-events-calendar-3-11-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"https://theeventscalendar.com/release-the-events-calendar-3-11-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 30 Jul 2015 20:51:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://theeventscalendar.com/?p=991922";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:638:"<p>Happy Thursday! It&#8217;s that time again&#8230;time to announce another maintenance release, after we just pushed The Events Calendar 3.11.2. It addresses two bugs that were reported to us by community members after we deployed 3.11. Specifically, The Events Calendar 3.11.2 patches the following bugs: Bug &#8211; Resolved an issue where List View paging into the past only&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-3-11-2/">Release: The Events Calendar 3.11.2</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:3:"Rob";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2061:"<p>Happy Thursday! It&#8217;s that time again&#8230;time to announce another maintenance release, after we just pushed <strong><a href="https://wordpress.org/plugins/the-events-calendar/">The Events Calendar 3.11.2</a></strong>. It addresses two bugs that were reported to us by community members after we deployed 3.11. Specifically, <strong>The Events Calendar 3.11.2</strong> patches the following bugs:</p>
<ul>
<li><strong>Bug &#8211;</strong> Resolved an issue where List View paging into the past only allowed you to go 1 page in the past <em>(thanks to Richard from Prescott Art Store for reporting this!)</em></li>
<li><strong>Bug &#8211;</strong> Fixed a bug where the iCal export for Month View inappropriately observed the events-per-page limit causing some events to be excluded <em>(thanks to Neil on the forums for the heads up!)</em></li>
</ul>
<p>All users are encouraged to update, especially those who have list view enabled or expect their users to rely on the iCal export functionality. Please also keep in mind that this release only impacts The Events Calendar; as it stands, this is the only plugin to be on version 3.11.2. Everything else in our suite as of today should be either 3.11 or 3.11.1.</p>
<p>As always, we&#8217;re happy to help out on the forums if you have any problems. PRO users should bring those concerns to our <a href="http://theeventscalendar.com/support/forums/">premium forums</a>, while those using just the core The Events Calendar should post to the <a href="https://wordpress.org/support/plugin/the-events-calendar">forums at WordPress.org</a> (which, as we stress in our <a href="https://wordpress.org/support/topic/welcome-the-events-calendar-users-read-this-first?replies=1">intro message there</a>, is only checked once a week).</p>
<p>Happy updating!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-3-11-2/">Release: The Events Calendar 3.11.2</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"https://theeventscalendar.com/release-the-events-calendar-3-11-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"Help Wanted: WordPress Plugin Support for Events Calendar PRO";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"https://theeventscalendar.com/help-wanted-wordpress-plugin-support/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"https://theeventscalendar.com/help-wanted-wordpress-plugin-support/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 Jul 2015 23:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"Gigs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:20:"News & Announcements";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://theeventscalendar.com/?p=990788";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:613:"<p>Are you equal parts coder and power user? Do you feel at home writing inline docs and user tutorials? Have a strong command of WordPress’ technical side AND an overpowering desire to share that with others? The Gig Modern Tribe is growing. We’re seeking 2 great freelancers to join our forum team in the WordPress Plugin&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/help-wanted-wordpress-plugin-support/">Help Wanted: WordPress Plugin Support for Events Calendar PRO</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Nicole";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6913:"<p>Are you equal parts coder and power user? Do you feel at home writing inline docs and user tutorials? Have a strong command of WordPress’ technical side AND an overpowering desire to share that with others?</p>
<h3>The Gig</h3>
<p>Modern Tribe is growing. We’re seeking 2 great freelancers to join our forum team in the WordPress Plugin Support role. You will help users of <a href="https://theeventscalendar.com/product/wordpress-events-calendar/" target="_blank">The Events Calendar</a>, <a href="https://theeventscalendar.com/product/wordpress-events-calendar-pro/" target="_blank">Events Calendar PRO</a> and our other premium add-ons as you troubleshoot common integration issues and report bugs.</p>
<p>Everyone on Modern Tribe’s support team prioritizes the forums over all else, but you will also pitch in on weekly tasks like:</p>
<ul>
<li>Moderating the support inbox, ensuring customers and potential customers receive responses within 24 hours of submission</li>
<li>Field incoming feature requests and document them for consideration in the roadmap</li>
<li>Take point on the WordPress.org forums for our core plugin offerings</li>
<li>Testing bug reports locally and logging them in our projects system, with appropriate detail and testing instructions, when a bug is confirmed as legitimate</li>
<li>Pre-release quality assurance testing for every new release and product</li>
<li>Recording video walkthroughs highlighting plugin functionality</li>
<li>Creating tutorials, documentation, screencasts and other forum materials to help guide people to success</li>
<li>Writing snippets to solve one-off problems</li>
<li>Helping run regular user testing sessions</li>
<li>Being the voice of the community during roadmap discussions</li>
<li>Supporting product partners (other theme/plugin authors) and non-profits</li>
</ul>
<p>You will be on the front-lines, representing Modern Tribe and The Events Calendar to customers… in many ways, you are the face of the company and the bridge between us and our customers.</p>
<p>&nbsp;</p>
<h3>The Requirements</h3>
<p>We are excited to work with freelancers that can come in and make a positive impact. If you have these qualities, we&#8217;d love to hear from you!</p>
<ul>
<li>Superb communication skills, a transparent attitude and self-confidence</li>
<li>A strong comprehension of PHP, CSS, HTML and JavaScript and can provide 4-5 original code samples to back it up (this is huge; our support is highly technical, and you will not succeed without these skills)</li>
<li>A love for all things WordPress with a good understanding of its codebase and community</li>
<li>Basic familiarity with (at least) <a href="http://wordpress.org/plugins/the-events-calendar/" target="_blank">The Events Calendar</a>, our main plugin</li>
<li>A familiarity with GIT. In other words, you can clone repos, pull branches and set up local WordPress installs without hassle</li>
<li>Passion for Modern Tribe’s company culture: <a href="https://tri.be/happy-helpful-curious-accountable/">Happy, Helpful, Curious, Accountable &amp; Good</a></li>
<li>Freelance full-time and have been doing so for at least 1 year (you’re not a full-time employee moonlighting; if you don’t consider freelancing your business, this probably won’t be a good fit)</li>
<li>At least 1 year of experience managing yourself in a remote, distributed working environment</li>
<li>Must be in PST, CST, MST or EST time zones and do their work during business hours in that time zone</li>
</ul>
<h5>Huge bonus points awarded to those who:</h5>
<ul>
<li>Have built your own WordPress plugins (EXTRA bonus points if those plugins extend The Events Calendar)</li>
<li>Love doing video tutorials and have a home setup to do it</li>
<li>Have a proven track record providing support specifically for WordPress plugins, or have an active track record in the WordPress.org community</li>
</ul>
<p>&nbsp;</p>
<h3>The Day-to-Day</h3>
<p>Your main priority is the support forum at TheEventsCalendar.com, where we work daily to provide hundreds of users with timely and clear solutions to their problems. The support team keeps an open Slack channel where they pop in throughout the day, check on the status of our support queue with a handy helper bot we’ve integrated, then divide and conquer as a team. We never want to end the day with unaddressed threads, and no thread should go more than 24 hours (during the workweek) without a reply. And yes, if you’ve got “danglers”, our support bot will call you out for it.</p>
<p>Since forum work ebbs and flows, there are plenty of days where the queue is cleared out early and team members still have hours available. How you spend this time will vary. Sometimes it’ll be QA, to test out new plugins or updates to existing ones. Other times it’ll be documentation, putting together tutorials and videos to address commonly-posed questions. Marketing, design and development opportunities are also on the table for you if you demonstrate a hunger to learn — we all have the opportunity to get involved with other areas of the business, but everyone’s main priority each day is support and keeping users happy.</p>
<p>&nbsp;</p>
<h3>The Company</h3>
<p>Modern Tribe is a digital agency with a modern twist. We are a product company. We are educators. We are a great mix of freelancers and full timers. All experts. In today’s world, we get to be many things to many people.</p>
<p>We believe in making quality products for other people and ourselves, balanced by living quality lives. We are 100% distributed &amp; our team is spread around North America (and a hint beyond).</p>
<p>We believe that you should be happy, helpful, curious &amp; accountable, on top of being good at what you do. We believe life should be lived intentionally. We believe in a class of artisans and craftsman in control of their work who solve people problems rather than just build more shit. We believe in a sustainable vision of open source, and contribute consistently into the ecosystem.</p>
<p>&nbsp;</p>
<h3>We can&#8217;t wait to meet you!</h3>
<p>Think you’d be a good fit? Awesome! Head back over to our <a href="http://theeventscalendar.com/join-our-team/" target="_blank">Work With Us</a> page, and fill out an application on the form provided, make sure to select <strong>Community/Support</strong> from the radio buttons to let us know which position you’re applying for. Please be prepared to answer a few sample support questions prior to your interview. Also, please include a note about your favorite color so we know you read this.</p>
<h4></h4>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/help-wanted-wordpress-plugin-support/">Help Wanted: WordPress Plugin Support for Events Calendar PRO</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"https://theeventscalendar.com/help-wanted-wordpress-plugin-support/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Release: The Events Calendar + PRO 3.11.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"https://theeventscalendar.com/release-the-events-calendar-3-11-1-the-events-calendar-pro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:98:"https://theeventscalendar.com/release-the-events-calendar-3-11-1-the-events-calendar-pro/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 Jul 2015 21:16:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://theeventscalendar.com/?p=990614";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:589:"<p>The Events Calendar and The Events Calendar PRO 3.11.1 is hot off the presses. This is a secondary release that addresses a few bugs that were caught after the 3.11 launch last week. Be sure to check the release notes from 3.11 if you haven&#8217;t updated already and a reminder to also be aware of&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-3-11-1-the-events-calendar-pro/">Release: The Events Calendar + PRO 3.11.1</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2021:"<p><strong>The Events Calendar and The Events Calendar PRO 3.11.1</strong> is hot off the presses. This is a secondary release that addresses a few bugs that were caught after the 3.11 launch last week. Be sure to check <a href="https://theeventscalendar.com/release-version-3-11-of-the-events-calendar-pro-and-all-add-ons/">the release notes from 3.11</a> if you haven&#8217;t updated already and a reminder to also<a href="https://theeventscalendar.com/the-events-calendarproadd-ons-3-11-things-to-be-aware-of/"> be aware of the impacts of updating from 3.10 to 3.11</a>.</p>
<p>Here&#8217;s what&#8217;s new in this release:</p>
<h3>The Events Calendar</h3>
<ul>
<li><strong>Bug &#8211;</strong> Fixed bug where all events regardless of category were shown on category month views while paging through months</li>
<li><strong>Bug &#8211;</strong> Fixed bug where events marked as &#8220;Hide From Event Listings&#8221; were visible while paging through months in Month View</li>
<li><strong>Bug &#8211;</strong> Fixed bug where recurring events where hidden in Month View when recurring event instances were disabled in List View</li>
<li><strong>Bug &#8211;</strong> Fixed bug where all admin dashboard post queries inappropriately included event date SQL which caused query/sorting instability</li>
</ul>
<h3>The Events Calendar PRO</h3>
<ul>
<li><strong>Bug</strong> &#8211; Fixed bug where recurring events were hidden in Month View when recurring event instances were disabled in List View (big thanks to Rebecca Redding on the forum for the first report!)</li>
</ul>
<p>If you have any problems with the release, please <a href="http://theeventscalendar.com/support/forums/">hit us up on the forums</a>. We appreciate your support!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-3-11-1-the-events-calendar-pro/">Release: The Events Calendar + PRO 3.11.1</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:94:"https://theeventscalendar.com/release-the-events-calendar-3-11-1-the-events-calendar-pro/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Release: Eventbrite Tickets 3.11.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://theeventscalendar.com/release-eventbrite-tickets-3-11-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:73:"https://theeventscalendar.com/release-eventbrite-tickets-3-11-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 20:33:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://theeventscalendar.com/?p=989627";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:620:"<p>In what marks our second secondary maintenance release today &#8212; hot on the heels of the broader 3.11 updates to our whole plugin suite yesterday &#8212; we&#8217;ve just pushed Eventbrite Tickets 3.11.1. Eventbrite Tickets 3.11.1 is a small release, but addresses an issue we noticed in our final pre-3.11 QA and needed a bit more time to diagnose after&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-eventbrite-tickets-3-11-1/">Release: Eventbrite Tickets 3.11.1</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:3:"Rob";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1537:"<p>In what marks our second secondary maintenance release today &#8212; hot on the heels of the <a href="https://theeventscalendar.com/release-version-3-11-of-the-events-calendar-pro-and-all-add-ons/">broader 3.11 updates to our whole plugin suite</a> yesterday &#8212; we&#8217;ve just pushed<strong> <a href="https://theeventscalendar.com/product/wordpress-eventbrite-tickets/">Eventbrite Tickets 3.11.1</a>.</strong></p>
<p><strong>Eventbrite Tickets 3.11.1 </strong>is a small release, but addresses an issue we noticed in our final pre-3.11 QA and needed a bit more time to diagnose after shipping 3.11. Specifically, a change to the Eventbrite API caused tickets with a cost greater than 0 to error out + fail.</p>
<p>We hadn&#8217;t received many reports from users on this, but since Eventbrite&#8217;s API change was very recent, it&#8217;s possible many haven&#8217;t experienced it first-hand yet. Update to 3.11.1 now so you never have to <img src="https://theeventscalendar.com/wp-includes/images/smilies/simple-smile.png" alt=":)" class="wp-smiley" style="height: 1em; max-height: 1em;" /></p>
<p>If you have any problems with the release, as always, you can <a href="http://theeventscalendar.com/support/forums/">hit us up on the forums</a>. We appreciate your support!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-eventbrite-tickets-3-11-1/">Release: Eventbrite Tickets 3.11.1</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:69:"https://theeventscalendar.com/release-eventbrite-tickets-3-11-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:35:"https://theeventscalendar.com/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 10 Sep 2015 17:40:21 GMT";s:12:"content-type";s:34:"application/rss+xml; charset=UTF-8";s:10:"connection";s:5:"close";s:13:"cache-control";s:29:"max-age=3095, must-revalidate";s:12:"x-powered-by";s:21:"PHP/5.4.33-1~dotdeb.1";s:4:"vary";s:6:"Cookie";s:10:"x-pingback";s:40:"https://theeventscalendar.com/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 10 Sep 2015 17:27:22 GMT";s:4:"etag";s:34:""9aececb4bf6b86aa691017b87abc088a"";s:12:"x-robots-tag";s:14:"noindex,follow";}s:5:"build";s:14:"20150611172108";}', 'no') ; 
INSERT INTO `gx_options` VALUES (383, '_transient_timeout_feed_mod_0d102f2a1f4d6bc90eb8c6ffe18e56ed', '1441950021', 'no') ; 
INSERT INTO `gx_options` VALUES (384, '_transient_feed_mod_0d102f2a1f4d6bc90eb8c6ffe18e56ed', '1441906821', 'no') ; 
INSERT INTO `gx_options` VALUES (387, 'finished_splitting_shared_terms', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (388, 'db_upgraded', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (391, 'rewrite_rules', 'a:164:{s:40:"(?:event)/([^/]+)/(\\d{4}-\\d{2}-\\d{2})/?$";s:56:"index.php?tribe_events=$matches[1]&eventDate=$matches[2]";s:28:"(?:event)/([^/]+)/(?:all)/?$";s:74:"index.php?tribe_events=$matches[1]&post_type=tribe_events&eventDisplay=all";s:45:"(?:event)/([^/]+)/(\\d{4}-\\d{2}-\\d{2})/ical/?$";s:63:"index.php?tribe_events=$matches[1]&eventDate=$matches[2]&ical=1";s:25:"(?:event)/([^/]+)/ical/?$";s:56:"index.php?ical=1&name=$matches[1]&post_type=tribe_events";s:28:"(?:events)/(?:page)/(\\d+)/?$";s:68:"index.php?post_type=tribe_events&eventDisplay=list&paged=$matches[1]";s:38:"(?:events)/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?post_type=tribe_events&eventDisplay=list&feed=$matches[1]";s:23:"(?:events)/(?:month)/?$";s:51:"index.php?post_type=tribe_events&eventDisplay=month";s:37:"(?:events)/(?:list)/(?:page)/(\\d+)/?$";s:68:"index.php?post_type=tribe_events&eventDisplay=list&paged=$matches[1]";s:22:"(?:events)/(?:list)/?$";s:50:"index.php?post_type=tribe_events&eventDisplay=list";s:23:"(?:events)/(?:today)/?$";s:49:"index.php?post_type=tribe_events&eventDisplay=day";s:27:"(?:events)/(\\d{4}-\\d{2})/?$";s:73:"index.php?post_type=tribe_events&eventDisplay=month&eventDate=$matches[1]";s:33:"(?:events)/(\\d{4}-\\d{2}-\\d{2})/?$";s:71:"index.php?post_type=tribe_events&eventDisplay=day&eventDate=$matches[1]";s:13:"(?:events)/?$";s:53:"index.php?post_type=tribe_events&eventDisplay=default";s:18:"(?:events)/ical/?$";s:39:"index.php?post_type=tribe_events&ical=1";s:38:"(?:events)/(\\d{4}-\\d{2}-\\d{2})/ical/?$";s:78:"index.php?post_type=tribe_events&ical=1&eventDisplay=day&eventDate=$matches[1]";s:60:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:page)/(\\d+)/?$";s:97:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list&paged=$matches[2]";s:55:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:month)/?$";s:80:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=month";s:69:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:list)/(?:page)/(\\d+)/?$";s:97:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list&paged=$matches[2]";s:54:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:list)/?$";s:79:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list";s:55:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:today)/?$";s:78:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=day";s:73:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:day)/(\\d{4}-\\d{2}-\\d{2})/?$";s:100:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=day&eventDate=$matches[2]";s:59:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(\\d{4}-\\d{2})/?$";s:102:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=month&eventDate=$matches[2]";s:65:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(\\d{4}-\\d{2}-\\d{2})/?$";s:100:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=day&eventDate=$matches[2]";s:50:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/feed/?$";s:89:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list&feed=rss2";s:50:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/ical/?$";s:68:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&ical=1";s:75:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:78:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&feed=$matches[2]";s:45:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/?$";s:79:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list";s:44:"(?:events)/(?:tag)/([^/]+)/(?:page)/(\\d+)/?$";s:84:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list&paged=$matches[2]";s:39:"(?:events)/(?:tag)/([^/]+)/(?:month)/?$";s:67:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=month";s:53:"(?:events)/(?:tag)/([^/]+)/(?:list)/(?:page)/(\\d+)/?$";s:84:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list&paged=$matches[2]";s:38:"(?:events)/(?:tag)/([^/]+)/(?:list)/?$";s:66:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list";s:39:"(?:events)/(?:tag)/([^/]+)/(?:today)/?$";s:65:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=day";s:57:"(?:events)/(?:tag)/([^/]+)/(?:day)/(\\d{4}-\\d{2}-\\d{2})/?$";s:87:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=day&eventDate=$matches[2]";s:43:"(?:events)/(?:tag)/([^/]+)/(\\d{4}-\\d{2})/?$";s:89:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=month&eventDate=$matches[2]";s:49:"(?:events)/(?:tag)/([^/]+)/(\\d{4}-\\d{2}-\\d{2})/?$";s:87:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=day&eventDate=$matches[2]";s:34:"(?:events)/(?:tag)/([^/]+)/feed/?$";s:76:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list&feed=rss2";s:34:"(?:events)/(?:tag)/([^/]+)/ical/?$";s:55:"index.php?post_type=tribe_events&tag=$matches[1]&ical=1";s:59:"(?:events)/(?:tag)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:65:"index.php?post_type=tribe_events&tag=$matches[1]&feed=$matches[2]";s:29:"(?:events)/(?:tag)/([^/]+)/?$";s:66:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list";s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:8:"event/?$";s:32:"index.php?post_type=tribe_events";s:38:"event/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=tribe_events&feed=$matches[1]";s:33:"event/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=tribe_events&feed=$matches[1]";s:25:"event/page/([0-9]{1,})/?$";s:50:"index.php?post_type=tribe_events&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:33:"event/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"event/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"event/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"event/([^/]+)/trackback/?$";s:39:"index.php?tribe_events=$matches[1]&tb=1";s:46:"event/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?tribe_events=$matches[1]&feed=$matches[2]";s:41:"event/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?tribe_events=$matches[1]&feed=$matches[2]";s:34:"event/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?tribe_events=$matches[1]&paged=$matches[2]";s:41:"event/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?tribe_events=$matches[1]&cpage=$matches[2]";s:26:"event/([^/]+)(/[0-9]+)?/?$";s:51:"index.php?tribe_events=$matches[1]&page=$matches[2]";s:22:"event/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"event/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"event/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"venue/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"venue/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"venue/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"venue/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"venue/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"venue/([^/]+)/trackback/?$";s:38:"index.php?tribe_venue=$matches[1]&tb=1";s:34:"venue/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?tribe_venue=$matches[1]&paged=$matches[2]";s:41:"venue/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?tribe_venue=$matches[1]&cpage=$matches[2]";s:26:"venue/([^/]+)(/[0-9]+)?/?$";s:50:"index.php?tribe_venue=$matches[1]&page=$matches[2]";s:22:"venue/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"venue/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"venue/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"venue/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"venue/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"organizer/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"organizer/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"organizer/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"organizer/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"organizer/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"organizer/([^/]+)/trackback/?$";s:42:"index.php?tribe_organizer=$matches[1]&tb=1";s:38:"organizer/([^/]+)/page/?([0-9]{1,})/?$";s:55:"index.php?tribe_organizer=$matches[1]&paged=$matches[2]";s:45:"organizer/([^/]+)/comment-page-([0-9]{1,})/?$";s:55:"index.php?tribe_organizer=$matches[1]&cpage=$matches[2]";s:30:"organizer/([^/]+)(/[0-9]+)?/?$";s:54:"index.php?tribe_organizer=$matches[1]&page=$matches[2]";s:26:"organizer/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"organizer/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"organizer/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"organizer/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"organizer/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:54:"events/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?tribe_events_cat=$matches[1]&feed=$matches[2]";s:49:"events/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?tribe_events_cat=$matches[1]&feed=$matches[2]";s:42:"events/category/(.+?)/page/?([0-9]{1,})/?$";s:56:"index.php?tribe_events_cat=$matches[1]&paged=$matches[2]";s:24:"events/category/(.+?)/?$";s:38:"index.php?tribe_events_cat=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (392, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (399, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (400, '_transient_doing_cron', '1445174980.2983160018920898437500', 'yes') ; 
INSERT INTO `gx_options` VALUES (402, '_site_transient_timeout_theme_roots', '1445176783', 'yes') ; 
INSERT INTO `gx_options` VALUES (403, '_site_transient_theme_roots', 'a:1:{s:8:"gobrenix";s:7:"/themes";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (405, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:3:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:65:"https://downloads.wordpress.org/release/de_CH/wordpress-4.3.1.zip";s:6:"locale";s:5:"de_CH";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:65:"https://downloads.wordpress.org/release/de_CH/wordpress-4.3.1.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.3.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.3.1-new-bundled.zip";s:7:"partial";s:69:"https://downloads.wordpress.org/release/wordpress-4.3.1-partial-0.zip";s:8:"rollback";b:0;}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:3:"4.3";}i:2;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.3.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.3.1-new-bundled.zip";s:7:"partial";s:69:"https://downloads.wordpress.org/release/wordpress-4.3.1-partial-0.zip";s:8:"rollback";s:70:"https://downloads.wordpress.org/release/wordpress-4.3.1-rollback-0.zip";}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:3:"4.3";s:9:"new_files";s:0:"";}}s:12:"last_checked";i:1445174989;s:15:"version_checked";s:3:"4.3";s:12:"translations";a:1:{i:0;a:7:{s:4:"type";s:4:"core";s:4:"slug";s:7:"default";s:8:"language";s:5:"de_CH";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-09 10:05:26";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/de_CH.zip";s:10:"autoupdate";b:1;}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (406, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1445174994;s:7:"checked";a:1:{s:8:"gobrenix";s:3:"1.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (407, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1445174991;s:8:"response";a:6:{s:19:"akismet/akismet.php";O:8:"stdClass":8:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.5";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.5.zip";s:14:"upgrade_notice";s:78:"Version 3.1.5 contains security fixes and is highly recommended for all users.";s:10:"autoupdate";b:1;}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":7:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.3.2";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.3.2.zip";s:14:"upgrade_notice";s:37:"Updates and improvements translations";}s:43:"the-events-calendar/the-events-calendar.php";O:8:"stdClass":6:{s:2:"id";s:5:"11861";s:4:"slug";s:19:"the-events-calendar";s:6:"plugin";s:43:"the-events-calendar/the-events-calendar.php";s:11:"new_version";s:6:"3.12.3";s:3:"url";s:50:"https://wordpress.org/plugins/the-events-calendar/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/the-events-calendar.3.12.3.zip";}s:25:"wp-members/wp-members.php";O:8:"stdClass":6:{s:2:"id";s:5:"10426";s:4:"slug";s:10:"wp-members";s:6:"plugin";s:25:"wp-members/wp-members.php";s:11:"new_version";s:5:"3.0.6";s:3:"url";s:41:"https://wordpress.org/plugins/wp-members/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/wp-members.3.0.6.zip";}s:23:"wp-smushit/wp-smush.php";O:8:"stdClass":6:{s:2:"id";s:4:"5534";s:4:"slug";s:10:"wp-smushit";s:6:"plugin";s:23:"wp-smushit/wp-smush.php";s:11:"new_version";s:7:"2.0.6.3";s:3:"url";s:41:"https://wordpress.org/plugins/wp-smushit/";s:7:"package";s:61:"https://downloads.wordpress.org/plugin/wp-smushit.2.0.6.3.zip";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":6:{s:2:"id";s:4:"5899";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:5:"2.3.5";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/wordpress-seo.2.3.5.zip";}}s:12:"translations";a:0:{}s:9:"no_update";a:7:{s:43:"admin-color-schemes/admin-color-schemes.php";O:8:"stdClass":6:{s:2:"id";s:5:"45554";s:4:"slug";s:19:"admin-color-schemes";s:6:"plugin";s:43:"admin-color-schemes/admin-color-schemes.php";s:11:"new_version";s:3:"2.1";s:3:"url";s:50:"https://wordpress.org/plugins/admin-color-schemes/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/admin-color-schemes.zip";}s:42:"bwp-google-xml-sitemaps/bwp-simple-gxs.php";O:8:"stdClass":6:{s:2:"id";s:5:"21948";s:4:"slug";s:23:"bwp-google-xml-sitemaps";s:6:"plugin";s:42:"bwp-google-xml-sitemaps/bwp-simple-gxs.php";s:11:"new_version";s:5:"1.3.1";s:3:"url";s:54:"https://wordpress.org/plugins/bwp-google-xml-sitemaps/";s:7:"package";s:66:"https://downloads.wordpress.org/plugin/bwp-google-xml-sitemaps.zip";}s:43:"floating-social-bar/floating-social-bar.php";O:8:"stdClass":6:{s:2:"id";s:5:"42494";s:4:"slug";s:19:"floating-social-bar";s:6:"plugin";s:43:"floating-social-bar/floating-social-bar.php";s:11:"new_version";s:5:"1.1.7";s:3:"url";s:50:"https://wordpress.org/plugins/floating-social-bar/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/floating-social-bar.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:32:"login-lockdown/loginlockdown.php";O:8:"stdClass":6:{s:2:"id";s:4:"3760";s:4:"slug";s:14:"login-lockdown";s:6:"plugin";s:32:"login-lockdown/loginlockdown.php";s:11:"new_version";s:6:"v1.6.1";s:3:"url";s:45:"https://wordpress.org/plugins/login-lockdown/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/login-lockdown.1.6.1.zip";}s:25:"sucuri-scanner/sucuri.php";O:8:"stdClass":6:{s:2:"id";s:5:"27199";s:4:"slug";s:14:"sucuri-scanner";s:6:"plugin";s:25:"sucuri-scanner/sucuri.php";s:11:"new_version";s:6:"1.7.13";s:3:"url";s:45:"https://wordpress.org/plugins/sucuri-scanner/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/sucuri-scanner.1.7.13.zip";}s:33:"w3-total-cache/w3-total-cache.php";O:8:"stdClass":7:{s:2:"id";s:4:"9376";s:4:"slug";s:14:"w3-total-cache";s:6:"plugin";s:33:"w3-total-cache/w3-total-cache.php";s:11:"new_version";s:7:"0.9.4.1";s:3:"url";s:45:"https://wordpress.org/plugins/w3-total-cache/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/w3-total-cache.0.9.4.1.zip";s:14:"upgrade_notice";s:140:"Thanks for using W3 Total Cache! This release includes important security updates designed to contribute to a secure WordPress installation.";}}}', 'yes') ;
#
# End of data contents of table gx_options
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `gx_postmeta`
#

DROP TABLE IF EXISTS `gx_postmeta`;


#
# Table structure of table `gx_postmeta`
#

CREATE TABLE `gx_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_postmeta (97 records)
#
 
INSERT INTO `gx_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `gx_postmeta` VALUES (2, 4, '_wp_attached_file', '2015/06/10968747_852590338115812_1938437724_o-1.jpg') ; 
INSERT INTO `gx_postmeta` VALUES (3, 4, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:752;s:4:"file";s:51:"2015/06/10968747_852590338115812_1938437724_o-1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:51:"10968747_852590338115812_1938437724_o-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:51:"10968747_852590338115812_1938437724_o-1-300x110.jpg";s:5:"width";i:300;s:6:"height";i:110;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:52:"10968747_852590338115812_1938437724_o-1-1024x376.jpg";s:5:"width";i:1024;s:6:"height";i:376;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `gx_postmeta` VALUES (4, 4, '_wp_attachment_image_alt', 'Gobrenix Schabe') ; 
INSERT INTO `gx_postmeta` VALUES (5, 1, '_edit_lock', '1434055975:1') ; 
INSERT INTO `gx_postmeta` VALUES (6, 5, '_menu_item_type', 'custom') ; 
INSERT INTO `gx_postmeta` VALUES (7, 5, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `gx_postmeta` VALUES (8, 5, '_menu_item_object_id', '5') ; 
INSERT INTO `gx_postmeta` VALUES (9, 5, '_menu_item_object', 'custom') ; 
INSERT INTO `gx_postmeta` VALUES (10, 5, '_menu_item_target', '') ; 
INSERT INTO `gx_postmeta` VALUES (11, 5, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `gx_postmeta` VALUES (12, 5, '_menu_item_xfn', '') ; 
INSERT INTO `gx_postmeta` VALUES (13, 5, '_menu_item_url', 'http://localhost:88/gobrenix.com/') ; 
INSERT INTO `gx_postmeta` VALUES (15, 6, '_menu_item_type', 'post_type') ; 
INSERT INTO `gx_postmeta` VALUES (16, 6, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `gx_postmeta` VALUES (17, 6, '_menu_item_object_id', '2') ; 
INSERT INTO `gx_postmeta` VALUES (18, 6, '_menu_item_object', 'page') ; 
INSERT INTO `gx_postmeta` VALUES (19, 6, '_menu_item_target', '') ; 
INSERT INTO `gx_postmeta` VALUES (20, 6, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `gx_postmeta` VALUES (21, 6, '_menu_item_xfn', '') ; 
INSERT INTO `gx_postmeta` VALUES (22, 6, '_menu_item_url', '') ; 
INSERT INTO `gx_postmeta` VALUES (24, 2, '_edit_lock', '1434062714:1') ; 
INSERT INTO `gx_postmeta` VALUES (25, 2, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (26, 2, '_yoast_wpseo_focuskw', 'gobrenix,artists,psr,dj,deejay,prog,goa,psy,psytrance,psychadelic,artist') ; 
INSERT INTO `gx_postmeta` VALUES (27, 2, '_yoast_wpseo_title', 'Gobrenix - Artists & Deejays') ; 
INSERT INTO `gx_postmeta` VALUES (28, 2, '_yoast_wpseo_linkdex', '23') ; 
INSERT INTO `gx_postmeta` VALUES (29, 9, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (30, 9, '_edit_lock', '1434066509:1') ; 
INSERT INTO `gx_postmeta` VALUES (31, 9, '_wp_page_template', 'templates/artist.php') ; 
INSERT INTO `gx_postmeta` VALUES (32, 9, '_yoast_wpseo_focuskw', 'si-moon') ; 
INSERT INTO `gx_postmeta` VALUES (33, 9, '_yoast_wpseo_linkdex', '84') ; 
INSERT INTO `gx_postmeta` VALUES (42, 14, '_EventOrigin', 'events-calendar') ; 
INSERT INTO `gx_postmeta` VALUES (43, 14, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (44, 14, '_edit_lock', '1434063533:1') ; 
INSERT INTO `gx_postmeta` VALUES (45, 14, '_EventShowMapLink', '1') ; 
INSERT INTO `gx_postmeta` VALUES (46, 14, '_EventShowMap', '1') ; 
INSERT INTO `gx_postmeta` VALUES (47, 15, '_OrganizerOrigin', 'events-calendar') ; 
INSERT INTO `gx_postmeta` VALUES (48, 15, '_yoast_wpseo_focuskw', 'test') ; 
INSERT INTO `gx_postmeta` VALUES (49, 15, '_OrganizerOrganizer', 'Sandro Gossweiler') ; 
INSERT INTO `gx_postmeta` VALUES (50, 15, '_OrganizerPhone', '') ; 
INSERT INTO `gx_postmeta` VALUES (51, 15, '_OrganizerWebsite', '') ; 
INSERT INTO `gx_postmeta` VALUES (52, 15, '_OrganizerEmail', '') ; 
INSERT INTO `gx_postmeta` VALUES (53, 16, '_VenueOrigin', 'events-calendar') ; 
INSERT INTO `gx_postmeta` VALUES (54, 16, '_yoast_wpseo_focuskw', 'test') ; 
INSERT INTO `gx_postmeta` VALUES (55, 16, '_EventShowMapLink', '1') ; 
INSERT INTO `gx_postmeta` VALUES (56, 16, '_EventShowMap', '1') ; 
INSERT INTO `gx_postmeta` VALUES (57, 16, '_VenueVenue', 'Gobrenix Studios') ; 
INSERT INTO `gx_postmeta` VALUES (58, 16, '_VenueAddress', 'Poststrasse') ; 
INSERT INTO `gx_postmeta` VALUES (59, 16, '_VenueCity', 'Widnau') ; 
INSERT INTO `gx_postmeta` VALUES (60, 16, '_VenueCountry', 'Switzerland') ; 
INSERT INTO `gx_postmeta` VALUES (61, 16, '_VenueProvince', 'St. Gallen') ; 
INSERT INTO `gx_postmeta` VALUES (62, 16, '_VenueState', '') ; 
INSERT INTO `gx_postmeta` VALUES (63, 16, '_VenueZip', '9443') ; 
INSERT INTO `gx_postmeta` VALUES (64, 16, '_VenuePhone', '') ; 
INSERT INTO `gx_postmeta` VALUES (65, 16, '_VenueURL', '') ; 
INSERT INTO `gx_postmeta` VALUES (66, 16, '_VenueStateProvince', 'St. Gallen') ; 
INSERT INTO `gx_postmeta` VALUES (67, 14, '_EventStartDate', '2015-06-20 17:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (68, 14, '_EventEndDate', '2015-06-20 22:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (69, 14, '_EventDuration', '18000') ; 
INSERT INTO `gx_postmeta` VALUES (70, 14, '_EventVenueID', '16') ; 
INSERT INTO `gx_postmeta` VALUES (71, 14, '_EventCurrencySymbol', 'CHF') ; 
INSERT INTO `gx_postmeta` VALUES (72, 14, '_EventCurrencyPosition', 'suffix') ; 
INSERT INTO `gx_postmeta` VALUES (73, 14, '_EventCost', '10') ; 
INSERT INTO `gx_postmeta` VALUES (74, 14, '_EventURL', '') ; 
INSERT INTO `gx_postmeta` VALUES (75, 14, '_EventOrganizerID', '15') ; 
INSERT INTO `gx_postmeta` VALUES (76, 14, '_yoast_wpseo_focuskw', 'test') ; 
INSERT INTO `gx_postmeta` VALUES (77, 14, '_yoast_wpseo_linkdex', '37') ; 
INSERT INTO `gx_postmeta` VALUES (78, 18, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (79, 18, '_edit_lock', '1434066041:1') ; 
INSERT INTO `gx_postmeta` VALUES (80, 18, '_wp_page_template', 'default') ; 
INSERT INTO `gx_postmeta` VALUES (81, 18, '_yoast_wpseo_focuskw', 'links') ; 
INSERT INTO `gx_postmeta` VALUES (82, 18, '_yoast_wpseo_title', 'Gobrenix - Links & References') ; 
INSERT INTO `gx_postmeta` VALUES (83, 18, '_yoast_wpseo_metadesc', 'Some links with references and many more about and from Gobrenix Records directly on their homepage.') ; 
INSERT INTO `gx_postmeta` VALUES (84, 18, '_yoast_wpseo_linkdex', '51') ; 
INSERT INTO `gx_postmeta` VALUES (85, 23, '_wp_attached_file', '2015/06/simoon.jpg') ; 
INSERT INTO `gx_postmeta` VALUES (86, 23, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:7:{s:7:"percent";d:7.0345684812183133516327870893292129039764404296875;s:5:"bytes";i:14375;s:11:"size_before";i:204348;s:10:"size_after";i:189973;s:4:"time";d:0.1600000000000000033306690738754696212708950042724609375;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;}s:5:"sizes";a:3:{s:9:"thumbnail";O:8:"stdClass":5:{s:7:"percent";d:8.25;s:5:"bytes";i:894;s:11:"size_before";i:10840;s:10:"size_after";i:9946;s:4:"time";d:0.0200000000000000004163336342344337026588618755340576171875;}s:6:"medium";O:8:"stdClass":5:{s:7:"percent";d:8.300000000000000710542735760100185871124267578125;s:5:"bytes";i:2154;s:11:"size_before";i:25954;s:10:"size_after";i:23800;s:4:"time";d:0.01000000000000000020816681711721685132943093776702880859375;}s:5:"large";O:8:"stdClass":5:{s:7:"percent";d:6.7599999999999997868371792719699442386627197265625;s:5:"bytes";i:11327;s:11:"size_before";i:167554;s:10:"size_after";i:156227;s:4:"time";d:0.13000000000000000444089209850062616169452667236328125;}}}') ; 
INSERT INTO `gx_postmeta` VALUES (87, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1066;s:4:"file";s:18:"2015/06/simoon.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"simoon-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"simoon-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"simoon-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:15:"Michael Winkler";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:44:"MICWINC • http://facebook.com/micwincphoto";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `gx_postmeta` VALUES (88, 23, '_wp_attachment_image_alt', 'Si-Moon live in Innsbruck') ; 
INSERT INTO `gx_postmeta` VALUES (89, 9, '_thumbnail_id', '23') ; 
INSERT INTO `gx_postmeta` VALUES (90, 26, '_EventOrigin', 'events-calendar') ; 
INSERT INTO `gx_postmeta` VALUES (91, 26, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (92, 26, '_edit_lock', '1441906996:1') ; 
INSERT INTO `gx_postmeta` VALUES (93, 26, '_EventShowMapLink', '1') ; 
INSERT INTO `gx_postmeta` VALUES (94, 26, '_EventShowMap', '1') ; 
INSERT INTO `gx_postmeta` VALUES (95, 26, '_EventStartDate', '2015-09-10 08:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (96, 26, '_EventEndDate', '2015-09-10 17:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (97, 26, '_EventStartDateUTC', '2015-09-10 06:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (98, 26, '_EventEndDateUTC', '2015-09-10 15:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (99, 26, '_EventDuration', '32400') ; 
INSERT INTO `gx_postmeta` VALUES (100, 26, '_EventVenueID', '0') ; 
INSERT INTO `gx_postmeta` VALUES (101, 26, '_EventCurrencySymbol', '') ; 
INSERT INTO `gx_postmeta` VALUES (102, 26, '_EventCurrencyPosition', 'suffix') ; 
INSERT INTO `gx_postmeta` VALUES (103, 26, '_EventCost', '') ; 
INSERT INTO `gx_postmeta` VALUES (104, 26, '_EventURL', '') ; 
INSERT INTO `gx_postmeta` VALUES (105, 26, '_EventOrganizerID', '0') ; 
INSERT INTO `gx_postmeta` VALUES (106, 26, '_EventTimezone', 'Europe/Zurich') ; 
INSERT INTO `gx_postmeta` VALUES (107, 26, '_EventTimezoneAbbr', 'CEST') ;
#
# End of data contents of table gx_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------


#
# Delete any existing table `gx_posts`
#

DROP TABLE IF EXISTS `gx_posts`;


#
# Table structure of table `gx_posts`
#

CREATE TABLE `gx_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_posts (20 records)
#
 
INSERT INTO `gx_posts` VALUES (1, 1, '2015-06-11 19:30:32', '2015-06-11 17:30:32', 'Willkommen zur deutschen Version von WordPress. Dies ist der erste Beitrag. Sie können ihn bearbeiten oder löschen. Um Spam zu vermeiden, gehen Sie doch gleich mal in den Pluginbereich und aktivieren die entsprechenden Plugins.', 'Hallo Welt!', '', 'publish', 'open', 'open', '', 'hallo-welt', '', '', '2015-06-11 19:30:32', '2015-06-11 17:30:32', '', 0, 'http://localhost:88/gobrenix.com/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `gx_posts` VALUES (2, 1, '2015-06-11 19:30:32', '2015-06-11 17:30:32', 'Infos über die Artisten kommen später hierhin :)

[list_children]', 'Artists', '', 'publish', 'open', 'open', '', 'artists', '', '', '2015-06-12 00:18:29', '2015-06-11 22:18:29', '', 0, 'http://localhost:88/gobrenix.com/?page_id=2', 0, 'page', '', 1) ; 
INSERT INTO `gx_posts` VALUES (4, 1, '2015-06-11 21:43:49', '2015-06-11 19:43:49', 'Gobrenix Schabe', 'Gobrenix Schabe', '', 'inherit', 'open', 'open', '', '10968747_852590338115812_1938437724_o-1', '', '', '2015-06-11 21:43:58', '2015-06-11 19:43:58', '', 0, 'http://localhost:88/gobrenix.com/wp-content/uploads/2015/06/10968747_852590338115812_1938437724_o-1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `gx_posts` VALUES (5, 1, '2015-06-11 23:27:15', '2015-06-11 21:27:15', '', 'Home', '', 'publish', 'open', 'open', '', 'startseite', '', '', '2015-06-12 01:53:04', '2015-06-11 23:53:04', '', 0, 'http://localhost:88/gobrenix.com/?p=5', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `gx_posts` VALUES (6, 1, '2015-06-11 23:27:16', '2015-06-11 21:27:16', ' ', '', '', 'publish', 'open', 'open', '', '6', '', '', '2015-06-12 01:53:04', '2015-06-11 23:53:04', '', 0, 'http://localhost:88/gobrenix.com/?p=6', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `gx_posts` VALUES (7, 1, '2015-06-12 00:01:09', '2015-06-11 22:01:09', 'Dies ist ein Beispiel einer statischen Seite. Sie können sie bearbeiten und beispielsweise Infos über Sie oder das Weblog eingeben, damit die Leser wissen, woher Sie kommen und was Sie machen. Sie können entweder beliebig viele Hauptseiten (wie diese hier) oder Unterseiten, die sich in der Hierachiestruktur den Hauptseiten unterordnen, anlegen. Sie können sie auch alle innerhalb von WordPress ändern und verwalten. Als stolzer Besitzer eines neuen WordPress-Blogs, sollten Sie zur Übersichtsseite, dem <a href="http://localhost:88/gobrenix.com/wp-admin/">Dashboard</a> gehen, diese Seite löschen und damit loslegen, eigene Inhalte zu erstellen. Viel Spass!', 'Artists', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-06-12 00:01:09', '2015-06-11 22:01:09', '', 2, 'http://localhost:88/gobrenix.com/2015/06/12/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (8, 1, '2015-06-12 00:01:39', '2015-06-11 22:01:39', 'Infos über die Artisten kommen später hierhin :)', 'Artists', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-06-12 00:01:39', '2015-06-11 22:01:39', '', 2, 'http://localhost:88/gobrenix.com/2015/06/12/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (9, 1, '2015-06-12 00:04:52', '2015-06-11 22:04:52', 'Simon Schneider alias Si-Moon was born on the 15.07.1992 in Swiss. At his first psytrance party in 2008 as he recognized that the powerfull bass wich controled his heartbeat and give him the full boody goose pumps he get addicted to the bass
Since this moment he know what was to do: He need to become a DJ, becouse as a DJ you can control hundert of peoples with your heartbeat and drag them into your powerfull spell of you own crazy fantasies. The People can come with you through your own wonderful fantasy world, where time and matter is no issue, where just you and the music is, to the maximum escalation of your body and mind.

One year ago Si-Moon played his first live act . After this he became quite popular in Swiss and he was booked out every weekend several times. And the curve does not weaken, it rises steeply. Now he plays every weekend in the biggest clubs of switzerland.
The Labehead from PSR, Necmi, heard his liveset and took him directly to the PSR familiy. This was the best was Si-Moon could passing. Becouse this is the label with the same kind uf music.
PSR Music will make a new music era, an music revolution! Now is Simon working very hard on his first ep: "Lets get Dirty" This EP will be out soon. The soundstyle from Si-Moon is indescribably. Its a new kind of Music. Its somethink like aggressive progreesiv fullon with one piece of dubstep elements. He call it by himself "dirty.prog!" He surprised the visitors all the time with new and powerful basslines, and blast them away with the power of his music. When Si-Moon plays at a party, no one will stand around, all are dancing in the spell of his music.', 'Si-Moon', '', 'publish', 'open', 'open', '', 'si-moon', '', '', '2015-06-12 01:49:43', '2015-06-11 23:49:43', '', 2, 'http://localhost:88/gobrenix.com/?page_id=9', 0, 'page', '', 0) ; 
INSERT INTO `gx_posts` VALUES (10, 1, '2015-06-12 00:04:52', '2015-06-11 22:04:52', 'Infos über de Simoooon', 'Si-Moon', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2015-06-12 00:04:52', '2015-06-11 22:04:52', '', 9, 'http://localhost:88/gobrenix.com/2015/06/12/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (11, 1, '2015-06-12 00:18:29', '2015-06-11 22:18:29', 'Infos über die Artisten kommen später hierhin :)

[list_children]', 'Artists', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-06-12 00:18:29', '2015-06-11 22:18:29', '', 2, 'http://localhost:88/gobrenix.com/2015/06/12/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (14, 1, '2015-06-12 01:01:11', '2015-06-11 23:01:11', 'Irgend en inhalt &amp; so ...', 'Test entry', '', 'publish', 'open', 'open', '', 'test-entry', '', '', '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 0, 'http://localhost:88/gobrenix.com/?post_type=tribe_events&#038;p=14', 0, 'tribe_events', '', 0) ; 
INSERT INTO `gx_posts` VALUES (15, 1, '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 'Sandro Gossweiler', '', 'publish', 'open', 'open', '', 'sandro-gossweiler', '', '', '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 0, 'http://localhost:88/gobrenix.com/?post_type=tribe_organizer&#038;p=15', 0, 'tribe_organizer', '', 0) ; 
INSERT INTO `gx_posts` VALUES (16, 1, '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 'Gobrenix Studios', '', 'publish', 'open', 'open', '', 'gobrenix-studios', '', '', '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 0, 'http://localhost:88/gobrenix.com/?post_type=tribe_venue&#038;p=16', 0, 'tribe_venue', '', 0) ; 
INSERT INTO `gx_posts` VALUES (18, 1, '2015-06-12 01:40:16', '2015-06-11 23:40:16', 'Irgendwelchi links links links kömmed do ane - links', 'Links', '', 'publish', 'open', 'open', '', 'links', '', '', '2015-06-12 01:40:16', '2015-06-11 23:40:16', '', 0, 'http://localhost:88/gobrenix.com/?page_id=18', 0, 'page', '', 0) ; 
INSERT INTO `gx_posts` VALUES (19, 1, '2015-06-12 01:40:16', '2015-06-11 23:40:16', 'Irgendwelchi links links links kömmed do ane - links', 'Links', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2015-06-12 01:40:16', '2015-06-11 23:40:16', '', 18, 'http://localhost:88/gobrenix.com/2015/06/12/18-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (21, 1, '2015-06-12 01:44:20', '2015-06-11 23:44:20', 'Simon Schneider alias Si-Moon was born on the 15.07.1992 in Swiss. At his first psytrance party in 2008 as he recognized that the powerfull bass wich controled his heartbeat and give him the full boody goose pumps he get addicted to the bass
Since this moment he know what was to do: He need to become a DJ, becouse as a DJ you can control hundert of peoples with your heartbeat and drag them into your powerfull spell of you own crazy fantasies. The People can come with you through your own wonderful fantasy world, where time and matter is no issue, where just you and the music is, to the maximum escalation of your body and mind. One year ago si -moon played his first live act . After this he became quite popular in Swiss and he was booked out every weekend several times. And the curve does not weaken, it rises steeply. Now he plays every weekend in the biggest clubs of switzerland.
The Labehead from PSR, Necmi, heard his liveset and took him directly to the PSR familiy. This was the best was Si-Moon could passing. Becouse this is the label with the same kind uf music.
PSR Music will make a new music era, an music revolution! Now is Simon working very hard on his first ep: "Lets get Dirty" This EP will be out soon. The soundstyle from Si-Moon is indescribably. Its a new kind of Music. Its somethink like aggressive progreesiv fullon with one piece of dubstep elements. He call it by himself "dirty.prog!" He surprised the visitors all the time with new and powerful basslines, and blast them away with the power of his music. When Si-Moon plays at a party, no one will stand around, all are dancing in the spell of his music.', 'Si-Moon', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2015-06-12 01:44:20', '2015-06-11 23:44:20', '', 9, 'http://localhost:88/gobrenix.com/2015/06/12/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (22, 1, '2015-06-12 01:48:12', '2015-06-11 23:48:12', 'Simon Schneider alias Si-Moon was born on the 15.07.1992 in Swiss. At his first psytrance party in 2008 as he recognized that the powerfull bass wich controled his heartbeat and give him the full boody goose pumps he get addicted to the bass
Since this moment he know what was to do: He need to become a DJ, becouse as a DJ you can control hundert of peoples with your heartbeat and drag them into your powerfull spell of you own crazy fantasies. The People can come with you through your own wonderful fantasy world, where time and matter is no issue, where just you and the music is, to the maximum escalation of your body and mind.

One year ago Si-Moon played his first live act . After this he became quite popular in Swiss and he was booked out every weekend several times. And the curve does not weaken, it rises steeply. Now he plays every weekend in the biggest clubs of switzerland.
The Labehead from PSR, Necmi, heard his liveset and took him directly to the PSR familiy. This was the best was Si-Moon could passing. Becouse this is the label with the same kind uf music.
PSR Music will make a new music era, an music revolution! Now is Simon working very hard on his first ep: "Lets get Dirty" This EP will be out soon. The soundstyle from Si-Moon is indescribably. Its a new kind of Music. Its somethink like aggressive progreesiv fullon with one piece of dubstep elements. He call it by himself "dirty.prog!" He surprised the visitors all the time with new and powerful basslines, and blast them away with the power of his music. When Si-Moon plays at a party, no one will stand around, all are dancing in the spell of his music.', 'Si-Moon', '', 'inherit', 'open', 'open', '', '9-autosave-v1', '', '', '2015-06-12 01:48:12', '2015-06-11 23:48:12', '', 9, 'http://localhost:88/gobrenix.com/2015/06/12/9-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (23, 1, '2015-06-12 01:49:03', '2015-06-11 23:49:03', 'Si-Moon live in Innsbruck', 'Si-Moon live in Innsbruck', 'Si-Moon live in Innsbruck', 'inherit', 'open', 'open', '', 'simoon', '', '', '2015-06-12 01:49:38', '2015-06-11 23:49:38', '', 9, 'http://localhost:88/gobrenix.com/wp-content/uploads/2015/06/simoon.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `gx_posts` VALUES (24, 1, '2015-06-12 01:49:43', '2015-06-11 23:49:43', 'Simon Schneider alias Si-Moon was born on the 15.07.1992 in Swiss. At his first psytrance party in 2008 as he recognized that the powerfull bass wich controled his heartbeat and give him the full boody goose pumps he get addicted to the bass
Since this moment he know what was to do: He need to become a DJ, becouse as a DJ you can control hundert of peoples with your heartbeat and drag them into your powerfull spell of you own crazy fantasies. The People can come with you through your own wonderful fantasy world, where time and matter is no issue, where just you and the music is, to the maximum escalation of your body and mind.

One year ago Si-Moon played his first live act . After this he became quite popular in Swiss and he was booked out every weekend several times. And the curve does not weaken, it rises steeply. Now he plays every weekend in the biggest clubs of switzerland.
The Labehead from PSR, Necmi, heard his liveset and took him directly to the PSR familiy. This was the best was Si-Moon could passing. Becouse this is the label with the same kind uf music.
PSR Music will make a new music era, an music revolution! Now is Simon working very hard on his first ep: "Lets get Dirty" This EP will be out soon. The soundstyle from Si-Moon is indescribably. Its a new kind of Music. Its somethink like aggressive progreesiv fullon with one piece of dubstep elements. He call it by himself "dirty.prog!" He surprised the visitors all the time with new and powerful basslines, and blast them away with the power of his music. When Si-Moon plays at a party, no one will stand around, all are dancing in the spell of his music.', 'Si-Moon', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2015-06-12 01:49:43', '2015-06-11 23:49:43', '', 9, 'http://localhost:88/gobrenix.com/2015/06/12/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (26, 1, '2015-09-10 19:45:35', '2015-09-10 17:45:35', 'With an example description', 'Example Event', '', 'publish', 'open', 'closed', '', 'example-event', '', '', '2015-09-10 19:45:35', '2015-09-10 17:45:35', '', 0, 'http://localhost:88/gobrenix.com/?post_type=tribe_events&#038;p=26', 0, 'tribe_events', '', 0) ;
#
# End of data contents of table gx_posts
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `gx_term_relationships`
#

DROP TABLE IF EXISTS `gx_term_relationships`;


#
# Table structure of table `gx_term_relationships`
#

CREATE TABLE `gx_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_term_relationships (11 records)
#
 
INSERT INTO `gx_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 3, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 4, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 5, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 6, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 7, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 8, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (26, 3, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (26, 4, 0) ;
#
# End of data contents of table gx_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `gx_term_taxonomy`
#

DROP TABLE IF EXISTS `gx_term_taxonomy`;


#
# Table structure of table `gx_term_taxonomy`
#

CREATE TABLE `gx_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_term_taxonomy (8 records)
#
 
INSERT INTO `gx_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ; 
INSERT INTO `gx_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 2) ; 
INSERT INTO `gx_term_taxonomy` VALUES (3, 3, 'tribe_events_cat', '', 0, 2) ; 
INSERT INTO `gx_term_taxonomy` VALUES (4, 4, 'tribe_events_cat', '', 3, 2) ; 
INSERT INTO `gx_term_taxonomy` VALUES (5, 5, 'tribe_events_cat', '', 3, 1) ; 
INSERT INTO `gx_term_taxonomy` VALUES (6, 6, 'tribe_events_cat', '', 3, 1) ; 
INSERT INTO `gx_term_taxonomy` VALUES (7, 7, 'tribe_events_cat', '', 0, 1) ; 
INSERT INTO `gx_term_taxonomy` VALUES (8, 8, 'tribe_events_cat', '', 7, 1) ;
#
# End of data contents of table gx_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_terms`
# --------------------------------------------------------


#
# Delete any existing table `gx_terms`
#

DROP TABLE IF EXISTS `gx_terms`;


#
# Table structure of table `gx_terms`
#

CREATE TABLE `gx_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_terms (8 records)
#
 
INSERT INTO `gx_terms` VALUES (1, 'Allgemein', 'allgemein', 0) ; 
INSERT INTO `gx_terms` VALUES (2, 'Main Menu', 'main-menu', 0) ; 
INSERT INTO `gx_terms` VALUES (3, 'events', 'events', 0) ; 
INSERT INTO `gx_terms` VALUES (4, 'goa', 'goa', 0) ; 
INSERT INTO `gx_terms` VALUES (5, 'concert', 'concert', 0) ; 
INSERT INTO `gx_terms` VALUES (6, 'crew', 'crew', 0) ; 
INSERT INTO `gx_terms` VALUES (7, 'other', 'other', 0) ; 
INSERT INTO `gx_terms` VALUES (8, 'meeting', 'meeting', 0) ;
#
# End of data contents of table gx_terms
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `gx_usermeta`
#

DROP TABLE IF EXISTS `gx_usermeta`;


#
# Table structure of table `gx_usermeta`
#

CREATE TABLE `gx_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_usermeta (26 records)
#
 
INSERT INTO `gx_usermeta` VALUES (1, 1, 'nickname', 'admin') ; 
INSERT INTO `gx_usermeta` VALUES (2, 1, 'first_name', '') ; 
INSERT INTO `gx_usermeta` VALUES (3, 1, 'last_name', '') ; 
INSERT INTO `gx_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `gx_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `gx_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `gx_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `gx_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `gx_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `gx_usermeta` VALUES (10, 1, 'gx_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `gx_usermeta` VALUES (11, 1, 'gx_user_level', '10') ; 
INSERT INTO `gx_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw') ; 
INSERT INTO `gx_usermeta` VALUES (13, 1, 'show_welcome_panel', '0') ; 
INSERT INTO `gx_usermeta` VALUES (15, 1, 'gx_dashboard_quick_press_last_post_id', '25') ; 
INSERT INTO `gx_usermeta` VALUES (17, 1, 'wpseo_ignore_tour', '1') ; 
INSERT INTO `gx_usermeta` VALUES (18, 1, 'wpseo_seen_about_version', '2.3.4') ; 
INSERT INTO `gx_usermeta` VALUES (19, 1, 'gx_user-settings', 'libraryContent=browse&mfold=o&post_dfw=off') ; 
INSERT INTO `gx_usermeta` VALUES (20, 1, 'gx_user-settings-time', '1434060065') ; 
INSERT INTO `gx_usermeta` VALUES (21, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `gx_usermeta` VALUES (22, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `gx_usermeta` VALUES (24, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `gx_usermeta` VALUES (25, 1, 'tribe_setDefaultNavMenuBoxes', '1') ; 
INSERT INTO `gx_usermeta` VALUES (26, 1, 'session_tokens', 'a:1:{s:64:"f47afbdcc9bb256a8cdfb82b2139d1d528955cbdbb6528bfd13296504afb7ad9";a:4:{s:10:"expiration";i:1442079068;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36";s:5:"login";i:1441906268;}}') ; 
INSERT INTO `gx_usermeta` VALUES (27, 1, 'closedpostboxes_dashboard', 'a:0:{}') ; 
INSERT INTO `gx_usermeta` VALUES (28, 1, 'metaboxhidden_dashboard', 'a:2:{i:0;s:22:"tribe_dashboard_widget";i:1;s:21:"dashboard_custom_feed";}') ; 
INSERT INTO `gx_usermeta` VALUES (29, 1, 'wpseo_dismissed_gsc_notice', '1') ;
#
# End of data contents of table gx_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 18. October 2015 13:29 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_users`
# --------------------------------------------------------


#
# Delete any existing table `gx_users`
#

DROP TABLE IF EXISTS `gx_users`;


#
# Table structure of table `gx_users`
#

CREATE TABLE `gx_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_users (1 records)
#
 
INSERT INTO `gx_users` VALUES (1, 'admin', '$P$B8qzwkL9tjirmZ6nspS.cVNRXLyF3P1', 'admin', 'gobrenix@gmail.com', '', '2015-06-11 17:30:32', '', 0, 'admin') ;
#
# End of data contents of table gx_users
# --------------------------------------------------------

