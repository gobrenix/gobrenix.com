# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `gx_commentmeta`
#

DROP TABLE IF EXISTS `gx_commentmeta`;


#
# Table structure of table `gx_commentmeta`
#

CREATE TABLE `gx_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_commentmeta (1 records)
#
 
INSERT INTO `gx_commentmeta` VALUES (2, 2, 'akismet_history', 'a:4:{s:4:"time";d:1434062129.7948729991912841796875;s:5:"event";s:11:"check-error";s:4:"user";s:5:"admin";s:4:"meta";a:1:{s:8:"response";s:7:"invalid";}}') ;
#
# End of data contents of table gx_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------


#
# Delete any existing table `gx_comments`
#

DROP TABLE IF EXISTS `gx_comments`;


#
# Table structure of table `gx_comments`
#

CREATE TABLE `gx_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_comments (2 records)
#
 
INSERT INTO `gx_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-06-11 19:30:32', '2015-06-11 17:30:32', 'Hallo, das hier ist ein Kommentar.<br />Um Kommentare zu bearbeiten, müssen Sie sich anmelden und zur Übersicht der Beiträge gehen. Dort bekommen Sie dann die Gelegenheit sie zu verändern oder zu löschen.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `gx_comments` VALUES (2, 2, 'admin', 'gobrenix@gmail.com', '', '::1', '2015-06-12 00:35:29', '2015-06-11 22:35:29', 'Test Kommentar :)', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36', '', 0, 1) ;
#
# End of data contents of table gx_comments
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------


#
# Delete any existing table `gx_links`
#

DROP TABLE IF EXISTS `gx_links`;


#
# Table structure of table `gx_links`
#

CREATE TABLE `gx_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_links (0 records)
#

#
# End of data contents of table gx_links
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------


#
# Delete any existing table `gx_lockdowns`
#

DROP TABLE IF EXISTS `gx_lockdowns`;


#
# Table structure of table `gx_lockdowns`
#

CREATE TABLE `gx_lockdowns` (
  `lockdown_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lockdown_IP` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`lockdown_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table gx_lockdowns (0 records)
#

#
# End of data contents of table gx_lockdowns
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------


#
# Delete any existing table `gx_login_fails`
#

DROP TABLE IF EXISTS `gx_login_fails`;


#
# Table structure of table `gx_login_fails`
#

CREATE TABLE `gx_login_fails` (
  `login_attempt_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `login_attempt_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_IP` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`login_attempt_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table gx_login_fails (1 records)
#
 
INSERT INTO `gx_login_fails` VALUES (1, 1, '2015-11-15 19:07:02', '::1') ;
#
# End of data contents of table gx_login_fails
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------


#
# Delete any existing table `gx_options`
#

DROP TABLE IF EXISTS `gx_options`;


#
# Table structure of table `gx_options`
#

CREATE TABLE `gx_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=492 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_options (223 records)
#
 
INSERT INTO `gx_options` VALUES (1, 'siteurl', 'http://localhost:88/gobrenix.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (2, 'home', 'http://localhost:88/gobrenix.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (3, 'blogname', 'Gobrenix Productions', 'yes') ; 
INSERT INTO `gx_options` VALUES (4, 'blogdescription', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (5, 'users_can_register', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (6, 'admin_email', 'gobrenix@gmail.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (7, 'start_of_week', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (8, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (9, 'use_smilies', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (10, 'require_name_email', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (11, 'comments_notify', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (12, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `gx_options` VALUES (13, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (14, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (15, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `gx_options` VALUES (16, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `gx_options` VALUES (17, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `gx_options` VALUES (18, 'default_category', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (19, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `gx_options` VALUES (20, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `gx_options` VALUES (21, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `gx_options` VALUES (23, 'date_format', 'j. F Y', 'yes') ; 
INSERT INTO `gx_options` VALUES (24, 'time_format', 'G:i', 'yes') ; 
INSERT INTO `gx_options` VALUES (25, 'links_updated_date_format', 'j. F Y G:i', 'yes') ; 
INSERT INTO `gx_options` VALUES (26, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (27, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes') ; 
INSERT INTO `gx_options` VALUES (29, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (30, 'hack_file', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (31, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `gx_options` VALUES (32, 'moderation_keys', '', 'no') ; 
INSERT INTO `gx_options` VALUES (33, 'active_plugins', 'a:14:{i:0;s:43:"admin-color-schemes/admin-color-schemes.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:43:"floating-social-bar/floating-social-bar.php";i:4;s:9:"hello.php";i:5;s:31:"list-subpages/list-subpages.php";i:6;s:37:"login-customizer/login-customizer.php";i:7;s:32:"login-lockdown/loginlockdown.php";i:8;s:39:"siteorigin-panels/siteorigin-panels.php";i:9;s:25:"sucuri-scanner/sucuri.php";i:10;s:43:"the-events-calendar/the-events-calendar.php";i:11;s:24:"wordpress-seo/wp-seo.php";i:12;s:25:"wp-members/wp-members.php";i:13;s:23:"wp-smushit/wp-smush.php";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `gx_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `gx_options` VALUES (38, 'gmt_offset', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `gx_options` VALUES (41, 'template', 'twentyfifteen', 'yes') ; 
INSERT INTO `gx_options` VALUES (42, 'stylesheet', 'twentyfifteen', 'yes') ; 
INSERT INTO `gx_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `gx_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `gx_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `gx_options` VALUES (49, 'db_version', '33056', 'yes') ; 
INSERT INTO `gx_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `gx_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `gx_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `gx_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `gx_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `gx_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `gx_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `gx_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `gx_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `gx_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `gx_options` VALUES (67, 'image_default_link_type', 'none', 'yes') ; 
INSERT INTO `gx_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `gx_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `gx_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `gx_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `gx_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `gx_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `gx_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (82, 'uninstall_plugins', 'a:1:{s:43:"floating-social-bar/floating-social-bar.php";a:2:{i:0;s:19:"floating_social_bar";i:1;s:9:"uninstall";}}', 'no') ; 
INSERT INTO `gx_options` VALUES (83, 'timezone_string', 'Europe/Zurich', 'yes') ; 
INSERT INTO `gx_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (88, 'initial_db_version', '31535', 'yes') ; 
INSERT INTO `gx_options` VALUES (89, 'gx_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:102:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;s:16:"edit_tribe_event";b:1;s:16:"read_tribe_event";b:1;s:18:"delete_tribe_event";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:24:"edit_others_tribe_events";b:1;s:26:"delete_others_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:27:"delete_private_tribe_events";b:1;s:25:"edit_private_tribe_events";b:1;s:25:"read_private_tribe_events";b:1;s:16:"edit_tribe_venue";b:1;s:16:"read_tribe_venue";b:1;s:18:"delete_tribe_venue";b:1;s:19:"delete_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:24:"edit_others_tribe_venues";b:1;s:26:"delete_others_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:27:"delete_private_tribe_venues";b:1;s:25:"edit_private_tribe_venues";b:1;s:25:"read_private_tribe_venues";b:1;s:20:"edit_tribe_organizer";b:1;s:20:"read_tribe_organizer";b:1;s:22:"delete_tribe_organizer";b:1;s:23:"delete_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;s:28:"edit_others_tribe_organizers";b:1;s:30:"delete_others_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;s:31:"delete_private_tribe_organizers";b:1;s:29:"edit_private_tribe_organizers";b:1;s:29:"read_private_tribe_organizers";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:74:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:16:"edit_tribe_event";b:1;s:16:"read_tribe_event";b:1;s:18:"delete_tribe_event";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:24:"edit_others_tribe_events";b:1;s:26:"delete_others_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:27:"delete_private_tribe_events";b:1;s:25:"edit_private_tribe_events";b:1;s:25:"read_private_tribe_events";b:1;s:16:"edit_tribe_venue";b:1;s:16:"read_tribe_venue";b:1;s:18:"delete_tribe_venue";b:1;s:19:"delete_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:24:"edit_others_tribe_venues";b:1;s:26:"delete_others_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:27:"delete_private_tribe_venues";b:1;s:25:"edit_private_tribe_venues";b:1;s:25:"read_private_tribe_venues";b:1;s:20:"edit_tribe_organizer";b:1;s:20:"read_tribe_organizer";b:1;s:22:"delete_tribe_organizer";b:1;s:23:"delete_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;s:28:"edit_others_tribe_organizers";b:1;s:30:"delete_others_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;s:31:"delete_private_tribe_organizers";b:1;s:29:"edit_private_tribe_organizers";b:1;s:29:"read_private_tribe_organizers";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:34:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:16:"edit_tribe_event";b:1;s:16:"read_tribe_event";b:1;s:18:"delete_tribe_event";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:16:"edit_tribe_venue";b:1;s:16:"read_tribe_venue";b:1;s:18:"delete_tribe_venue";b:1;s:19:"delete_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:20:"edit_tribe_organizer";b:1;s:20:"read_tribe_organizer";b:1;s:22:"delete_tribe_organizer";b:1;s:23:"delete_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:20:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:16:"edit_tribe_event";b:1;s:16:"read_tribe_event";b:1;s:18:"delete_tribe_event";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:16:"edit_tribe_venue";b:1;s:16:"read_tribe_venue";b:1;s:18:"delete_tribe_venue";b:1;s:19:"delete_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:20:"edit_tribe_organizer";b:1;s:20:"read_tribe_organizer";b:1;s:22:"delete_tribe_organizer";b:1;s:23:"delete_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:5:{s:4:"read";b:1;s:7:"level_0";b:1;s:16:"read_tribe_event";b:1;s:20:"read_tribe_organizer";b:1;s:16:"read_tribe_venue";b:1;}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (90, 'WPLANG', 'de_CH', 'yes') ; 
INSERT INTO `gx_options` VALUES (91, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (92, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (93, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (94, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (95, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (96, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:18:"orphaned_widgets_1";N;s:18:"orphaned_widgets_2";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (98, 'cron', 'a:7:{i:1447625071;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1447626929;a:1:{s:24:"akismet_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1447650900;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1447651832;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1447695058;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1447797600;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"bac2a2be1c518053b1f7bf98ae752a19";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:1:{s:2:"id";s:10:"1434052171";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (107, '_transient_random_seed', '6b560183cff472ce85c4d104f6f424fd', 'yes') ; 
INSERT INTO `gx_options` VALUES (127, '_transient_timeout_plugin_slugs', '1445270513', 'no') ; 
INSERT INTO `gx_options` VALUES (128, '_transient_plugin_slugs', 'a:16:{i:0;s:43:"admin-color-schemes/admin-color-schemes.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:42:"bwp-google-xml-sitemaps/bwp-simple-gxs.php";i:4;s:37:"login-customizer/login-customizer.php";i:5;s:43:"floating-social-bar/floating-social-bar.php";i:6;s:9:"hello.php";i:7;s:31:"list-subpages/list-subpages.php";i:8;s:32:"login-lockdown/loginlockdown.php";i:9;s:39:"siteorigin-panels/siteorigin-panels.php";i:10;s:25:"sucuri-scanner/sucuri.php";i:11;s:43:"the-events-calendar/the-events-calendar.php";i:12;s:33:"w3-total-cache/w3-total-cache.php";i:13;s:25:"wp-members/wp-members.php";i:14;s:23:"wp-smushit/wp-smush.php";i:15;s:24:"wordpress-seo/wp-seo.php";}', 'no') ; 
INSERT INTO `gx_options` VALUES (133, 'current_theme', 'Twenty Fifteen', 'yes') ; 
INSERT INTO `gx_options` VALUES (134, 'theme_mods_gobrenix', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1445175713;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (135, 'theme_switched', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (136, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (137, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (139, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (140, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (144, '_transient__mbbasetheme_categories', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (147, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `gx_options` VALUES (158, 'fsb_global_option', 'a:9:{s:8:"services";a:5:{s:8:"linkedin";a:1:{s:2:"on";b:0;}s:9:"pinterest";a:1:{s:2:"on";b:0;}s:8:"facebook";a:2:{s:2:"on";b:1;s:5:"order";i:0;}s:7:"twitter";a:2:{s:2:"on";b:1;s:5:"order";i:1;}s:6:"google";a:2:{s:2:"on";b:1;s:5:"order";i:2;}}s:5:"label";s:0:"";s:7:"show_on";a:1:{i:0;s:4:"post";}s:7:"twitter";s:0:"";s:9:"transient";i:1800;s:7:"pinback";s:0:"";s:6:"static";i:0;s:8:"position";s:5:"above";s:9:"socialite";i:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (159, 'loginlockdownAdminOptions', 'a:6:{s:17:"max_login_retries";s:1:"3";s:14:"retries_within";s:1:"5";s:14:"lockout_length";s:2:"60";s:25:"lockout_invalid_usernames";s:2:"no";s:17:"mask_login_errors";s:2:"no";s:16:"show_credit_link";s:2:"no";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (160, 'loginlockdown_db_version', '1.0', 'no') ; 
INSERT INTO `gx_options` VALUES (161, 'wpseo', 'a:20:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:7:"version";s:5:"2.3.5";s:11:"alexaverify";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (162, 'wpseo_permalinks', 'a:13:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (163, 'wpseo_titles', 'a:54:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:1;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (164, 'wpseo_social', 'a:21:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"296b130d5ffbca1916a049f28a5b2c75";s:13:"facebook_site";s:33:"https://www.facebook.com/gobrenix";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:20:"Gobrenix Productions";s:17:"og_frontpage_desc";s:78:"This is Gobrenix Records, the leading Goa & Progressive label from swizterland";s:18:"og_frontpage_image";s:103:"http://localhost:88/gobrenix.com/wp-content/uploads/2015/06/10968747_852590338115812_1938437724_o-1.jpg";s:9:"opengraph";b:1;s:10:"googleplus";b:0;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (165, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (166, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:2:"»";s:23:"post_types-post-maintax";i:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (167, 'wpseo_xml', 'a:15:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (168, 'wpmembers_settings', 'a:28:{i:0;s:13:"WPMEM_VERSION";i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;s:1:"1";i:7;i:0;i:8;i:0;i:9;i:0;i:10;i:0;i:11;i:0;s:7:"version";s:5:"3.0.4";s:5:"block";a:2:{s:4:"post";i:0;s:4:"page";i:0;}s:12:"show_excerpt";a:2:{s:4:"post";i:0;s:4:"page";i:0;}s:8:"show_reg";a:2:{s:4:"post";i:1;s:4:"page";i:1;}s:10:"show_login";a:2:{s:4:"post";i:1;s:4:"page";i:1;}s:6:"notify";i:0;s:7:"mod_reg";i:0;s:7:"captcha";s:1:"1";s:7:"use_exp";i:0;s:9:"use_trial";i:0;s:8:"warnings";i:0;s:10:"user_pages";a:3:{s:7:"profile";s:0:"";s:8:"register";s:0:"";s:5:"login";s:0:"";}s:6:"cssurl";b:0;s:5:"style";s:87:"http://localhost:88/gobrenix.com/wp-content/plugins/wp-members/css/generic-no-float.css";s:6:"autoex";a:2:{s:7:"auto_ex";i:0;s:11:"auto_ex_len";s:0:"";}s:6:"attrib";s:1:"0";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (169, 'wpmembers_fields', 'a:16:{i:0;a:7:{i:0;i:1;i:1;s:10:"First Name";i:2;s:10:"first_name";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:1;a:7:{i:0;i:2;i:1;s:9:"Last Name";i:2;s:9:"last_name";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:2;a:7:{i:0;i:3;i:1;s:9:"Address 1";i:2;s:5:"addr1";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:3;a:7:{i:0;i:4;i:1;s:9:"Address 2";i:2;s:5:"addr2";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"n";i:6;s:1:"n";}i:4;a:7:{i:0;i:5;i:1;s:4:"City";i:2;s:4:"city";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:5;a:7:{i:0;i:6;i:1;s:5:"State";i:2;s:8:"thestate";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:6;a:7:{i:0;i:7;i:1;s:3:"Zip";i:2;s:3:"zip";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:7;a:7:{i:0;i:8;i:1;s:7:"Country";i:2;s:7:"country";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:8;a:7:{i:0;i:9;i:1;s:9:"Day Phone";i:2;s:6:"phone1";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:9;a:7:{i:0;i:10;i:1;s:5:"Email";i:2;s:10:"user_email";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:10;a:7:{i:0;i:11;i:1;s:13:"Confirm Email";i:2;s:13:"confirm_email";i:3;s:4:"text";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:11;a:7:{i:0;i:12;i:1;s:7:"Website";i:2;s:8:"user_url";i:3;s:4:"text";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"y";}i:12;a:7:{i:0;i:13;i:1;s:17:"Biographical Info";i:2;s:11:"description";i:3;s:8:"textarea";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"y";}i:13;a:7:{i:0;i:14;i:1;s:8:"Password";i:2;s:8:"password";i:3;s:8:"password";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:14;a:7:{i:0;i:15;i:1;s:16:"Confirm Password";i:2;s:16:"confirm_password";i:3;s:8:"password";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:15;a:9:{i:0;i:16;i:1;s:3:"TOS";i:2;s:3:"tos";i:3;s:8:"checkbox";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";i:7;s:5:"agree";i:8;s:1:"n";}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (170, 'wpmembers_dialogs', 'a:9:{i:0;s:119:"This content is restricted to site members.  If you are an existing user, please log in.  New users may register below.";i:1;s:50:"Sorry, that username is taken, please try another.";i:2;s:74:"Sorry, that email address already has an account.<br />Please try another.";i:3;s:124:"Congratulations! Your registration was successful.<br /><br />You may now log in using the password that was emailed to you.";i:4;s:29:"Your information was updated!";i:5;s:53:"Passwords did not match.<br /><br />Please try again.";i:6;s:30:"Password successfully changed!";i:7;s:65:"Either the username or email address do not exist in our records.";i:8;s:135:"Password successfully reset!<br /><br />An email containing a new password has been sent to the email address on file for your account.";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (171, 'wpmembers_tos', 'Put your TOS (Terms of Service) text here.  You can use HTML markup.', 'yes') ; 
INSERT INTO `gx_options` VALUES (172, 'wpmembers_email_newreg', 'a:2:{s:4:"subj";s:37:"Your registration info for [blogname]";s:4:"body";s:268:"Thank you for registering for [blogname]

Your registration information is below.
You may wish to retain a copy for your records.

username: [username]
password: [password]

You may login here:
[reglink]

You may change your password here:
[members-area]
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (173, 'wpmembers_email_newmod', 'a:2:{s:4:"subj";s:40:"Thank you for registering for [blogname]";s:4:"body";s:173:"Thank you for registering for [blogname]. 
Your registration has been received and is pending approval.
You will receive login instructions upon approval of your account
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (174, 'wpmembers_email_appmod', 'a:2:{s:4:"subj";s:50:"Your registration for [blogname] has been approved";s:4:"body";s:299:"Your registration for [blogname] has been approved.

Your registration information is below.
You may wish to retain a copy for your records.

username: [username]
password: [password]

You may login and change your password here:
[members-area]

You originally registered at:
[reglink]
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (175, 'wpmembers_email_repass', 'a:2:{s:4:"subj";s:34:"Your password reset for [blogname]";s:4:"body";s:157:"Your password for [blogname] has been reset

Your new password is included below. You may wish to retain a copy for your records.

password: [password]
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (176, 'wpmembers_email_notify', 'a:2:{s:4:"subj";s:36:"New user registration for [blogname]";s:4:"body";s:196:"The following user registered for [blogname]:
	
username: [username]
email: [email]

[fields]
This user registered here:
[reglink]

user IP: [user-ip]
	
activate user: [activate-user]
";}', 'no') ; 
INSERT INTO `gx_options` VALUES (177, 'wpmembers_email_footer', '----------------------------------
This is an automated message from [blogname]
Please do not reply to this address', 'no') ; 
INSERT INTO `gx_options` VALUES (178, 'wpmembers_style', 'http://localhost:88/gobrenix.com/wp-content/plugins/wp-members/css/generic-no-float.css', 'yes') ; 
INSERT INTO `gx_options` VALUES (180, 'sucuriscan_datastore_path', '/Applications/MAMP/htdocs/gobrenix.com/wp-content/uploads/sucuri', 'yes') ; 
INSERT INTO `gx_options` VALUES (183, '_transient_yoast_i18n_wordpress-seo_promo_hide', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (188, 'sucuriscan_emails_sent', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (189, 'sucuriscan_last_email_at', '1447610823', 'yes') ; 
INSERT INTO `gx_options` VALUES (203, 'wpmembers_attrib', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (204, 'wpmembers_msurl', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (205, 'wpmembers_regurl', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (206, 'wpmembers_logurl', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (207, 'wpmembers_autoex', 'a:2:{s:7:"auto_ex";i:0;s:11:"auto_ex_len";s:0:"";}', 'no') ; 
INSERT INTO `gx_options` VALUES (215, 'hmbkp_schedule_1434052171', 'a:5:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:6:"weekly";s:19:"schedule_start_time";d:1434492000;s:11:"max_backups";i:7;s:5:"email";a:1:{s:5:"email";s:18:"gobrenix@gmail.com";}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (217, 'hmbkp_plugin_version', '3.3.2', 'yes') ; 
INSERT INTO `gx_options` VALUES (228, 'hmbkp_notices', 'a:1:{s:13:"backup_errors";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (229, 'hmbkp_schedule_1434052240', 'a:7:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:8:"manually";s:5:"email";a:1:{s:5:"email";s:18:"gobrenix@gmail.com";}s:11:"max_backups";i:2;s:8:"excludes";a:85:{i:0;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:1;s:5:".git/";i:2;s:5:".svn/";i:3;s:9:".DS_Store";i:4;s:6:".idea/";i:5;s:10:"backwpup-*";i:6;s:7:"updraft";i:7;s:12:"wp-snapshots";i:8;s:19:"backupbuddy_backups";i:9;s:14:"pb_backupbuddy";i:10;s:9:"backup-db";i:11;s:14:"Envato-backups";i:12;s:8:"managewp";i:13;s:25:"backupwordpress-*-backups";i:14;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:15;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:16;s:5:".git/";i:17;s:5:".svn/";i:18;s:9:".DS_Store";i:19;s:6:".idea/";i:20;s:10:"backwpup-*";i:21;s:7:"updraft";i:22;s:12:"wp-snapshots";i:23;s:19:"backupbuddy_backups";i:24;s:14:"pb_backupbuddy";i:25;s:9:"backup-db";i:26;s:14:"Envato-backups";i:27;s:8:"managewp";i:28;s:25:"backupwordpress-*-backups";i:29;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:30;s:59:"/Applications/MAMP/htdocs/gobrenix.com/wp-config-sample.php";i:31;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:32;s:5:".git/";i:33;s:5:".svn/";i:34;s:9:".DS_Store";i:35;s:6:".idea/";i:36;s:10:"backwpup-*";i:37;s:7:"updraft";i:38;s:12:"wp-snapshots";i:39;s:19:"backupbuddy_backups";i:40;s:14:"pb_backupbuddy";i:41;s:9:"backup-db";i:42;s:14:"Envato-backups";i:43;s:8:"managewp";i:44;s:25:"backupwordpress-*-backups";i:45;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:46;s:59:"/Applications/MAMP/htdocs/gobrenix.com/wp-config-sample.php";i:47;s:52:"/Applications/MAMP/htdocs/gobrenix.com/liesmich.html";i:48;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:49;s:5:".git/";i:50;s:5:".svn/";i:51;s:9:".DS_Store";i:52;s:6:".idea/";i:53;s:10:"backwpup-*";i:54;s:7:"updraft";i:55;s:12:"wp-snapshots";i:56;s:19:"backupbuddy_backups";i:57;s:14:"pb_backupbuddy";i:58;s:9:"backup-db";i:59;s:14:"Envato-backups";i:60;s:8:"managewp";i:61;s:25:"backupwordpress-*-backups";i:62;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:63;s:59:"/Applications/MAMP/htdocs/gobrenix.com/wp-config-sample.php";i:64;s:52:"/Applications/MAMP/htdocs/gobrenix.com/liesmich.html";i:65;s:50:"/Applications/MAMP/htdocs/gobrenix.com/readme.html";i:66;s:85:"/Applications/MAMP/htdocs/gobrenix.com/wp-content/backupwordpress-956cf6fb25-backups/";i:67;s:5:".git/";i:68;s:5:".svn/";i:69;s:9:".DS_Store";i:70;s:6:".idea/";i:71;s:10:"backwpup-*";i:72;s:7:"updraft";i:73;s:12:"wp-snapshots";i:74;s:19:"backupbuddy_backups";i:75;s:14:"pb_backupbuddy";i:76;s:9:"backup-db";i:77;s:14:"Envato-backups";i:78;s:8:"managewp";i:79;s:25:"backupwordpress-*-backups";i:80;s:51:"/Applications/MAMP/htdocs/gobrenix.com/wp-includes/";i:81;s:59:"/Applications/MAMP/htdocs/gobrenix.com/wp-config-sample.php";i:82;s:52:"/Applications/MAMP/htdocs/gobrenix.com/liesmich.html";i:83;s:50:"/Applications/MAMP/htdocs/gobrenix.com/readme.html";i:84;s:48:"/Applications/MAMP/htdocs/gobrenix.com/README.md";}s:14:"duration_total";i:1;s:16:"backup_run_count";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (239, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (246, 'widget_akismet_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (247, 'widget_widget_wpmemwidget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (263, 'tribe_events_calendar_options', 'a:33:{s:27:"recurring_events_are_hidden";s:6:"hidden";s:19:"tribeEventsTemplate";s:20:"templates/events.php";s:21:"tribeEventsBeforeHTML";s:0:"";s:20:"tribeEventsAfterHTML";s:0:"";s:21:"previous_ecp_versions";a:3:{i:0;s:1:"0";i:1;s:5:"3.9.3";i:2;s:6:"3.12.1";}s:18:"latest_ecp_version";s:6:"3.12.3";s:10:"viewOption";s:4:"list";s:11:"donate-link";b:0;s:12:"postsPerPage";s:1:"5";s:17:"liveFiltersUpdate";b:1;s:12:"showComments";b:0;s:20:"showEventsInMainLoop";b:0;s:10:"eventsSlug";s:6:"events";s:15:"singleEventSlug";s:5:"event";s:14:"multiDayCutoff";s:5:"00:00";s:21:"defaultCurrencySymbol";s:3:"CHF";s:23:"reverseCurrencyPosition";b:1;s:15:"embedGoogleMaps";b:1;s:19:"embedGoogleMapsZoom";s:2:"15";s:11:"debugEvents";b:0;s:16:"stylesheetOption";s:5:"tribe";s:16:"tribeEnableViews";a:3:{i:0;s:4:"list";i:1;s:5:"month";i:2;s:3:"day";}s:20:"tribeDisableTribeBar";b:0;s:16:"monthEventAmount";s:1:"3";s:18:"dateWithYearFormat";s:6:"j. F Y";s:21:"dateWithoutYearFormat";s:3:"F j";s:18:"monthAndYearFormat";s:3:"F Y";s:17:"dateTimeSeparator";s:3:" @ ";s:18:"timeRangeSeparator";s:3:" - ";s:16:"datepickerFormat";s:1:"4";s:13:"earliest_date";s:19:"2015-06-20 17:00:00";s:11:"latest_date";s:19:"2015-09-10 17:00:00";s:14:"schema-version";s:6:"3.12.3";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (264, 'tribe_events_db_version', '3.0.0', 'yes') ; 
INSERT INTO `gx_options` VALUES (266, 'tribe_events_suite_versions', 'a:1:{s:19:"TribeEventsCalendar";s:5:"3.9.3";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (269, 'tribe_last_save_post', '1447610840', 'yes') ; 
INSERT INTO `gx_options` VALUES (276, 'tribe_events_cat_children', 'a:2:{i:3;a:3:{i:0;i:4;i:1;i:5;i:2;i:6;}i:7;a:1:{i:0;i:8;}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (314, 'bwp_gxs_generator', 'a:1:{s:15:"input_cache_dir";s:0:"";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (315, 'bwp_gxs_version', '1.3.1', 'yes') ; 
INSERT INTO `gx_options` VALUES (316, 'bwp_gxs_log', 'a:2:{s:3:"log";a:0:{}s:7:"sitemap";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (328, 'dismiss_smush_upgrade', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (329, 'sucuriscan_ads_visibility', 'disabled', 'yes') ; 
INSERT INTO `gx_options` VALUES (377, 'akismet_strictness', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (378, 'akismet_show_user_comments_approved', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (379, 'wordpress_api_key', '4055b30fa7f6', 'yes') ; 
INSERT INTO `gx_options` VALUES (380, 'widget_tribe-events-list-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (387, 'finished_splitting_shared_terms', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (388, 'db_upgraded', '', 'yes') ; 
INSERT INTO `gx_options` VALUES (408, '_transient_timeout_online_users', '1445176796', 'no') ; 
INSERT INTO `gx_options` VALUES (409, '_transient_online_users', 'a:1:{i:0;a:6:{s:7:"user_id";i:1;s:10:"user_login";s:5:"admin";s:10:"user_email";s:18:"gobrenix@gmail.com";s:15:"user_registered";s:19:"2015-06-11 17:30:32";s:13:"last_activity";d:1445182196;s:11:"remote_addr";s:9:"127.0.0.1";}}', 'no') ; 
INSERT INTO `gx_options` VALUES (410, '_site_transient_timeout_browser_59e1bf35cf0392879abcbbfedc8d5a29', '1445779797', 'yes') ; 
INSERT INTO `gx_options` VALUES (411, '_site_transient_browser_59e1bf35cf0392879abcbbfedc8d5a29', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"46.0.2490.71";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (412, '_transient_timeout_feed_0d102f2a1f4d6bc90eb8c6ffe18e56ed', '1445218199', 'no') ; 
INSERT INTO `gx_options` VALUES (413, '_transient_feed_0d102f2a1f4d6bc90eb8c6ffe18e56ed', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"The Events Calendar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:29:"https://theeventscalendar.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress event plugins for people who kick ass";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 18 Oct 2015 12:36:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"The Events Calendar 4.0: Beta Testers Wanted";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"https://theeventscalendar.com/the-events-calendar-4-0-beta-testers-wanted/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"https://theeventscalendar.com/the-events-calendar-4-0-beta-testers-wanted/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 16 Oct 2015 22:49:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1015451";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:582:"<p>The major 4.0 release of The Events Calendar is coming soon, and we&#8217;re looking for readers like you to sign up and help us test the Beta version! There are too many awesome changes coming in the 4.0 release to list them all here. Some are still top-secret at this time — but hey, if you&#8217;re&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/the-events-calendar-4-0-beta-testers-wanted/">The Events Calendar 4.0: Beta Testers Wanted</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"George";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2270:"<p>The major 4.0 release of The Events Calendar is coming soon, and we&#8217;re looking for readers like <strong>you</strong> to sign up and help us test the Beta version!</p>
<p>There are too many awesome changes coming in the 4.0 release to list them all here. Some are still top-secret at this time — but hey, if you&#8217;re curious about 4.0 and want an early peek at all the new features, that&#8217;s all the more reason to <a href="http://theeventscalendar.com/knowledgebase/signup-for-beta-access/" target="_blank">sign up to participate in the 4.0 Beta Test</a>!</p>
<h4>Signing Up and Participating</h4>
<p>You can sign up for the beta by <a href="https://theeventscalendar.com/knowledgebase/signup-for-beta-access/">filling out this form</a>. We&#8217;ll hit you up via email when the testing actually begins, which is tentatively set for late-October or early-November.</p>
<p>This round of beta testing should be quite simple. Once we have a large enough pool of testers, the actual <em>testing</em> will proceed in the following phases:</p>
<ul>
<li><strong>Phase 1: Code launch.</strong> We will start, of course, by sharing the new code with you.</li>
<li><strong>Phase 2: Feedback period.</strong> You will have open access to a forum where you can post feedback, questions and comments about the 4.0 code and your experience with it.</li>
<li><strong>Phase 3: Wrap-up. </strong>This is where we&#8217;ll close the forum and start following up on the feedback that was collected.</li>
</ul>
<h4>Great, but what&#8217;s in it for me?</h4>
<p>Because it means a lot to us. And you get a better product. And you get a sneak peak at what&#8217;s coming.</p>
<p>Oh, and we&#8217;ll totally hook you up with coupons and other goodies for especially insightful bug reports and feedback you provide during the feedback phase.</p>
<p><strong><a href="http://theeventscalendar.com/knowledgebase/signup-for-beta-access/" target="_blank">Ready to sign up? Click here to do so!</a></strong></p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/the-events-calendar-4-0-beta-testers-wanted/">The Events Calendar 4.0: Beta Testers Wanted</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"https://theeventscalendar.com/the-events-calendar-4-0-beta-testers-wanted/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Release: Events Calendar PRO 3.12.4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"https://theeventscalendar.com/release-events-calendar-pro-3-12-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"https://theeventscalendar.com/release-events-calendar-pro-3-12-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 Oct 2015 23:09:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1015113";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:591:"<p>You may have seen we released Events Calendar PRO 3.12.3 earlier today. Hot on its heels, we&#8217;ve just followed that up with a minor version 3.12.4 update that all users are encouraged to apply to their sites. Here&#8217;s what we fixed in Events Calendar PRO 3.12.4: Altered our build process to remove utilities and libraries&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-events-calendar-pro-3-12-4/">Release: Events Calendar PRO 3.12.4</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:3:"Rob";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1177:"<p>You may have seen we released <a href="https://theeventscalendar.com/release-the-events-calendar-pro-3-12-3/">Events Calendar PRO 3.12.3</a> earlier today. Hot on its heels, we&#8217;ve just followed that up with a minor <strong>version 3.12.4</strong> update that all users are encouraged to apply to their sites.</p>
<p><strong>Here&#8217;s what we fixed in Events Calendar PRO 3.12.4:</strong></p>
<ul>
<li>Altered our build process to remove utilities and libraries not needed in the finished product, some of which accidentally shipped in 3.12.3 <em>(thanks to Jay on the forums for the heads up!)</em></li>
</ul>
<p>Whether you&#8217;re still on 3.12.2 or one of the few folks who updated to 3.12.3 while it was still in the wild &#8211; this version is the latest and greatest. As always, <a href="http://theeventscalendar.com/support/forums/">let us know on the forums</a> if you have any problems. Happy updating!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-events-calendar-pro-3-12-4/">Release: Events Calendar PRO 3.12.4</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"https://theeventscalendar.com/release-events-calendar-pro-3-12-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Release: The Events Calendar PRO 3.12.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://theeventscalendar.com/release-the-events-calendar-pro-3-12-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"https://theeventscalendar.com/release-the-events-calendar-pro-3-12-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 Oct 2015 14:26:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1014258";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:587:"<p>Hey folks! The Events Calendar PRO 3.12.3 is fresh off the grill and ready for your site. Bon appetite! The last version had a few bugs that we weren&#8217;t happy living with, so we&#8217;ve squashed them and now have a much better taste in mouths as we continue to bake The Events Calendar 4.0. Here&#8217;s what we&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-pro-3-12-3/">Release: The Events Calendar PRO 3.12.3</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2266:"<p>Hey folks! The Events Calendar PRO 3.12.3 is fresh off the grill and ready for your site. <em>Bon appetite!</em></p>
<p>The last version had a few bugs that we weren&#8217;t happy living with, so we&#8217;ve squashed them and now have a much better taste in mouths as we <a href="https://theeventscalendar.com/upcoming-release-events-calendar-4-0/">continue to bake The Events Calendar 4.0</a>.</p>
<p><strong>Here&#8217;s what we fixed in The Events Calendar PRO 3.12.3:</strong></p>
<ul>
<li>Fixed a bug to ensure date exclusion was being respected when creating recurring events (thanks to laughmasters, Nadia, Andreas and Jeff for noting this in the forums)</li>
<li>Fixed a bug that made the event list and mini calendar widget show wrong date in Date Box due to<em> time()</em> function (thank you Seth in the support forums for this one)</li>
<li>Fixed a bug that resulted in custom recurring events showing wrong times and have PHP notices (Sitecrafting &#8211; thank you for the report on this one)</li>
<li>Fixed an issue with 24-hour format for WordPress which was resulting in bugs related to Meridian.</li>
<li>Simplified information related to recurring events in tooltip (Thanks to David and mmccoycchs for highlighting this)</li>
<li>Fixed a bug that occurred when a recurring events created before 3.12 resulted in the primary event not displaying as recurring</li>
</ul>
<p>As always, we wish you happy updating! Please do be sure to update safely and <a href="https://codex.wordpress.org/WordPress_Backups">create backups of your files and databases</a> as you would do for any other update. We expect smooth sailing if you are already using The Events Calendar PRO 3.12 or greater. If you&#8217;re running something lower than 3.12, please do <a href="https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/">see what changed in that release</a> prior to updating and update in a test environment if you can, as there were significant changes.</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-pro-3-12-3/">Release: The Events Calendar PRO 3.12.3</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"https://theeventscalendar.com/release-the-events-calendar-pro-3-12-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Join Modern Tribe’s QA team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://theeventscalendar.com/join-modern-tribes-qa-team/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"https://theeventscalendar.com/join-modern-tribes-qa-team/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 Oct 2015 23:14:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"Gigs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1014327";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:560:"<p>Modern Tribe’s QA team works on a lot of cool projects: over the past year alone, we’ve tested sites built by our dev team for big-name clients including Stanford Law School, Bon Appetit Magazine, MIT, Harvard Law School + Urban Movie Channel. (Want to see how we did? The links above highlight some of our&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/join-modern-tribes-qa-team/">Join Modern Tribe&#8217;s QA team</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:3:"Rob";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:7212:"<p>Modern Tribe’s QA team works on a lot of cool projects: over the past year alone, we’ve tested sites built by our dev team for big-name clients including <a href="https://law.stanford.edu/">Stanford Law School</a>, Bon Appetit Magazine, <a href="http://sloanreview.mit.edu/">MIT</a>, <a href="http://hls.harvard.edu/">Harvard Law School</a> + <a href="https://urbanmoviechannel.com/">Urban Movie Channel</a>. (Want to see how we did? The links above highlight some of our work). And that&#8217;s not even including our family of WordPress plugins led by <a href="https://wordpress.org/plugins/the-events-calendar/">The Events Calendar</a>.</p>
<p>We’ve got a slew of cool projects on the docket for 2016, and need another member for our QA team. If working on high-profile sites for large clients gets you excited and a serious case of attention to detail is your jam, we should talk.</p>
<h2>Details About the QA Gig</h2>
<p>QA is responsible for ensuring all aspects of quality at Modern Tribe. It&#8217;s a tall order for sure: learning how a site works, creating test plans covering obscure use cases, and then putting it all into practice when testing every aspect of site functionality&#8230;it&#8217;s a lot of ground to cover. But we&#8217;ve got an established workflow down that helps make sure we&#8217;re setting the team up with the tools they need to proceed and succeed.</p>
<p>Though every project is different, here&#8217;s the gist of our QA flow:</p>
<ol>
<li><strong>Kickoff meeting.</strong> Just a kickoff — meet the PM; get your questions answered; set expectations; and schedule milestones.</li>
<li><strong>Preparing docs.</strong> Getting started with internal documentation early is hugely important to getting the project into your brain.</li>
<li><strong>Review approved comps.</strong> Before you start QA or even get a walkthrough, you&#8217;ll review the comps to understand the project + prepare a list of questions to ask on the QA walkthrough.</li>
<li><strong>QA walkthrough.</strong> Once development is far enough along for QA to begin, you’ll do a walkthrough with the lead developer to get an overview of the functionality.</li>
<li><strong>Prepare QA checklist + test plan.</strong> After seeing each component of the site in action, you’ll put together a first draft at a comprehensive QA checklist and a higher-level overview of what you&#8217;re planning to test, in what order, and when.</li>
<li><strong>Heavy duty testing.</strong> You’ll put the site through its paces and give it a few rounds of full pass bug hunting. Beyond just hitting buttons, you’ll be thinking from a higher level: are there usability concerns? Does what we’re doing here actually make sense as the best way to solve the problem? etc.</li>
<li><strong>Celebrating a successful launch.</strong> What feels better than kicking back after a successful launch? If QA has done their job, the project will launch smoothly, the team will have a finished product to show off, and — most importantly — the client will be happy. It doesn’t get much better than that.</li>
</ol>
<p>Our QA team also generally leads client training and prepares training documentation/videos when appropriate, so be prepared for some direct client communication.</p>
<h2>The Right Candidate</h2>
<p>We’re looking for someone who:</p>
<ul>
<li><strong>Has a proven track record in Quality Assurance.</strong> Automated testing experience is a bonus, but the majority of our QA is manual and requires a heavy degree of hands-on testing. Be prepared to provide examples of past experience.</li>
<li><strong>Pays meticulous attention to detail + fights for the customer.</strong> Being able to catch bugs is huge, but it isn’t everything — QA is most effective when it puts itself in the customer or end user’s shoes.</li>
<li><strong>Knows WordPress well.</strong> It’s tough coming in and having to learn WordPress and our QA systems at the same time. Through a (paid) test project, you&#8217;ll be expected to prove your familiarity with the platform.</li>
<li><strong>Has 1+ year remote freelancing experience.</strong> Full-time freelancers are the only candidates we’re looking for at this time; we are not seeking F/T or P/T employees, nor can we work with somebody moonlighting from a full-time gig. And if you haven’t worked remotely before, this probably won’t be a good fit.</li>
<li><strong>Likes working with a diverse group of awesome people.</strong> Since Modern Tribe is an entirely remote company, you&#8217;ll work with people from all over the world who you might not cross paths with at a traditional office gig. And when we get together for our yearly team-wide retreat (usually in warm exotic locale where the food is cheap and the wifi is spotty), there’s no telling what types of friendships will emerge once everyone is in the same room.</li>
</ul>
<p>Our hourly rate for this gig starts at<strong> $35-$45/hr</strong>, depending on experience, with opportunities for rate bumps on annual review.</p>
<p>Since this is a freelance position, you control your schedule and work when you want to. But note that we are looking for team members to have at least <strong>3 hours of overlap each day</strong> with the rest of your project team.</p>
<h2>Who Are We?</h2>
<p><a href="http://tri.be/">Modern Tribe</a> is a unique hybrid of independent contractors and traditional employees, with the added distinction of being 100% remote. One of the benefits of working with us is the diversity this brings: you’ll be building cool stuff with people from different cultures bringing a variety of experiences to the table.</p>
<p>We believe that you should be happy, helpful, curious &amp; accountable, on top of being good at what you do. We believe life should be lived intentionally. We believe in a class of artisans and craftsman in control of their work who solve people problems rather than just build more crap. We believe in a sustainable vision of open source, and contribute consistently into the ecosystem.</p>
<p><em><strong>NOTE:</strong> Modern Tribe thrives from having a diverse workplace. We do not discriminate against prospective contractors on the basis of race, religion, color, gender identity, age, veteran status, sexual orientation, marital status, physical/mental disability, or other protected classes.</em></p>
<h2>How To Apply</h2>
<p>We&#8217;re excited to hear from you! Please include in your application:</p>
<ul>
<li>A link to your Linkedin, personal portfolio, or online resume.</li>
<li>A link to any QA plans that you have written in the past.</li>
<li>A short sentence about why you want to work with Modern Tribe and how we can help you achieve your goals.</li>
<li>Details about your WordPress knowledge and any relevant experience doing QA on WordPress projects.</li>
</ul>
<p>All set? Apply at our <a href="https://theeventscalendar.com/join-our-team/">Work with Us page</a>!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/join-modern-tribes-qa-team/">Join Modern Tribe&#8217;s QA team</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"https://theeventscalendar.com/join-modern-tribes-qa-team/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"Upcoming Release: What’s Coming in The Events Calendar 4.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"https://theeventscalendar.com/upcoming-release-events-calendar-4-0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"https://theeventscalendar.com/upcoming-release-events-calendar-4-0/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 Oct 2015 15:40:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"Quick Peek";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"preview";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1013701";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:591:"<p>The release of The Events Calendar 4.0 is on the horizon, and we’ve got some juicy details to leak. What’s Our Timeline? We’re targeting a mid-November release for version 4.0. As with any major release, we’ve got quite a bit of testing and QA ahead of us before we can call it ready to ship,&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/upcoming-release-events-calendar-4-0/">Upcoming Release: What&#8217;s Coming in The Events Calendar 4.0</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Jen Jamar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3155:"<p>The release of The Events Calendar 4.0 is on the horizon, and we’ve got some juicy details to leak.</p>
<h2>What’s Our Timeline?</h2>
<p>We’re targeting a mid-November release for version 4.0. As with any major release, we’ve got quite a bit of testing and QA ahead of us before we can call it ready to ship, but we’re working hard to stick as close to our schedule as possible.</p>
<h2>Beta Testers Needed</h2>
<p>As we near the launch of 4.0, we’ll be looking for code-savvy folks to provide at least one round of substantive feedback during the course of our beta testing. The scope will include bug reports and broken functionality, including local conflicts such as theme or plugin clashes.</p>
<p>You can find more info and get signed up on our <a href="https://theeventscalendar.com/knowledgebase/signup-for-beta-access/">Beta Testing info page</a>.</p>
<p>And now for the juicy stuff….</p>
<h2>The Events Calendar 4.0 &#8211; The Highlights</h2>
<ul>
<li>A new (and free!) add-on for creating and selling tickets for events (including RSVP capabilities)</li>
<li>We&#8217;re consolidating all of our <a href="https://theeventscalendar.com/tickets">premium ticketing add-ons</a> into one single add-on</li>
<li><a href="https://theeventscalendar.com/product/wordpress-events-filterbar/">Filter Bar</a> will (finally!) support filters for additional fields created in <a href="https://theeventscalendar.com/product/wordpress-events-calendar-pro/">The Events Calendar PRO</a></li>
<li>Change calendar colors directly in the WordPress theme customizer&#8211;no more code snippets needed!</li>
<li>All API settings&#8211;from Eventbrite to Facebook&#8211;in a single place</li>
<li>Facebook Events will sync the changes made to an event on facebook.com to the site</li>
<li>Better integration with Twenty Fifteen</li>
</ul>
<p>Our quick &amp; dirty video preview of the updated customizer (if you already follow us on <a href="https://www.facebook.com/theeventscalendar" target="_blank">Facebook</a> or <a href="http://twitter.com/theeventscal" target="_blank">Twitter</a>, you may have already caught a glimpse of this).</p>
<p><iframe src="https://player.vimeo.com/video/142261805" width="271" height="750" frameborder="0" title="4.0 Preview: Customizer Teaser" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></p>
<h2>This is Just the Beginning</h2>
<p>The upcoming changes we&#8217;ve mentioned here are significant but also represent just the tip of the iceberg as far as what&#8217;s coming in The Events Calendar and its suite of premium add-ons. Version 4.0 marks a new era and sets the stage for a ton of new ideas we have in the works that we&#8217;re excited to let you know about in due time. We hope this gives you a good idea of what&#8217;s coming and that you&#8217;re just as stoked as we are for what&#8217;s ahead!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/upcoming-release-events-calendar-4-0/">Upcoming Release: What&#8217;s Coming in The Events Calendar 4.0</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"https://theeventscalendar.com/upcoming-release-events-calendar-4-0/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Release: The Events Calendar 3.12.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"https://theeventscalendar.com/release-the-events-calendar-3-12-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"https://theeventscalendar.com/release-the-events-calendar-3-12-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Oct 2015 20:16:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1010605";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:587:"<p>We&#8217;re back once again with a fresh release off the presses. The Events Calendar 3.12.3 is a minor update that addresses one lonely bug we felt were worth crushing ahead of the work we&#8217;re doing on 4.0.: Fix &#8211; Ensure daily counts in month view are accurate (our thanks to @communityanswers in the support forums&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-3-12-3/">Release: The Events Calendar 3.12.3</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1114:"<p>We&#8217;re back once again with a fresh release off the presses. The Events Calendar 3.12.3 is a minor update that addresses one lonely bug we felt were worth crushing ahead of the work we&#8217;re doing on 4.0.:</p>
<ul>
<li><strong>Fix</strong> &#8211; Ensure daily counts in month view are accurate (our thanks to @communityanswers in the support forums for highlighting this)</li>
</ul>
<p>As always, we recommend updating when a maintenance release is available for the version you are currently running. That said, if you have not yet updated to The Events Calendar 3.12, please note that it was a big one and you should check out <a href="https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/">our release notes for it</a> before making the jump.</p>
<p>Thanks for your support and happy updating!</p>
<p>&nbsp;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-3-12-3/">Release: The Events Calendar 3.12.3</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"https://theeventscalendar.com/release-the-events-calendar-3-12-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Release: The Events Calendar PRO 3.12.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://theeventscalendar.com/release-the-events-calendar-pro-3-12-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"https://theeventscalendar.com/release-the-events-calendar-pro-3-12-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Oct 2015 20:16:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1010613";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:609:"<p>The Events Calendar PRO 3.12.2 is ready for your updating pleasure. In this minor release, we squashed three bugs that will make your calendaring experience so much nicer: Fix &#8211; Avoid modifying permalinks unless it is absolutely necessary (props to Jan for the fix) Fix &#8211; Ensure we do not inadvertently change the order of posts&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-pro-3-12-2/">Release: The Events Calendar PRO 3.12.2</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1375:"<p>The Events Calendar PRO 3.12.2 is ready for your updating pleasure. In this minor release, we squashed three bugs that will make your calendaring experience so much nicer:</p>
<ul>
<li><strong>Fix &#8211;</strong> Avoid modifying permalinks unless it is absolutely necessary (props to Jan for the fix)</li>
<li><strong>Fix</strong> &#8211; Ensure we do not inadvertently change the order of posts when events are integrated into the main blog loop</li>
<li><strong>Fix &#8211;</strong> Ensure rewrite rules are correctly added (our thanks to Nadia for highlighting this issue)</li>
</ul>
<p>We recommend installing this update if you&#8217;re already made the leap to The Events Calendar 3.12 and The Events Calendar PRO 3.12. If you have yet to level up to the latest version, please do check out <a href="https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/">the release notes over here</a> because there were a number of significant updates you should be aware of before diving in.</p>
<p>Thanks a ton for your support and keep on rocking as we push onward toward 4.0!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-the-events-calendar-pro-3-12-2/">Release: The Events Calendar PRO 3.12.2</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"https://theeventscalendar.com/release-the-events-calendar-pro-3-12-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Release: Filter Bar 3.12.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://theeventscalendar.com/release-filter-bar-3-12-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://theeventscalendar.com/release-filter-bar-3-12-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Oct 2015 20:16:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1010617";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:554:"<p>Hello, howdy, hi and all of the above! We&#8217;re happy to let you know that we have a very minor update available for the Filter Bar add-on of The Events Calendar. The release is small, but does squash a rather annoying bug: Fix &#8211; Ensure Filter Bar renders as expected, including when translations are in&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-filter-bar-3-12-1/">Release: Filter Bar 3.12.1</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1134:"<p>Hello, howdy, hi and all of the above! We&#8217;re happy to let you know that we have a very minor update available for the Filter Bar add-on of The Events Calendar. The release is small, but does squash a rather annoying bug:</p>
<ul>
<li><strong>Fix &#8211;</strong> Ensure Filter Bar renders as expected, including when translations are in effect (thanks to @flamencoagenda on the forums for highlighting this)</li>
</ul>
<p>We recommend installing this update if you&#8217;ve already made the jump to The Events Calendar 3.12 and Filter Bar 3.12. Please read through <a href="https://theeventscalendar.com/release-version-3-12-of-the-events-calendar-pro-and-all-add-ons/">the release notes for The Events Calendar 3.12</a> if you haven&#8217;t upgrade to it yet because there are a number of significant changes in there you should know about before installing.</p>
<p>Cheers and happy updating!</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-filter-bar-3-12-1/">Release: Filter Bar 3.12.1</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://theeventscalendar.com/release-filter-bar-3-12-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Release: iCal Importer 3.12.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://theeventscalendar.com/release-ical-importer-3-12-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:68:"https://theeventscalendar.com/release-ical-importer-3-12-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Oct 2015 20:16:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Release Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1010622";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:555:"<p>Howdy folks! A small update is available for the iCal Importer add-on for The Events Calendar. We made one minor tweak in iCal Importer 3.12.2: Tweak &#8211; Switch to the WordPress HTTP API when loading iCal data from an external source (with thanks to Bill on the forums for helping us with this issue) It&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-ical-importer-3-12-2/">Release: iCal Importer 3.12.2</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Geoff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1230:"<p>Howdy folks! A small update is available for the iCal Importer add-on for The Events Calendar. We made one minor tweak in iCal Importer 3.12.2:</p>
<ul>
<li><strong>Tweak &#8211;</strong> Switch to the WordPress HTTP API when loading iCal data from an external source (with thanks to Bill on the forums for helping us with this issue)</li>
</ul>
<p>It might seem small, but this mighty little change is super helpful when importing events to The Events Calendar from secure external sources. We recommend updating if you&#8217;ve already made the jump to The Events Calendar 3.12 and iCal Importer 3.12. If not, please do read the notes for that release ahead of updating&#8211;there are a number of significant updates to be aware of before diving in.</p>
<p>Cheers and thanks for your support! We&#8217;re well on our way toward 4.0. <img src="https://theeventscalendar.com/wp-includes/images/smilies/simple-smile.png" alt=":)" class="wp-smiley" style="height: 1em; max-height: 1em;" /></p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/release-ical-importer-3-12-2/">Release: iCal Importer 3.12.2</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:64:"https://theeventscalendar.com/release-ical-importer-3-12-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"Join our support team as we prepare The Events Calendar 4.0 for release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"https://theeventscalendar.com/join-our-support-team-as-we-prepare-the-events-calendar-4-0-for-release/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:111:"https://theeventscalendar.com/join-our-support-team-as-we-prepare-the-events-calendar-4-0-for-release/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Oct 2015 15:36:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"Gigs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://theeventscalendar.com/?p=1010164";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:715:"<p>Modern Tribe’s flagship WordPress plugin, The Events Calendar, has grown substantially during 2015. It is currently the most popular calendar plugin on the WordPress.org repo, and just a few weeks ago, hit 2 million downloads. As we move towards launching The Events Calendar 4.0 in November and prepare for the support onslaught that will likely accompany it, we’re looking&#8230;</p>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/join-our-support-team-as-we-prepare-the-events-calendar-4-0-for-release/">Join our support team as we prepare The Events Calendar 4.0 for release</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:3:"Rob";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:8052:"<p>Modern Tribe’s flagship WordPress plugin, <a href="https://wordpress.org/plugins/the-events-calendar/">The Events Calendar</a>, has grown substantially during 2015. It is currently the most popular calendar plugin on the WordPress.org repo, and just a few weeks ago, <a href="https://theeventscalendar.com/2-million-downloads-the-events-calendar/">hit 2 million downloads</a>. As we move towards launching <strong>The Events Calendar 4.0</strong> in November and prepare for the support onslaught that will likely accompany it, we’re looking to build out our support team with 1-2 friendly people who know the plugin and find great joy in helping troubleshoot user problems.</p>
<p>Our support team prioritizes our <a href="http://theeventscalendar.com/support/forums/">premium forums</a> above all else. Each day, the team works to clear out the list of new threads and existing follow-ups, collaborating to troubleshoot challenging issues together in our support team Slack channel. Everyone on the team is responsible for clearing out their queue of assigned threads and making as big a dent as possible in the unassigned queue each day. No threads should be left unreplied to at the end of each day, and all threads need a reply within 24 hours (during the business week).</p>
<p>Once the queue is clear, there are plenty of opportunities for support members to help with other tasks that interest them. These include:</p>
<ul>
<li>Quality assurance testing on each plugin prior to a new release</li>
<li>Contributing to development tickets during the plugin dev cycle</li>
<li>Preparing tutorials, snippets and video walkthroughs that help users do creative/cool things with the plugin</li>
<li>Helping run regular user testing sessions</li>
<li>Marketing efforts: blogging, promoting the plugin, working on swag, etc.</li>
</ul>
<p>Though the support forums are everyone’s priority — and will be the main focus of your work each day — it is not the only opportunity support team members can expect. We want to provide people with chances to learn in the areas that interest them, so long as it doesn’t distract from the main goal of helping our customers solve their problems politely and quickly.</p>
<h3><b>The Team</b></h3>
<p>Modern Tribe is a unique hybrid of independent contractors and traditional employees, with the added distinction of being 100% remote. One of the benefits of working with us is the diversity this brings: you’ll be building cool stuff with people from different cultures bringing a variety of experiences to the table.</p>
<p>A Scottish support guru living off the Western Coast of Canada. An amazing Argentinean developer based in the secluded hills of wine-rich Mendoza. A lead project manager nestled in the heart of New Hampshire while his assistant PM on the same project chills down in Nicaragua. A trio of owners — Shane, Reid and Peter — who don’t even all live in the same state.</p>
<p>With a worldwide crew of the best and brightest, you can be sure you will learn a lot and have a great time working with people you might not cross paths with at a traditional office gig. And when we get together for our yearly team-wide retreat (usually in warm exotic locale where the food is cheap and the wifi is spotty), there’s no telling what types of friendships will emerge once everyone is in the same room.</p>
<h3><b>The Right Candidate</b></h3>
<p>If you possess the following traits, we’d love to speak with you:</p>
<ul>
<li><strong>An existing familiarity with The Events Calendar.</strong> Bonus if you have used The Events Calendar PRO or our other premium add-ons.</li>
<li><strong>A fairly strong command of PHP, CSS, HTML and JavaScript.</strong> You don’t need to be a full-stack developer, but you need to be able to effectively troubleshoot problems in these 4 areas on your own.</li>
<li><strong>At least 1 year experience doing web-based customer support.</strong> Be prepared to provide some examples.</li>
<li><strong>1+ year remote freelancing experience.</strong> Full-time freelancers are the only candidates we&#8217;re looking for at this time; we are not seeking F/T or P/T employees, nor can we work with somebody moonlighting from a full-time gig. And if you haven’t worked remotely before, this probably won’t be a good fit.</li>
</ul>
<p>Our hourly rate for this gig starts at <strong>$30-$40/hr</strong>, depending on experience, with opportunities for rate bumps on annual review.</p>
<p>Since this is a freelance position, you control your schedule and work when you want to. But note that we expect team members to have <strong>at least 3 hours of overlap each business day</strong> with the rest of our support team, who generally work between the hours of <strong>7 am and 5 pm PT, Monday-Friday.</strong></p>
<h3><b>Our Interview Process</b></h3>
<p>Modern Tribe’s interview process involves three distinct steps:</p>
<ul>
<li>After our recruiter does initial screening, you’ll have an interview with our hiring manager. They’ll meet with you for 30-60 minutes to ask questions about your experience with the plugin and freelancing, how you manage burnout as a remote worker, etc.</li>
<li>If the interview works out, we’ll set you up for a paid test project answering 7-10 real world support questions pulled from our forums. (If you haven’t checked out the types of issues that we handle there, <a href="http://theeventscalendar.com/support/forums/">now would be a good time</a>). You will be paid for the test project regardless of whether you make it beyond this stage.</li>
<li>If the test project passes our support team’s collective review, we’ll get you hooked in for a one month trial. You will be a full member of the team at this point and will be doing the same work as everyone else; but the monthlong trial gives both sides an opportunity to “try before they buy.”</li>
</ul>
<p>When we get to the end of the monthlong trial period, both sides will meet to review how it went and whether it makes sense to continue working together.</p>
<h3><b>Who Are We? </b></h3>
<div>
<p>Modern Tribe is a digital agency with a modern twist. We are a product company. We are educators. We are a great mix of freelancers and full timers. All experts. In today’s world, we get to be many things to many people.</p>
<p>We believe in making quality products for other people and ourselves, balanced by living quality lives. We are 100% distributed &amp; our team is spread around North America (and a hint beyond).</p>
<p>We believe that you should be happy, helpful, curious &amp; accountable, on top of being good at what you do. We believe life should be lived intentionally. We believe in a class of artisans and craftsman in control of their work who solve people problems rather than just build more shit. We believe in a sustainable vision of open source, and contribute consistently into the ecosystem.</p>
<p><em>NOTE: Modern Tribe thrives from having a diverse workplace. We do not discriminate against prospective contractors on the basis of race, religion, color, gender identity, age, veteran status, sexual orientation, marital status, physical/mental disability, or other protected classes.</em></p>
<h3><b>How To Apply</b></h3>
<p>Think you’d be a good fit? We can’t wait to hear from you! Submit your information at the application form on our <a href="https://theeventscalendar.com/join-our-team/">Work With Us</a> page (make sure to select Community/Support from the radio buttons to let us know which position you’re applying for). Also, please include a note about your favorite color so we know you read this. We’ll be in touch from there.</p>
</div>
<p>The post <a rel="nofollow" href="https://theeventscalendar.com/join-our-support-team-as-we-prepare-the-events-calendar-4-0-for-release/">Join our support team as we prepare The Events Calendar 4.0 for release</a> appeared first on <a rel="nofollow" href="https://theeventscalendar.com">The Events Calendar</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:107:"https://theeventscalendar.com/join-our-support-team-as-we-prepare-the-events-calendar-4-0-for-release/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:35:"https://theeventscalendar.com/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 18 Oct 2015 13:30:00 GMT";s:12:"content-type";s:34:"application/rss+xml; charset=UTF-8";s:10:"connection";s:5:"close";s:13:"cache-control";s:28:"max-age=448, must-revalidate";s:12:"x-powered-by";s:21:"PHP/5.4.33-1~dotdeb.1";s:4:"vary";s:6:"Cookie";s:10:"x-pingback";s:40:"https://theeventscalendar.com/xmlrpc.php";s:13:"last-modified";s:29:"Sun, 18 Oct 2015 12:36:45 GMT";s:4:"etag";s:34:""2f91e92cdaaf95956481ed57e7d32de6"";s:12:"x-robots-tag";s:14:"noindex,follow";}s:5:"build";s:14:"20150611172108";}', 'no') ; 
INSERT INTO `gx_options` VALUES (414, '_transient_timeout_feed_mod_0d102f2a1f4d6bc90eb8c6ffe18e56ed', '1445218199', 'no') ; 
INSERT INTO `gx_options` VALUES (415, '_transient_feed_mod_0d102f2a1f4d6bc90eb8c6ffe18e56ed', '1445174999', 'no') ; 
INSERT INTO `gx_options` VALUES (418, '_transient_timeout_feed_2c2fe0099a2578688413800ea68677d6', '1445218200', 'no') ; 
INSERT INTO `gx_options` VALUES (419, '_transient_feed_2c2fe0099a2578688413800ea68677d6', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"ButlerBlog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://www.butlerblog.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:20:"chad butler\'s weblog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 12 Jun 2015 16:00:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=4.3.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"5 Articles to Help You Manage WordPress Better";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/-HQU00er-qs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.butlerblog.com/2015/06/11/articles-to-help-you-manage-wordpress-better/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Jun 2015 15:59:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:11:"development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3436";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1776:"Here are some posts that I have done on the site to help you manage WordPress better.   Maybe you&#8217;re a writer or designer, and not a developer. Then you are in luck! These posts are to help the...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=-HQU00er-qs:sLeSOeyZpBU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=-HQU00er-qs:sLeSOeyZpBU:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=-HQU00er-qs:sLeSOeyZpBU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=-HQU00er-qs:sLeSOeyZpBU:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/-HQU00er-qs" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.butlerblog.com/2015/06/11/articles-to-help-you-manage-wordpress-better/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:82:"http://www.butlerblog.com/2015/06/11/articles-to-help-you-manage-wordpress-better/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Don’t Let This Mistake Kill Your Business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/AFPMDwe6Lv8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.butlerblog.com/2015/06/04/dont-let-this-mistake-kill-your-business/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Jun 2015 14:00:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:4:"fear";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"freelance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:12:"productivity";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3370";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1770:"It&#8217;s called &#8220;Perfectionism&#8221; and it effects many new writers, developers, and freelancers. At some point, it effects almost everyone who attempts to launch their business online...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=AFPMDwe6Lv8:pK0kUdPxMmA:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=AFPMDwe6Lv8:pK0kUdPxMmA:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=AFPMDwe6Lv8:pK0kUdPxMmA:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=AFPMDwe6Lv8:pK0kUdPxMmA:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/AFPMDwe6Lv8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.butlerblog.com/2015/06/04/dont-let-this-mistake-kill-your-business/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.butlerblog.com/2015/06/04/dont-let-this-mistake-kill-your-business/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Is your site ready for mobilegeddon?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/mgXl7Q4PrM8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:82:"http://www.butlerblog.com/2015/04/20/is-your-site-ready-for-mobilegeddon/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Apr 2015 03:34:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"Web";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3393";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1771:"Is your site currently mobile friendly?  How fast does it load on mobile devices? Dubbed &#8220;Mobilegeddon,&#8221; Google will be making changes to its search algorithm on Tuesday to take into...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=mgXl7Q4PrM8:77HxzmE4DWw:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=mgXl7Q4PrM8:77HxzmE4DWw:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=mgXl7Q4PrM8:77HxzmE4DWw:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=mgXl7Q4PrM8:77HxzmE4DWw:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/mgXl7Q4PrM8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.butlerblog.com/2015/04/20/is-your-site-ready-for-mobilegeddon/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:73:"http://www.butlerblog.com/2015/04/20/is-your-site-ready-for-mobilegeddon/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:69:"
		
		
		
		
		
				
		
		
		
		
		
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"Personal Brand Building with Your Own URL Shortener";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/ISeEKBHBNSU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:92:"http://www.butlerblog.com/2015/02/05/personal-brand-building-your-own-url-shortener/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Feb 2015 14:00:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:12:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:14:"Brand Building";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:11:"Brand Image";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"branding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:17:"Personal Branding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:14:"Shortened Urls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:9;a:5:{s:4:"data";s:5:"tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:10;a:5:{s:4:"data";s:6:"webdev";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:11;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3297";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1775:"You may have noticed that last year I started the process of reinforcing my personal brand image, placing a larger importance on personal branding.  This included a web site makeover, a new logo for...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=ISeEKBHBNSU:dx5Efy0GcqQ:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=ISeEKBHBNSU:dx5Efy0GcqQ:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=ISeEKBHBNSU:dx5Efy0GcqQ:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=ISeEKBHBNSU:dx5Efy0GcqQ:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/ISeEKBHBNSU" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:89:"http://www.butlerblog.com/2015/02/05/personal-brand-building-your-own-url-shortener/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:84:"http://www.butlerblog.com/2015/02/05/personal-brand-building-your-own-url-shortener/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Schedule Your Day to Improve Productivity in 3 Easy Steps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/M8lGPovanBo/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.butlerblog.com/2015/02/03/schedule-your-day-to-improve-productivity-in-3-easy-steps/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Feb 2015 13:00:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:11:"development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"freelance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3239";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1775:"I once wrote a post about the importance of avoiding distractions as a freelancer. It began with a little story about burning a pot of coffee and related that to how distractions can yield a similar...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=M8lGPovanBo:aXSUkrdH0YQ:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=M8lGPovanBo:aXSUkrdH0YQ:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=M8lGPovanBo:aXSUkrdH0YQ:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=M8lGPovanBo:aXSUkrdH0YQ:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/M8lGPovanBo" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:100:"http://www.butlerblog.com/2015/02/03/schedule-your-day-to-improve-productivity-in-3-easy-steps/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:95:"http://www.butlerblog.com/2015/02/03/schedule-your-day-to-improve-productivity-in-3-easy-steps/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"5 Top Bloggers Teach You How to Drive Traffic to Your Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/LKX4GwZQzyE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:105:"http://www.butlerblog.com/2015/02/02/5-top-bloggers-teach-you-how-to-drive-traffic-to-your-blog/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Feb 2015 18:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3131";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1772:"These 5 top bloggers command top dollar for their advice and expertise. Here is an opportunity for you to get some of their best advice on how to get more blog traffic. And you don&#8217;t have to...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=LKX4GwZQzyE:mtZt7OT42PU:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=LKX4GwZQzyE:mtZt7OT42PU:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=LKX4GwZQzyE:mtZt7OT42PU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=LKX4GwZQzyE:mtZt7OT42PU:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/LKX4GwZQzyE" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:101:"http://www.butlerblog.com/2015/02/02/5-top-bloggers-teach-you-how-to-drive-traffic-to-your-blog/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:96:"http://www.butlerblog.com/2015/02/02/5-top-bloggers-teach-you-how-to-drive-traffic-to-your-blog/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:63:"
		
		
		
		
		
				
		
		
		
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"Building Successful Membership Sites: What You Need To Know";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/Kxe5VDIbYxg/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:86:"http://www.butlerblog.com/2015/01/30/how-to-build-successful-membership-sites/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Jan 2015 15:54:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:10:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:14:"Building Trust";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"Business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:17:"Business Modeling";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:16:"membership-sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:8:"monetize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:8;a:5:{s:4:"data";s:15:"Premium Content";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:9;a:5:{s:4:"data";s:16:"Web Entrepreneur";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"http://www.butlerblog.com/?page_id=3302";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1774:"Many web entrepreneurs and freelancers would argue that the membership site is the ultimate business model. As someone who has utilized this concept for coming close to two decades, I would agree. I...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=Kxe5VDIbYxg:fzdF2-4qX-w:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=Kxe5VDIbYxg:fzdF2-4qX-w:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=Kxe5VDIbYxg:fzdF2-4qX-w:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=Kxe5VDIbYxg:fzdF2-4qX-w:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/Kxe5VDIbYxg" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.butlerblog.com/2015/01/30/how-to-build-successful-membership-sites/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.butlerblog.com/2015/01/30/how-to-build-successful-membership-sites/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"Change WordPress email settings to reduce spam rejection";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/UXBYB7kQsxM/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.butlerblog.com/2014/11/24/change-wordpress-email-settings-to-reduce-spam-rejection/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 24 Nov 2014 16:41:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:13:"Blogging Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"webdev";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:29:"Wordpress Email Configuration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:7:"wp_mail";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3263";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1774:"I have several other posts on how to improve the reliability of email sent via wp_mail and how to troubleshoot your WordPress email settings, most of which has focused on the sending end. A common...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=UXBYB7kQsxM:4_c9_4U2EAY:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=UXBYB7kQsxM:4_c9_4U2EAY:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=UXBYB7kQsxM:4_c9_4U2EAY:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=UXBYB7kQsxM:4_c9_4U2EAY:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/UXBYB7kQsxM" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:99:"http://www.butlerblog.com/2014/11/24/change-wordpress-email-settings-to-reduce-spam-rejection/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:94:"http://www.butlerblog.com/2014/11/24/change-wordpress-email-settings-to-reduce-spam-rejection/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:36:"
		
		
		
		
		
				

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Weekend Reading List";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/7lanse57Iro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.butlerblog.com/2014/10/25/weekend-reading-list-3/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 25 Oct 2014 15:00:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:9:"Editorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1772:"One of these weeks, I&#8217;m going to get the Weekend Reading List out on a Friday like it&#8217;s supposed to be! But at least this is closer (Saturday morning).  I&#8217;ve got a great list of...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=7lanse57Iro:ra3rzd2c9vI:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=7lanse57Iro:ra3rzd2c9vI:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=7lanse57Iro:ra3rzd2c9vI:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=7lanse57Iro:ra3rzd2c9vI:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/7lanse57Iro" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://www.butlerblog.com/2014/10/25/weekend-reading-list-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.butlerblog.com/2014/10/25/weekend-reading-list-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Weekend Reading List";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://feedproxy.google.com/~r/butlerblog/~3/B16V7TM1ZY8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.butlerblog.com/2014/10/17/weekend-reading-list-2/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Oct 2014 16:35:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:15:"Weekend Reading";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"clickbank";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:17:"content-marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"freelance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://www.butlerblog.com/?p=3196";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1763:"This week&#8217;s weekend reading list has some great posts on content creation and copywriting.   The first is from KISSmetrics &#8211; How to Steal Killer Sales Copy Straight from Your...<br/>
<br/>
[[ This is a content summary only. Visit my website for full links, other content, and more! ]]<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:V_sGLiPBpWU"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=B16V7TM1ZY8:GPC8YEFff7w:V_sGLiPBpWU" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:dnMXMwOfBR0"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=dnMXMwOfBR0" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=B16V7TM1ZY8:GPC8YEFff7w:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:7Q72WNTAKBA"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=7Q72WNTAKBA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/butlerblog?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/butlerblog?a=B16V7TM1ZY8:GPC8YEFff7w:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/butlerblog?i=B16V7TM1ZY8:GPC8YEFff7w:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/butlerblog/~4/B16V7TM1ZY8" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Chad Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://www.butlerblog.com/2014/10/17/weekend-reading-list-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.butlerblog.com/2014/10/17/weekend-reading-list-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:38:"http://feeds.feedburner.com/butlerblog";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:10:"butlerblog";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:10:"butlerblog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:29:"https://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"r75Hwatt8SfwdhsGX3rvbMIs2bo";s:13:"last-modified";s:29:"Sun, 18 Oct 2015 13:07:01 GMT";s:16:"content-encoding";s:4:"gzip";s:4:"date";s:29:"Sun, 18 Oct 2015 13:29:59 GMT";s:7:"expires";s:29:"Sun, 18 Oct 2015 13:29:59 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";}s:5:"build";s:14:"20150611172108";}', 'no') ; 
INSERT INTO `gx_options` VALUES (420, '_transient_timeout_feed_mod_2c2fe0099a2578688413800ea68677d6', '1445218200', 'no') ; 
INSERT INTO `gx_options` VALUES (421, '_transient_feed_mod_2c2fe0099a2578688413800ea68677d6', '1445175000', 'no') ; 
INSERT INTO `gx_options` VALUES (422, '_site_transient_timeout_wporg_theme_feature_list', '1445195673', 'yes') ; 
INSERT INTO `gx_options` VALUES (423, '_site_transient_wporg_theme_feature_list', 'a:4:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:6:"Layout";a:9:{i:0;s:12:"fixed-layout";i:1;s:12:"fluid-layout";i:2;s:17:"responsive-layout";i:3;s:10:"one-column";i:4;s:11:"two-columns";i:5;s:13:"three-columns";i:6;s:12:"four-columns";i:7;s:12:"left-sidebar";i:8;s:13:"right-sidebar";}s:8:"Features";a:20:{i:0;s:19:"accessibility-ready";i:1;s:8:"blavatar";i:2;s:10:"buddypress";i:3;s:17:"custom-background";i:4;s:13:"custom-colors";i:5;s:13:"custom-header";i:6;s:11:"custom-menu";i:7;s:12:"editor-style";i:8;s:21:"featured-image-header";i:9;s:15:"featured-images";i:10;s:15:"flexible-header";i:11;s:20:"front-page-post-form";i:12;s:19:"full-width-template";i:13;s:12:"microformats";i:14;s:12:"post-formats";i:15;s:20:"rtl-language-support";i:16;s:11:"sticky-post";i:17;s:13:"theme-options";i:18;s:17:"threaded-comments";i:19;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (424, '_transient_timeout_wpseo-dashboard-totals', '1445262710', 'no') ; 
INSERT INTO `gx_options` VALUES (425, '_transient_wpseo-dashboard-totals', 'a:7:{i:0;a:1:{i:4;a:4:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:5:"count";s:1:"1";}}i:1;a:1:{i:4;a:4:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:5:"count";s:1:"1";}}i:2;a:1:{i:4;a:4:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:5:"count";s:1:"1";}}i:3;a:1:{i:4;a:4:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:5:"count";s:1:"1";}}i:4;a:1:{i:4;a:4:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:5:"count";s:1:"1";}}i:5;a:1:{i:4;a:4:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:5:"count";s:1:"1";}}i:6;a:1:{i:4;a:4:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:5:"count";s:1:"1";}}}', 'no') ; 
INSERT INTO `gx_options` VALUES (427, 'theme_mods_responsiveboat', 'a:6:{i:0;b:0;s:20:"zerif_bigtitle_title";s:20:"Gobrenix Productions";s:30:"zerif_bigtitle_redbutton_label";s:8:"About us";s:32:"zerif_bigtitle_greenbutton_label";s:7:"Contact";s:16:"rb_bigtitle_logo";s:0:"";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1445176060;s:4:"data";a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:15:"sidebar-aboutus";N;s:16:"sidebar-ourfocus";a:4:{i:0;s:17:"ctup-ads-widget-1";i:1;s:17:"ctup-ads-widget-2";i:2;s:17:"ctup-ads-widget-3";i:3;s:17:"ctup-ads-widget-4";}s:20:"sidebar-testimonials";a:3:{i:0;s:21:"zerif_testim-widget-1";i:1;s:21:"zerif_testim-widget-2";i:2;s:21:"zerif_testim-widget-3";}s:15:"sidebar-ourteam";a:4:{i:0;s:19:"zerif_team-widget-1";i:1;s:19:"zerif_team-widget-2";i:2;s:19:"zerif_team-widget-3";i:3;s:19:"zerif_team-widget-4";}}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (428, 'widget_ctup-ads-widget', 'a:5:{i:1;a:4:{s:5:"title";s:15:"PARALLAX EFFECT";s:4:"text";s:163:"Create memorable pages with smooth parallax effects that everyone loves. Also, use our lightweight content slider offering you smooth and great-looking animations.";s:4:"link";s:1:"#";s:9:"image_uri";s:81:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/parallax.png";}i:2;a:4:{s:5:"title";s:11:"WOOCOMMERCE";s:4:"text";s:166:"Build a front page for your WooCommerce store in a matter of minutes. The neat and clean presentation will help your sales and make your store accessible to everyone.";s:4:"link";s:1:"#";s:9:"image_uri";s:76:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/woo.png";}i:3;a:4:{s:5:"title";s:21:"CUSTOM CONTENT BLOCKS";s:4:"text";s:164:"Showcase your team, products, clients, about info, testimonials, latest posts from the blog, contact form, additional calls to action. Everything translation ready.";s:4:"link";s:1:"#";s:9:"image_uri";s:76:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/ccc.png";}i:4;a:4:{s:5:"title";s:24:"GO PRO FOR MORE FEATURES";s:4:"text";s:186:"Get new content blocks: pricing table, Google Maps, and more. Change the sections order, display each block exactly where you need it, customize the blocks with whatever colors you wish.";s:4:"link";s:1:"#";s:9:"image_uri";s:80:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/ti-logo.png";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (429, 'widget_zerif_testim-widget', 'a:4:{i:1;a:3:{s:5:"title";s:10:"Dana Lorem";s:4:"text";s:242:"Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur nec sem vel sapien venenatis mattis non vitae augue. Nullam congue commodo lorem vitae facilisis. Suspendisse malesuada id turpis interdum dictum.";s:9:"image_uri";s:85:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/testimonial1.jpg";}i:2;a:3:{s:5:"title";s:13:"Linda Guthrie";s:4:"text";s:242:"Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur nec sem vel sapien venenatis mattis non vitae augue. Nullam congue commodo lorem vitae facilisis. Suspendisse malesuada id turpis interdum dictum.";s:9:"image_uri";s:85:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/testimonial2.jpg";}i:3;a:3:{s:5:"title";s:13:"Cynthia Henry";s:4:"text";s:242:"Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur nec sem vel sapien venenatis mattis non vitae augue. Nullam congue commodo lorem vitae facilisis. Suspendisse malesuada id turpis interdum dictum.";s:9:"image_uri";s:85:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/testimonial3.jpg";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (430, 'widget_zerif_team-widget', 'a:5:{i:1;a:9:{s:4:"name";s:14:"ASHLEY SIMMONS";s:8:"position";s:15:"Project Manager";s:11:"description";s:157:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc dapibus, eros at accumsan auctor, felis eros condimentum quam, non porttitor est urna vel neque";s:7:"fb_link";s:1:"#";s:7:"tw_link";s:1:"#";s:7:"bh_link";s:1:"#";s:7:"db_link";s:1:"#";s:7:"ln_link";s:1:"#";s:9:"image_uri";s:78:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/team1.png";}i:2;a:9:{s:4:"name";s:13:"TIMOTHY SPRAY";s:8:"position";s:12:"Art Director";s:11:"description";s:157:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc dapibus, eros at accumsan auctor, felis eros condimentum quam, non porttitor est urna vel neque";s:7:"fb_link";s:1:"#";s:7:"tw_link";s:1:"#";s:7:"bh_link";s:1:"#";s:7:"db_link";s:1:"#";s:7:"ln_link";s:1:"#";s:9:"image_uri";s:78:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/team2.png";}i:3;a:9:{s:4:"name";s:12:"TONYA GARCIA";s:8:"position";s:15:"Account Manager";s:11:"description";s:157:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc dapibus, eros at accumsan auctor, felis eros condimentum quam, non porttitor est urna vel neque";s:7:"fb_link";s:1:"#";s:7:"tw_link";s:1:"#";s:7:"bh_link";s:1:"#";s:7:"db_link";s:1:"#";s:7:"ln_link";s:1:"#";s:9:"image_uri";s:78:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/team3.png";}i:4;a:9:{s:4:"name";s:10:"JASON LANE";s:8:"position";s:20:"Business Development";s:11:"description";s:157:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc dapibus, eros at accumsan auctor, felis eros condimentum quam, non porttitor est urna vel neque";s:7:"fb_link";s:1:"#";s:7:"tw_link";s:1:"#";s:7:"bh_link";s:1:"#";s:7:"db_link";s:1:"#";s:7:"ln_link";s:1:"#";s:9:"image_uri";s:78:"http://localhost:88/gobrenix.com/wp-content/themes/zerif-lite/images/team4.png";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (431, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `gx_options` VALUES (435, 'widget_zerif_clients-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (436, '_transient_timeout_feed_bdc5f20c97996c8ac39224fac23b29b0', '1445219125', 'no') ; 
INSERT INTO `gx_options` VALUES (437, '_transient_feed_bdc5f20c97996c8ac39224fac23b29b0', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress Deutschland News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:20:"http://blog.wpde.org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 Apr 2015 20:03:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"de-DE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=4.3.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 4.2.1 Security-Release veröffentlicht";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://blog.wpde.org/2015/04/27/wordpress-4-2-1-security-release-veroeffentlicht.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:94:"http://blog.wpde.org/2015/04/27/wordpress-4-2-1-security-release-veroeffentlicht.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 Apr 2015 20:03:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3146";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:480:"WordPress 4.2.1 wurde soeben veröffentlicht &#8211; diese Version behebt kritische Sicherheitslücken, wir empfehlen dringend alle älteren Versionen umgehend zu aktualisieren. Das Sicherheitsproblem wurde dem Release-Team erst einige Stunden zuvor mitgeteilt, das Team hat sich entschlossen sofort zu handeln und eine Security-Release zu veröffentlichen. Sofern die Hintergrund-Aktualisierung nicht deaktiviert wurde, wird die Version automatisch eingespielt. Weitere [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Olaf Schmitz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1383:"<p><strong class="teaser"><a href="https://wordpress.org/news/2015/04/wordpress-4-2-1/">WordPress 4.2.1</a> wurde soeben veröffentlicht &#8211; diese Version behebt kritische Sicherheitslücken, wir empfehlen dringend alle älteren Versionen umgehend zu aktualisieren.</strong></p>
<p>Das Sicherheitsproblem wurde dem Release-Team erst einige Stunden zuvor mitgeteilt, das Team hat sich entschlossen sofort zu handeln und eine Security-Release zu veröffentlichen. Sofern die Hintergrund-Aktualisierung nicht deaktiviert wurde, wird die Version automatisch eingespielt.</p>
<p>Weitere Informationen findest du in den offiziellen <a href="https://codex.wordpress.org/Version_4.2.1">Release-Notes</a> und im <a href="https://core.trac.wordpress.org/log/branches/4.2?rev=32311&#038;stop_rev=32300">Changelog</a>.</p>
<p><strong>In kurzer Zeit ist dies das dritte Release, kurz vor und nach Version 4.2 wurden Security-Releases veröffentlicht &#8211; wann eine Sicherheitslücke bekannt wird ist nicht vorhersagbar. Wichtig ist alleine, dass direkt auf bekannte, schwerwiegende Sicherheitslücken reagiert wird.</strong></p>
<p>Bitte wende dich mit Fragen oder Problemen an das <a href="http://forum.wpde.org/">Forum</a>. Dort findest du Hilfe, falls bei dir Probleme auftauchen, du Fragen im Vorfeld der Aktualisierung hast oder Unterstützung zu den neuen Funktionen benötigst.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:90:"http://blog.wpde.org/2015/04/27/wordpress-4-2-1-security-release-veroeffentlicht.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"13";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress 4.2 „Powell“";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://blog.wpde.org/2015/04/24/wordpress-4-2-powell.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"http://blog.wpde.org/2015/04/24/wordpress-4-2-powell.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Apr 2015 15:32:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3132";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:491:"WordPress 4.2 wurde veröffentlicht, diese Version ist dem Jazz-Pianisten Bud Powell gewidmet. Die offizielle englisch- und deutschsprachigen Versionen stehen zum Download bereit. Sie werden bereits über die automatische Aktualisierung im eigenen Administtrationsbereich angeboten. Mit dieser Funktion wurde das Press This Bookmarklet-Bookmarklet überarbeitet, die interne Zeichenfunktion wurde um Chinesisch, Japanisch und Koreanisch erweitert, unterstützt werden auch Symbole [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Olaf Schmitz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3051:"<p><strong class="teaser"><a href="https://wordpress.org/news/2015/04/powell/">WordPress 4.2</a> wurde veröffentlicht, diese Version ist dem Jazz-Pianisten <a href="https://de.wikipedia.org/wiki/Bud_Powell">Bud Powell</a> gewidmet. Die offizielle englisch- und deutschsprachigen Versionen stehen zum <a href="http://wpde.org/download">Download</a> bereit. Sie werden bereits über die automatische Aktualisierung im eigenen Administtrationsbereich angeboten.</strong></p>
<p>Mit dieser Funktion wurde das Press This Bookmarklet-Bookmarklet überarbeitet, die interne Zeichenfunktion wurde um Chinesisch, Japanisch und Koreanisch erweitert, unterstützt werden auch Symbole der Musik und Mathematik, sowie Hieroglyphen und <a href="https://codex.wordpress.org/Emoji">emoji</a>. Informationen zu den weiteren Neuerungen finden sich im offiziellen <a href="https://wordpress.org/news/2015/04/powell/">Ankündigungsbeitrag auf WordPress.org</a>.</p>
<p><span id="more-3132"></span></p>
<p><embed type="application/x-shockwave-flash" src="https://v0.wordpress.com/player.swf?v=1.04" width="800" height="448" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=e9kH4FzP&amp;isDynamicSeeking=true"></embed></p>
<p><strong><u>Bitte achtet unbedingt darauf, vor der manuellen oder automatischen Aktualisierung eine vollständige <a href="http://faq.wpde.org/backup-von-wordpress-erstellen/">Datensicherung</a> anzulegen. Das beinhaltet alle Dateien auf eurem Webspace und ein vollständiges Backup der Datenbank.</u></strong></p>
<p><strong>Bitte wendet euch mit Fragen oder Problemen an das <a href="http://forum.wpde.org/">Forum</a>. Dort findet ihr Hilfe, falls bei euch Probleme auftauchen, ihr Fragen im Vorfeld der Aktualisierung habt oder Unterstützung zu den neuen Funktionen benötigt.</strong></p>
<p>In der <a href="http://faq.wpde.org/">FAQ</a> findet ihr viele Informationen und Hilfetexte, unter anderem zur <a href="http://wpde.org/installation">Installation</a> und zum <a href="http://faq.wpde.org/backup-von-wordpress-erstellen/">Anlegen eines Backups</a>. Weitere Hilfe findet ihr in unserem <a href="http://forum.wpde.org/">Support-Forum</a>, im offiziellen <a href="http://wordpress.org/support/">englischsprach-</a> oder <a href="http://de.forums.wordpress.org/">deutschsprachigem</a> Forum. </p>
<p>Solltet ihr Fehler in der Sprachdatei finden, so meldet sie bitte <a href="http://forum.wpde.org/sprachdatei/">hier im Forum</a>. Gerne könnt ihr Vorschläge direkt im GlotPress eintragen. Siehe dazu auch unseren Blogbeitrag: <a href="http://blog.wpde.org/2013/06/03/wordpress-auf-deutsch-hilf-mit.html" title="WordPress auf Deutsch – hilf mit!">WordPress auf Deutsch &#8211; hilf mit!</a></p>
<p><strong>Wir bedanken uns bei allen Mitwirkenden, die dieses Release möglich gemacht haben und mit Ihrer unermüdlichen Arbeit WordPress weiter entwickeln, sowie allen fleißigen Helfern, die die deutsche Version bereitzustellen &#8211; vielen Dank!</strong> </p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"http://blog.wpde.org/2015/04/24/wordpress-4-2-powell.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 4.1.2 Security-Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://blog.wpde.org/2015/04/22/wordpress-4-1-2-security-release.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"http://blog.wpde.org/2015/04/22/wordpress-4-1-2-security-release.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Apr 2015 20:38:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Passwort";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3125";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:538:"Das WordPress Security-Release 4.1.2 ist verfügbar &#8211; wir empfehlen, dass dieses Update schnellstmöglich durchgeführt wird. WordPress-Installationen, bei denen die Hintergrund-Aktualisierung nicht deaktiviert wurde, werden automatisch auf Version 4.1.2 aktualisiert. Nachdem die automatische Hintergrund-Aktualisierung durchgeführt wurde, erhält der Administrator eine Bestätigungs-E-Mail. Die offizielle deutschsprachige Vollversion 4.1.2 kann hier heruntergeladen werden. Alle Informationen zu dieser Version finden [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Olaf Schmitz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1265:"<p><strong class="teaser">Das <a href="https://wordpress.org/news/2015/04/wordpress-4-1-2/">WordPress Security-Release 4.1.2</a> ist verfügbar &#8211; wir empfehlen, dass dieses Update schnellstmöglich durchgeführt wird. WordPress-Installationen, bei denen die Hintergrund-Aktualisierung nicht deaktiviert wurde, werden automatisch auf Version 4.1.2 aktualisiert. Nachdem die automatische Hintergrund-Aktualisierung durchgeführt wurde, erhält der Administrator eine Bestätigungs-E-Mail. </strong></p>
<p>Die offizielle  deutschsprachige Vollversion 4.1.2 kann <a href="https://de.wordpress.org/latest-de_DE.zip">hier heruntergeladen</a> werden. Alle Informationen zu dieser Version finden sich im <a href="https://wordpress.org/news/2015/04/wordpress-4-1-2/">offiziellen Ankündigungsbeitrag</a>. Vor jeder Aktualisierung unbedingt ein <a href="http://faq.wpde.org/backup-von-wordpress-erstellen/">vollständiges Backup</a> aller Dateien und der Datenbank anlegen!</p>
<div style="margin: 20px 0pt; color: #c45500; font-size: 16px;">Wir bitten euch, Support-Fragen zu der neuen Version im <a href="http://forum.wpde.org/">Forum</a> zu stellen. Dort findet ihr Hilfe falls bei euch Probleme auftauchen oder ihr Fragen im Vorfeld der Aktualisierung habt.</div>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"http://blog.wpde.org/2015/04/22/wordpress-4-1-2-security-release.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Wartungs-Release WordPress 4.1.1 verfügbar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://blog.wpde.org/2015/02/19/wartungs-release-wordpress-4-1-1-verfuegbar.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:89:"http://blog.wpde.org/2015/02/19/wartungs-release-wordpress-4-1-1-verfuegbar.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Feb 2015 09:00:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3118";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:444:"WordPress 4.1.1 ist ein Wartungs-Release und seit kurzem verfügbar. Es wurden 21 Fehler aus Version 4.1 behoben. Weitere Informationen findest du in der Liste der Tickets und im Changelog. Das Update wird für alle WordPress Installationen automatisch ausgeliefert, die Auto-Updates unterstützen. Alternativ kannst du die Version 4.1.1 hier herunterladen oder über Dashboard → Aktualisierung manuell aktualisieren. Vielen Dank [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Birgit Olzem";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3394:"<p><strong class="teaser">WordPress 4.1.1 ist ein Wartungs-Release und seit kurzem verfügbar. Es wurden 21 Fehler aus Version 4.1 behoben. Weitere Informationen findest du in der <a href="https://core.trac.wordpress.org/query?milestone=4.1.1&amp;group=severity&amp;order=component">Liste der Tickets</a> und im <a href="https://core.trac.wordpress.org/log/branches/4.1?stop_rev=30974&amp;rev=31474">Changelog</a>.</strong></p>
<p>Das Update wird für alle WordPress Installationen automatisch ausgeliefert, <a href="https://wordpress.org/plugins/background-update-tester/">die Auto-Updates unterstützen</a>. Alternativ kannst du <a href="https://de.wordpress.org/latest-de_DE.zip">die Version 4.1.1 hier herunterladen</a> oder über <strong>Dashboard → Aktualisierung </strong>manuell aktualisieren.</p>
<p>Vielen Dank an alle Mitwirkenden zu 4.1.1: <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/chrico">ChriCo</a>,<a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>,<a href="https://profiles.wordpress.org/hissy">Takuro Hishikawa</a>, <a href="https://profiles.wordpress.org/ipm-frommen">Thorsten Frommen</a>,<a href="https://profiles.wordpress.org/iseulde">Iseulde</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/sippis">sippis</a>, <a href="https://profiles.wordpress.org/tmatsuur">tmatsuur</a>, <a href="https://profiles.wordpress.org/tyxla">Marin Atanasov</a>, <a href="https://profiles.wordpress.org/valendesigns">Derek Herman</a>, und <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
<p><strong>Im Gedenken an Kim Parsell</strong></p>
<p>Andrew Nacin gedenkt in dem <a href="https://wordpress.org/news/2015/02/wordpress-4-1-1/">Ankündigungsbeitrag zu 4.1.1</a> auch der <a href="https://make.wordpress.org/docs/2015/01/05/rip-kim-parsell/">verstorbenen Kim Parsell</a>. Sie war ein engagiertes Community Mitglied und ist unerwartet im Dezember von uns gegangen. In Memorandum an Kim wurde ein  <a href="https://make.wordpress.org/community/2015/01/15/remembering-kim-parsell/">Reisestipendium-Programm</a> ins Leben gerufen. Ich persönlich hatte im vergangenen Jahr die Ehre eins dieser Stipendien zu erhalten, die im Rahmen eines Pilotprojekts vergeben wurden. Somit konnte ich an dem Community Summit und dem WordCamp San Francisco teilzunehmen. Dort habe ich Kim Parsell auch persönlich kennengelernt. Wir vermissen Kim sehr.</p>
<p><strong>Support</strong></p>
<p>Falls du wider Erwarten Probleme mit diesem Release hast, kannst du dich gerne an einen der <a href="https://de.wordpress.org/hilfe/">Support-Kanäle</a> wenden. Bitte habe Verständnis dafür, dass wir im Rahmen der Kommentar-Funktion keinen Support leisten können.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:85:"http://blog.wpde.org/2015/02/19/wartungs-release-wordpress-4-1-1-verfuegbar.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"22";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Angeguckt: WordPress 4 – Das umfassende Training";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://blog.wpde.org/2015/01/28/wordpress-4-training.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"http://blog.wpde.org/2015/01/28/wordpress-4-training.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 Jan 2015 09:25:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Tutorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"verlosung";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:5:"Video";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3019";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:362:"Im Herbst 2014 war es endlich so weit: Das neue Video-Training zu WordPress 4 erschien im Galileo Press Verlag. Als Autoren-Paar konnte der Verlag die beiden bekannten WordPress Entwickler- &#38; Berater Birgit Olzem und René Reimann von Inpsyde gewinnen &#8211; was die DVD bietet und für wen sie etwas ist, erfahren Sie in meinem Erfahrungsbericht. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"André Goldmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4929:"<p><strong class="teaser">Im Herbst 2014 war es endlich so weit: Das neue Video-Training zu <a title="WordPress 4 Das umfassende Training" href="http://www.amazon.de/gp/product/3836234645/" target="_blank">WordPress 4 erschien im Galileo Press Verlag</a>. Als Autoren-Paar konnte der Verlag die beiden bekannten WordPress Entwickler- &amp; Berater Birgit Olzem und <a href="http://www.rene-reimann.de/">René Reimann</a> von Inpsyde gewinnen &#8211; was die DVD bietet und für wen sie etwas ist, erfahren Sie in meinem Erfahrungsbericht.</strong></p>
<p><img src="http://blog.wpde.org/files/2014/12/wp4-274x300.png" alt="wp4" width="274" height="300" class="alignleft size-medium wp-image-3102" />Aus meiner Referenten-Tätigkeit bei der <a title="121WATT - Online Marketing Seminare in Hamburg, Berlin &amp; München" href="http://www.121watt.de/" target="_blank">121WATT</a> rund um das Thema <a title="WordPress Deutschland" href="http://wpde.org/">WordPress</a>, SEO und Online Marketing weiß ich wie schwer es ist, ein so komplexes und gleichermaßen umfangreiches Thema wie WordPress in kleine Häppchen zu packen, die Anfänger und fortgeschrittene Nutzer gleichermaßen packt und lehrt. Die beiden Autoren haben hier wirklich sehr gute Arbeit geleistet und führen den Zuschauer <a title="WordPress FAQ" href="http://faq.wpde.org/installation/" target="_blank">Schritt für Schritt</a> zu seinem ersten WordPress Blog.</p>
<h2>Inhalt der Trainings-DVD</h2>
<p>Zu Beginn der DVD geht es rund um die Installation von WordPress. Einmal installiert, stellen Birgit und René das WordPress Backend im Detail vor. Besonders klasse finde ich die kleinen Tricks und versteckten Funktionen, die man oft alleine gar nicht findet. So habe auch ich noch einige Dinge gefunden, die mir im Vorfeld nicht sofort ins Auge gesprungen sind und meinen Arbeitstag effizienter machen &#8211; obwohl ich seit Jahren mit WordPress arbeite.<span id="more-3019"></span></p>
<p>Nach dem Erstellen erster Artikel und Seiten erfährt der Zuschauer wie man das Standard-WordPress-Theme an seine eigenen Wünsche anpassen und verändern kann. Durch den technischen Hintergrund von René bekommt man hier auch einige Hintergründe zur Theme-Entwicklung und dem WordPress Codex erklärt. Gerade wenn man später einmal vorhat in die Theme-Entwicklung zu gehen, helfen diese Hinweise ungemein weiter.</p>
<p>Gemeinsam mit den Autoren setzt man kleinere Teilprojekte selbst um und erweitert die Funktionen von WordPress soweit, dass man als Zuschauer sogar in der Lage ist, seine eigenen Produkte über einen mit WordPress erstellten Onlineshop zu verkaufen. Selbstverständlich zeigt das Team auch noch andere Lösungen, wie z.B. automatische Backups, den Versand von Newslettern und wie man Google Maps ganz einfach in seine Website integrieren kann.</p>
<p>Da es leider nicht reicht, einfach nur eine Website mit WordPress zu erstellen &amp; zu veröffentlichen, zeigt René Reimann wie man häufige Fehler und Problemstellen aufspürt und lösen kann. Hier spart man für die Zukunft echt eine Menge Zeit, da gerade die Fehlersuche oft die „Nadel im Heuhafen“ bedeutet.</p>
<p>Auch der Bereich responsive Webdesign ist Bestandteil der Trainings-DVD und wird abgerundet durch einige Tipps &amp; Tricks aus der Suchmaschinenoptimierung und dem Online Marketing für WordPress Blogs und Websites.</p>
<h2>Mein Fazit zur Trainings-DVD</h2>
<p>Wer noch keine WordPress Website erstellt hat und spätestens 2015 den Schritt zur eigenen Website plant, sollte nicht länger überlegen diese 40,- € in seine Weiterbildung zu investieren. Natürlich ist die Form der Video-Weiterbildung nur ein Teil der möglichen Weiterbildung. In Eigenregie muss man sich stetig weiterbilden und Interesse an WordPress haben, sei es im <a title="WordPress Forum" href="http://forum.wpde.org/">WordPress-Deutschland-Forum</a>, einschlägigen WordPress Blogs oder mit dem <a title="WPLetter - WordPress Newsletter" href="https://wpletter.de/">WPLetter von Sergej Müller</a> (Tipp!).</p>
<h2>Möchten Sie ein Exemplar vom DVD Training gewinnen?</h2>
<p>Ich finde die Trainings-DVD wirklich sinnvoll &#8211; gerade wer ein neues Projekt mit WordPress starten möchte, findet hier eine gute Gelegenheit sich weiterzubilden oder einige Lösungsansätze von WordPress kennenzulernen. Das Team der 121WATT und ich, möchten Sie dabei unterstützen und <strong>verlosen unter allen Kommentaren insgesamt 2 mal das WordPress 4 Training als DVD</strong>. Schreiben Sie mir per Kommentar was Sie für ein Projekt planen und wie Sie WordPress dabei verwenden werden &#8211; Ich freue mich auf Ihren Kommentar und Ihre Ideen! <strong>Teilnahmeschluss ist der 16.02.2015</strong> &#8211; eine Barauszahlung ist selbstverständlich nicht möglich <img src="http://s.w.org/images/core/emoji/72x72/1f609.png" alt="😉" class="wp-smiley" style="height: 1em; max-height: 1em;" /></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"http://blog.wpde.org/2015/01/28/wordpress-4-training.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:3:"131";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"Das WordCamp Köln 2015 sucht Experten – Call for Papers.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://blog.wpde.org/2015/01/27/das-wordcamp-koeln-2015-sucht-experten-call-for-papers.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:100:"http://blog.wpde.org/2015/01/27/das-wordcamp-koeln-2015-sucht-experten-call-for-papers.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 27 Jan 2015 07:50:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3089";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:423:"Das diesjährige WordCamp, welches die größte jährliche Veranstaltung rund um WordPress in Deutschland ist, findet in Köln statt. Dort geht es in vielen spannenden Vorträgen rund um das Thema WordPress. WordCamps dienen dem Austausch von Wissen, Knüpfen von Kontakten und Festigen von Freundschaften. Möchtest du dazu beitragen? In diesem Beitrag möchten die Organisatoren des WordCamp Cologne dich als [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Birgit Olzem";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1384:"<p><strong class="teaser">Das diesjährige WordCamp, welches die größte jährliche Veranstaltung rund um WordPress in Deutschland ist, findet in Köln statt. Dort geht es in vielen spannenden Vorträgen rund um das Thema WordPress. WordCamps dienen dem Austausch von Wissen, Knüpfen von Kontakten und Festigen von Freundschaften. Möchtest du dazu beitragen?</strong></p>
<p><span id="more-3089"></span></p>
<p>In diesem Beitrag möchten die <a href="http://2015.cologne.wordcamp.org/info/orga-team/">Organisatoren des WordCamp Cologne</a> dich als Experte/in gewinnen.</p>
<ul>
<li>Du arbeitest beruflich, nebenberuflich oder in deiner Freizeit mit WordPress?</li>
<li>Du bist Blogger/in, Designer/in, Entwickler/in, Spezialist/in für SEO oder Blogvermarktung, Webworker/in, Online-Redakteur/in, Software-Evangelist/in oder CEO einer Agentur?</li>
<li>Du kennst dich aus in einem speziellen WordPress-Theme und bist bereit, anderen davon zu erzählen?</li>
</ul>
<p>Wenn du mindestens zwei dieser Fragen mit JA beantworten kannst und Lust hast über dein Lieblingsthema zu sprechen, dann melde dich als Session-Speaker/in, denn DEIN Wissen ist gefragt.</p>
<p>Weitere Informationen und Anmeldung findest du auf der Seite des WordCamp Cologne: <a href="http://2015.cologne.wordcamp.org/">http://2015.cologne.wordcamp.org/</a></p>
<p>Bis bald beim WordCamp Köln 2015!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:96:"http://blog.wpde.org/2015/01/27/das-wordcamp-koeln-2015-sucht-experten-call-for-papers.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"The Blogging Software Dilemma";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://blog.wpde.org/2015/01/25/the-blogging-software-dilemma.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://blog.wpde.org/2015/01/25/the-blogging-software-dilemma.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 25 Jan 2015 18:41:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3060";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:371:"Vor nunmehr 12 Jahren, am 24.01.2003, hat Matt Mullenweg den Beitrag &#8222;The Blogging Software Dilemma&#8220; veröffentlicht, einen Tag später hat Mike Little dazu einen Kommentar geschrieben: Matt, If you’re serious about forking b2 I would be interested in contributing. I’m sure there are one or two others in the community who would be too. Perhaps [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Olaf Schmitz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2544:"<p><strong class="teaser">Vor nunmehr 12 Jahren, am 24.01.2003, hat Matt Mullenweg den Beitrag &#8222;<a href="http://ma.tt/2003/01/the-blogging-software-dilemma/">The Blogging Software Dilemma</a>&#8220; veröffentlicht, einen Tag später hat Mike Little dazu einen <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/#comment-445">Kommentar</a> geschrieben:</strong></p>
<blockquote><p>Matt,<br />
If you’re serious about forking b2 I would be interested in contributing. I’m sure there are one or two others in the community who would be too. Perhaps a post to the B2 forum, suggesting a fork would be a good starting point.</p></blockquote>
<p>Damit nahm eine unvergleichbare Erfolgsgeschichte ihren Anfang. Matt hatte damals das unter der <a href="http://de.wikipedia.org/wiki/GNU_General_Public_License"><strong>GPL</strong></a> lizensierte <a href="http://www.cafelog.com/"><strong>b2/cafelog</strong></a> System im Einsatz, das schon einige Zeit nicht mehr aktualisiert wurde. Matt und Mike haben kurzerhand begonnen einen <a href="http://de.wikipedia.org/wiki/Abspaltung_%28Softwareentwicklung%29"><strong>Fork</strong></a> zu erstellen und einige Wochen später, am <strong>27.05.2003</strong> wurde das erste WordPress-Release <a href="https://wordpress.org/news/2003/05/wordpress-now-available/">veröffentlicht</a>. Die <a href="https://wordpress.org/news/2004/01/wordpress-10/">Version 1.0</a> wurde ein knappes Jahr nach Matts Beitrag, am <strong>03.01.2004</strong>, veröffentlicht.</p>
<p>12 Jahre später ist WordPress das meistgenutze und erfolgreichste CMS auf unserem Planeten. Aus WordPress ist ein Milliarden-Business geworden &#8211; unzählige Freelancer und Agenturen verdienen damit ihren Lebensunterhalt. WordPress ist untrennbar mit der Idee von <a href="http://de.wikipedia.org/wiki/Open_Source"><strong>quelloffener Software</strong></a> verbunden und ein Paradebeispiele dafür, dass Business und die <strong>Open-Source</strong>-Philosophie kein Widerspruch sein müssen. Millionen Menschen nutzen das frei verfügbare und kostenlos erhältliche System, die Community ist lebendig, die Entwicklung aktiv und ein Ende noch lange nicht abzusehen.</p>
<blockquote><p><strong>WordPress is available completely free of charge under the GPL license. Enjoy!</strong></p></blockquote>
<p><img src="http://blog.wpde.org/files/2015/01/matt_mike.jpg" alt="Bildquelle www.wpress.eu" width="640" height="427" class="aligncenter size-full wp-image-3076" /></p>
<p><strong>Vielen Dank Mike und Matt!</strong></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://blog.wpde.org/2015/01/25/the-blogging-software-dilemma.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress 4.1 „Dinah“ wurde veröffentlicht";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://blog.wpde.org/2014/12/18/wordpress-4-1-dinah-wurde-veroeffentlicht.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://blog.wpde.org/2014/12/18/wordpress-4-1-dinah-wurde-veroeffentlicht.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 18 Dec 2014 20:10:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3034";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:454:"Diese Version ist der Jazz-Sängerin Dinah Washington gewidmet. Die offizielle englisch- und deutschsprachigen Versionen stehen hier zum Download bereit. Sie werden auch über die automatische Aktualisierung ausgeliefert. Wie bei jedem großen Versionssprung gibt es auch zu diesem Release kein Upgradepaket. Eine Aktualisierung musst du entweder automatisch aus dem Administrationsbereich durchführen oder du lädst das Release herunter und [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Birgit Olzem";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:12963:"<p><strong class="teaser">Diese Version ist der Jazz-Sängerin <a href="http://de.wikipedia.org/wiki/Dinah_Washington">Dinah Washington</a> gewidmet. Die offizielle englisch- und deutschsprachigen Versionen stehen hier zum <a href="http://de.wordpress.org/wordpress-4.1-de_DE.zip">Download</a> bereit. Sie werden auch über die automatische Aktualisierung ausgeliefert.</strong></p>
<p>Wie bei jedem großen Versionssprung gibt es auch zu diesem Release kein Upgradepaket. Eine Aktualisierung musst du entweder automatisch aus dem Administrationsbereich durchführen oder du lädst das Release herunter und führst es manuell durch. Auf de.wordpress.org haben wir die Sprachdateien bereits eingespielt, nach einer automatischen Aktualisierung bleiben alle Bereiche deutschsprachig.</p>
<p>Eine ausführliche Auflistung aller Neuigkeiten findest du im <a href="https://codex.wordpress.org/Version_4.1">Codex</a>.</p>
<p><span id="more-3034"></span></p>
<h2 style="text-align: center;">Vorstellung von Twenty Fifteen</h2>
<p><a href="http://blog.wpde.org/files/2014/12/theme.png"><img class="aligncenter size-large wp-image-3037" src="http://blog.wpde.org/files/2014/12/theme-1024x533.png" alt="theme" width="960" height="499" /></a></p>
<h3>Das neueste Standard-Theme Twenty Fifteen ist für Blogs konzipiert und auf ein klares Erscheinungsbild ausgerichtet.<a href="http://blog.wpde.org/files/2014/12/mobile.png"><img class="alignright size-medium wp-image-3038" src="http://blog.wpde.org/files/2014/12/mobile-300x249.png" alt="mobile" width="300" height="249" /></a></h3>
<p>Mit Hilfe von <a href="https://www.google.com/get/noto/">Googles Schriftfamilie Noto</a> bietet Twenty Fifteen eine makellose Sprachunterstützung.</p>
<p>Die gradlinige Typografie lässt sich auf jeder Bildschirmgröße lesen.</p>
<p>Deine Inhalte stehen immer im Mittelpunkt, ganz gleich, ob sie auf einem Smartphone, Tablet, Laptop oder Desktop-Computer angesehen werden.<br />
<span class="clear"></span></p>
<h2 style="text-align: center;">Ablenkungsfreies Schreiben</h2>
<p>&nbsp;</p>
<h3><a href="http://blog.wpde.org/files/2014/12/wordpress-4-1-focus-e1418466766981.jpg"><img class="aligncenter size-full wp-image-3043" src="http://blog.wpde.org/files/2014/12/wordpress-4-1-focus-e1418466766981.jpg" alt="wordpress-4-1-focus-e1418466766981" width="1023" height="811" /></a></h3>
<h3><em>Einfach schreiben.</em></h3>
<p>Manchmal möchtest du dich einfach darauf konzentrieren, deine Gedanken in die richtigen Worte zu fassen. Probiere dazu den Modus für <strong>ablenkungsfreies Schreiben</strong> aus. Sobald du anfängst zu schreiben, wird alles ausgeblendet, was dich ablenkt. So kannst du dich völlig auf das Schreiben konzentrieren. Alle Bearbeitungs-Werkzeuge sind direkt wieder da, sobald du sie benötigst.</p>
<h2>Die Feinheiten</h2>
<h4>Wähle eine Sprache</h4>
<p>Aktuell liegt WordPress 4.2 bereits in <span id="translations-count">44</span> Sprachen vor und weitere Übersetzungen sind in Arbeit. Du kannst über das Menü für Allgemeine Einstellungen zu jeder Übersetzung wechseln.</p>
<h4>Überall abmelden</h4>
<p>Hattest du schonmal die Sorge, dich von einem öffentlichen Computer nicht abgemeldet zu haben? Dann kannst du dich jetzt in deinem Profil ganz entspannt von überall abmelden.</p>
<h4>Einbettung von Vine</h4>
<p>Das Einbinden von Vine Videos ist so einfach wie das Einfügen einer URL in einer eigenen Zeile in einem Beitrag. Für weitere unterstütze Medien schaue dir die <a href="http://codex.wordpress.org/Embeds">vollständige Liste</a> an.</p>
<h4>Empfehlungen für Plugins</h4>
<p>Beim Installieren neuer Plugins werden dir nun Plugins empfohlen. Die Empfehlungen basieren auf Plugins, welche du und andere Anwender installliert haben.</p>
<h3>Änderungen unter der Haube</h3>
<p>Auch für Entwickler gibt es einige Neuerungen. So ist es unter anderem nun möglich, mit der <a href="https://codex.wordpress.org/Theme_Customization_API">Customizer API</a> Einstellungen je nach gerade dargestellter Seite anzuzeigen. Des Weiteren wird seit Version 4.1 Theme-Entwicklern empfohlen, den title-Tag nicht hart in die <code>header.php</code> zu schreiben, sondern die neu eingeführte <code>add_theme_support( \'title-tag\' );</code>-Funktion zu nutzen (weitere Informationen dazu findet ihr im <a href="https://codex.wordpress.org/Title_Tag">Codex</a>).</p>
<p>Metadaten-, Daten- und Term-Queries unterstützen nun komplexere abhängige Logik, beispielsweise <code>A AND ( B OR C )</code>(weitere Informationen hierzu lassen sich im <a href="https://make.wordpress.org/core/2014/10/02/meta-date-and-tax-query-improvements-in-wp-4-1/">Make-Blogbeitrag finden</a>). Daneben wurden einige weitere hilfreiche Template-Tags eingeführt, wie etwa <code>the_posts_pagination()</code>, um eine paginierte Navigation der Beitragsseiten auszugeben oder<code>get_the_archive_title()</code>, um den Titel der aktuellen Archivseite auszugeben – passend zum jeweiligen Archivtyp (also Autor, Taxonomie, Datum und so weiter).</p>
<h2>Download und wichtige Hinweise</h2>
<p>Die offizielle englischsprachige Version findest du im <a href="http://wpde.org/download/englisch/">Downloadbereich</a> und die offizielle deutschsprachige Version steht auf de.wordpress.org zur Verfügung.</p>
<div><strong>»</strong> <a href="http://de.wordpress.org/wordpress-4.1-de_DE.zip"><strong>Download WordPress 4.1 DE</strong></a></div>
<div></div>
<div>Beachte bitte unbedingt die Mindestvoraussetzungen für WordPress! PHP muss mindestens in Version 5.2.4 vorliegen, MySQL in Version 5.0.15. Ein Upgrade ist sonst weder möglich, noch empfehlenswert. Wir raten jedoch dringend zu mindestens PHP 5.4 und MySQL 5.5, denn ältere Versionen erhalten keine Sicherheitsupdates mehr.</div>
<p>WordPress 4.1 (DE) enthält insgesamt sechs Sprachdateien in informeller Anrede (»Du«), die in der DE-Edition und der offiziellen deutschsprachigen Version bereits enthalten sind: Die Hauptsprachdatei mit der separaten Sprachdatei für Kontinente und Städte, die Sprachdatei für die Administration, die Sprachdatei für die Netzwerk-Administration und die Sprachdateien für die Standardthemes. Die informellen (»Du«) und formellen (»Sie«) Sprachdateien kannst du im <a href="http://wpde.org/download/sprachdatei/">Downloadbereich</a> auch einzeln herunterladen.</p>
<p><strong>Bitte achte unbedingt darauf, vor der manuellen oder automatischen Aktualisierung eine vollständige <a href="http://faq.wpde.org/backup-von-wordpress-erstellen/">Datensicherung</a> anzulegen. Das beinhaltet alle Dateien auf deinem Webspace und ein vollständiges Backup der Datenbank.</strong></p>
<p><strong>Bitte wende dich mit Fragen oder Problemen an das <a href="http://forum.wpde.org/">Forum</a>. Dort findest du Hilfe, falls Probleme auftauchen, du Fragen im Vorfeld der Aktualisierung hast oder Unterstützung zu den neuen Funktionen benötigst.</strong></p>
<p>In der <a href="http://faq.wpde.org/">FAQ</a> findest du viele Informationen und Hilfetexte, unter anderem zur <a href="http://wpde.org/installation">Installation</a> und zum <a href="http://faq.wpde.org/backup-von-wordpress-erstellen/">Anlegen eines Backups</a>. Weitere Hilfe findest du in unserem <a href="http://forum.wpde.org/">Support-Forum</a>, im offiziellen <a href="http://wordpress.org/support/">englischsprachigen Forum</a>, in unserem <a href="http://blog.wpde.org/2007/02/02/irc-channel-wordpress-deutschland.html">IRC-Channel</a> unter <code>#wordpress-deutschland</code> oder im englischsprachigen Channel <code>#wordpress</code> (beide <code>irc.freenode.net</code>).</p>
<p>Solltest du Fehler in der Sprachdatei finden, so melde sie bitte <a href="http://forum.wpde.org/sprachdatei/">hier im Forum</a>. Gerne kannst du Vorschläge direkt in GlotPress eintragen. Siehe dazu auch unseren Blogbeitrag: <a href="http://blog.wpde.org/2013/06/03/wordpress-auf-deutsch-hilf-mit.html">WordPress auf Deutsch &#8211; hilf mit!</a></p>
<p><strong>Wir bedanken uns bei allen Mitwirkenden, die dieses Release möglich gemacht haben und mit Ihrer unermüdlichen Arbeit WordPress weiter entwickeln, sowie allen fleißigen Helfern, die es uns ermöglichen, zeitnah die deutsche Version bereitzustellen – vielen Dank!</strong></p>
<h4>Aktive Übersetzer und Validatoren für die deutschsprachige Versionen</h4>
<ul id="wp-people-group-validators" class="wp-people-group compact" style="color: #444444;">
<li id="wp-person-fstaude" class="wp-person"><a style="color: #0074a2;" href="http://profiles.wordpress.org/fstaude"><img class="gravatar" src="http://0.gravatar.com/avatar/60d7918457ae5ab8bafbf551fd67c2a2?s=30" alt="Frank Staude" /></a><a class="web" style="color: #0074a2;" href="http://profiles.wordpress.org/fstaude">Frank Staude</a></li>
<li id="wp-person-coachbirgit" class="wp-person"><a style="color: #0074a2;" href="http://profiles.wordpress.org/coachbirgit"><img class="gravatar" src="http://0.gravatar.com/avatar/159829b410bba9413b62bb60aae0a949?s=30" alt="Birgit Olzem" /></a><a class="web" style="color: #0074a2;" href="http://profiles.wordpress.org/coachbirgit">Birgit Olzem</a></li>
<li id="wp-person-nullbyte" class="wp-person"><a style="color: #0074a2;" href="http://profiles.wordpress.org/nullbyte"><img class="gravatar" src="http://0.gravatar.com/avatar/782dd6ceec537f2a878f6b31fcdcb8f1?s=30" alt="Robert Windisch" /></a><a class="web" style="color: #0074a2;" href="http://profiles.wordpress.org/nullbyte">Robert Windisch</a></li>
<li id="wp-person-zodiac1978" class="wp-person"><a style="color: #0074a2;" href="http://profiles.wordpress.org/zodiac1978"><img class="gravatar" src="http://0.gravatar.com/avatar/c82f3ac01fcf49e733b482214c7483cd?s=30" alt="Torsten Landsiedel" /></a><a class="web" style="color: #0074a2;" href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a></li>
<li id="wp-person-ocean90" class="wp-person"><a style="color: #0074a2;" href="http://profiles.wordpress.org/ocean90"><img class="gravatar" src="http://0.gravatar.com/avatar/3e8e161d97d793bd8fc2dcd62583bb76?s=30" alt="Dominik Schilling (ocean90)" /></a><a class="web" style="color: #0074a2;" href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a></li>
<li id="wp-person-glueckpress" class="wp-person"><a style="color: #0074a2;" href="http://profiles.wordpress.org/glueckpress"><img class="gravatar" src="http://0.gravatar.com/avatar/8a50eb4ed9bb4354d6df8e881befe64e?s=30" alt="Caspar" /></a><a class="web" style="color: #0074a2;" href="http://profiles.wordpress.org/glueckpress">Caspar Hübinger</a></li>
<li id="wp-person-la-geek" class="wp-person"><a style="color: #0074a2;" href="http://profiles.wordpress.org/la-geek"><img class="gravatar" src="http://0.gravatar.com/avatar/c5e13dd8e1a318747e9700eb5ecd0a8b?s=30" alt="La Geek" /></a><a class="web" style="color: #0074a2;" href="http://profiles.wordpress.org/la-geek">La Geek</a></li>
<li id="wp-person-swissky" class="wp-person"><a style="color: #0074a2;" href="http://profiles.wordpress.org/swissky"><img class="gravatar" src="http://0.gravatar.com/avatar/37390e548c9592c15d93cffed03c9f47?s=30" alt="Kevin Kyburz (@swissky)" /></a><a class="web" style="color: #0074a2;" href="http://profiles.wordpress.org/swissky">Kevin Kyburz (@swissky)</a></li>
</ul>
<h4>Mitübersetzer:</h4>
<p><a style="color: #0074a2;" href="http://profiles.wordpress.org/arkonisus">Christian Ruggeberg</a>, <a style="color: #0074a2;" href="http://profiles.wordpress.org/gerritg">gerritg</a>, <a style="color: #0074a2;" href="http://profiles.wordpress.org/janreim">Jan Reimers</a>, <a style="color: #0074a2;" href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a> und <a style="color: #0074a2;" href="http://profiles.wordpress.org/pixolin">pixolin</a>.<br />
Wer alles aktiv an der Entwicklung und Übersetzung beteiligt war, kann man jederzeit im Administrationsbereich unter <code>/wp-admin/credits.php</code> abrufen.</p>
<h3>Hinweis</h3>
<p>Zum Schluss noch ein Hinweis in Bezug auf die hier bisher angebotene Community-Edition: Seit dem Release 3.8 werden wir keine spezielle <em>DE-Edition</em> mehr anbieten. Die neueste Version der deutschsprachigen WordPress-Version wird nun direkt von de.wordpress.org zum Download angeboten.<br />
Die Community-Edition wurde vor etlichen Jahren aus dem Umstand heraus angeboten, dass nicht alle Texte in WordPress durch die Sprachdatei übersetzt wurden. Es war also nötig, etliche Texte direkt in den Dateien zu übersetzen. Im Laufe der Jahre wurde das in der Weiterentwicklung des WordPress-Cores immer stärker berücksichtigt, und glücklicherweise werden mittlerweile alle Texte durch die Sprachdatei übersetzt. Es gibt also auf Dateiebene keinen Unterschied mehr zwischen der deutsch- und der englischsprachigen Version. Damit ist die Grundlage für eine spezielle DE-Edition nicht mehr gegeben.</p>
<p>Wir wünschen dir viel Vergnügen mit WordPress 4.1 „Dinah“!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://blog.wpde.org/2014/12/18/wordpress-4-1-dinah-wurde-veroeffentlicht.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"24";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"1. Release Kandidat zu WordPress 4.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://blog.wpde.org/2014/12/12/1-release-kandidat-zu-wordpress-4-1.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:81:"http://blog.wpde.org/2014/12/12/1-release-kandidat-zu-wordpress-4-1.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 12 Dec 2014 08:40:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:7:"Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:17:"Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:13:"WordPress 4.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3013";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:455:"Der erste Release Kandidat der kommenden WordPress Version 4.1 wurde veröffentlicht. Wer die Entwicklerversion testen möchte, kann sich das “WordPress Beta Tester Plugin” installieren oder sich die englische Version hier runterladen (zip) und die deutsch-sprachige Version hier herunterladen (.zip). Die finale Version 4.1 soll voraussichtlich am 16. Dezember 2014 veröffentlicht werden. Weitere Informationen finden sich im offiziellen [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Birgit Olzem";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1742:"<p><strong class="teaser">Der erste Release Kandidat der kommenden WordPress Version 4.1 wurde veröffentlicht. Wer die Entwicklerversion testen möchte, kann sich das “<a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester Plugin</a>” installieren oder sich die englische Version <a href="https://wordpress.org/wordpress-4.1-RC1.zip">hier runterladen</a> (zip) und die deutsch-sprachige Version <a href="https://de.wordpress.org/wordpress-4.1-RC1-de_DE.zip">hier herunterladen</a> (.zip).</strong></p>
<p>Die finale Version 4.1 soll voraussichtlich am 16. Dezember 2014 veröffentlicht werden. Weitere Informationen finden sich im offiziellen <a href="https://wordpress.org/news/2014/12/wordpress-4-1-release-candidate/">Ankündigungsbeitrag</a>.<span id="more-3013"></span><span id="more-2997"></span></p>
<h2>Mach mit und teste gründlich!</h2>
<p>Du kannst mithelfen, dass WordPress immer besser wird. Teste die Beta-Version so gründlich wie es für dich geht. Falls du einen Fehler gefunden hast, kannst du diesen im <a href="https://wordpress.org/support/forum/alphabeta">Support-Forum Alpha/Beta</a> melden. Natürlich kannst du auch direkt einen <em>bug report</em>im <a href="https://make.wordpress.org/core/reports/">WordPress Trac</a>einreichen. Bitte schau vor dem Erstellen eines Forenbeitrags oder Ticket im Trac, <a href="https://core.trac.wordpress.org/tickets/major">ob dieser Fehler schon bekannt ist </a>und schau nach, <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.1">ob es schon eine Lösung</a> dazu gibt.</p>
<h2>Danke</h2>
<p>Ein großes Dankeschön an alle diejenigen, die WordPress zu dem machen, was es heute ist!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:77:"http://blog.wpde.org/2014/12/12/1-release-kandidat-zu-wordpress-4-1.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Sicherheits-Update WordPress 4.0.1 veröffentlicht";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://blog.wpde.org/2014/11/21/sicherheits-update-wordpress-4-0-1-veroeffentlicht.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:96:"http://blog.wpde.org/2014/11/21/sicherheits-update-wordpress-4-0-1-veroeffentlicht.html#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Nov 2014 23:17:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:7:"Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:18:"Sicherheitsrelease";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:15:"WordPress 4.0.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://blog.wpde.org/?p=3000";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:532:"WordPress 4.0.1 ist nun als Sicherheitsupdate verfügbar. Es wird empfohlen, dass dieses Update schnellstmöglich durchgeführt wird. WordPress-Installationen, bei denen die Hintergrund-Aktualisierung aktiv ist, werden innerhalb der kommenden 12 Stunden automatisch auf Version 4.0.1 aktualisiert. Nachdem die automatische Hintergrund-Aktualisierung durchgeführt wurde, erhält der Administrator eine Bestätigungs-E-Mail.  (Wenn du immernoch WordPress 3.9.2, 3.8.4 oder 3.7.4 einsetzt, wird WordPress automatisch auf [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Birgit Olzem";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4666:"<p><strong class="teaser">WordPress 4.0.1 ist nun als Sicherheitsupdate verfügbar. Es wird empfohlen, dass dieses Update schnellstmöglich durchgeführt wird.</strong></p>
<p><strong class="teaser">WordPress-Installationen, bei denen die Hintergrund-Aktualisierung aktiv ist, werden innerhalb der kommenden 12 Stunden automatisch auf Version 4.0.1 aktualisiert. Nachdem die automatische Hintergrund-Aktualisierung durchgeführt wurde, erhält der Administrator eine Bestätigungs-E-Mail. </strong></p>
<p>(Wenn du immernoch WordPress 3.9.2, 3.8.4 oder 3.7.4 einsetzt, wird WordPress automatisch auf 3.9.3, 3.8.5 oder 3.7.5 aktualisiert. Es wird aber keinen weiteren Support für ältere Versionen mehr geben und es wird ein Update auf 4.0.1 empfohlen.)</p>
<p><span id="more-3000"></span></p>
<p>Die Version 3.9.2 und ältere waren von einer kritischen Cross-Site-Scripting Schwachstelle betroffen. Diese wurde frühzeitig geschlossen und hatte keinen Einfluss auf die Version 4.0. Die Version 4.0.1 schließt allerdings folgende acht Sicherheitslücken:</p>
<ul>
<li>Drei <a href="http://de.wikipedia.org/wiki/Cross-Site-Scripting">Cross-Site-Scripting</a> Lücken, womit die Benutzer mit der Rolle Mitarbeiter und Autor die Website manipulieren konnten. Entdeckt von <a href="http://joncave.co.uk/">Jon Cave</a>, <a href="http://www.miqrogroove.com/">Robert Chapin</a> und <a href="https://johnblackbourn.com/">John Blackbourn</a> vom WordPress Sicherheitsteam.</li>
<li>Eine <a href="http://de.wikipedia.org/wiki/Cross-Site-Request-Forgery">Cross-Site-Request-Forgery</a> Lücke, womit Benutzer unberechtigt aufgefordert werden könnten, das Passwort zu ändern.</li>
<li>Ein  Problem, womit man bei der Passwort-Abfrage einen <a href="http://de.wikipedia.org/wiki/Denial_of_Service">Denial of Service</a> auslösen konnte. Gemeldet wurde dies von  <a href="http://www.behindthefirewalls.com/">Javier Nieto Arevalo</a> und <a href="http://www.devconsole.info/">Andres Rojas Guerrero</a>.</li>
<li>Weitere mögliche serverseitige Übergriffs-Attacken, wenn WordPress Aufrufe über HTTPS tätigen musste. Gemeldet von <a href="https://profiles.wordpress.org/vortfu">Ben Bidner</a>.</li>
<li>Eine extrem unglückliche Hashtag-Überschneidung hätte es ermöglichen können, dass Benutzerkonten manipuliert werden konnten. Gemeldet von  <a href="http://david.dw-perspective.org.uk/">David Anderson</a>.</li>
<li>WordPress annuliert nun den einmaligen Link in der Passwort-Zurücksetzen-Mail, falls dem Benutzer doch sein Passwort wieder eingefallen ist, sich anmeldet und dann die E-Mail Adresse ändert. Gemeldet von <a href="https://twitter.com/MomenBassel">Momen Bassel</a>, <a href="http://c0dehouse.blogspot.in/">Tanoy Bose</a> und <a href="https://managewp.com/">Bojan Slavković of ManageWP</a>.</li>
</ul>
<p>WordPress 4.0.1 behebt noch weitere 23 Fehler, die in 4.0 aufgefallen sind. Es wurden zwei gravierende Änderungen vorgenommen.</p>
<p>Es wird darum gebeten, Sicherheitsfehler direkt an das <a href="https://codex.wordpress.org/FAQ_Security">Sicherheitsteam zu melden</a>, damit solche Lücken schnell geschlossen werden können. Weitere Informationen zu diesem Sicherheits-Release sind in den <a href="https://codex.wordpress.org/Version_4.0.1">Release-Notes</a> und in der <a href="https://core.trac.wordpress.org/log/branches/4.0?rev=30475&amp;stop_rev=29710">Liste der Änderungen</a> zu finden.</p>
<p>Sofern die Hintergrund-Aktualisierung deaktiviert wurde, kann aus dem Administrationsbereich die Aktualisierung manuell eingeleitet werden.</p>
<p><strong>Die offizielle  deutschsprachige Vollversion 4.0.1 kann <a href="https://de.wordpress.org/latest-de_DE.zip">hier heruntergeladen</a> werden.</strong> Weitere Informationen zu dieser Version finden sich im <a href="https://wordpress.org/news/2014/11/wordpress-4-0-1/">offiziellen Ankündigungsbeitrag</a> und im <a href="http://codex.wordpress.org/Version_4.0.1">Codex</a>.</p>
<p><strong>Vor jeder Aktualisierung unbedingt ein <a href="http://faq.wpde.org/backup-von-wordpress-erstellen/">vollständiges Backup</a> aller Dateien und der Datenbank anlegen!</strong></p>
<div style="margin: 20px 0pt; color: #c45500; font-size: 16px;">Wir bitten euch, Support-Fragen zu der neuen Version im <a href="http://forum.wpde.org/">Forum</a> zu stellen. Dort findet ihr Hilfe falls bei euch Probleme auftauchen oder ihr Fragen im Vorfeld der Aktualisierung habt.</div>
<h3>Beta-Version</h3>
<p>Auch die aktuelle <a title="Download WordPress 4.1 Beta 2" href="https://wordpress.org/wordpress-4.1-beta2.zip">WordPress 4.1 Beta 2</a> enthält diese Sicherheitspatches.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:92:"http://blog.wpde.org/2014/11/21/sicherheits-update-wordpress-4-0-1-veroeffentlicht.html/feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"38";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:25:"http://blog.wpde.org/feed";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:4:"date";s:29:"Sun, 18 Oct 2015 13:45:25 GMT";s:6:"server";s:6:"Apache";s:4:"vary";s:26:"Accept-Encoding,User-Agent";s:12:"x-powered-by";s:14:"PHP/5.5.21-pl0";s:10:"x-pingback";s:31:"http://blog.wpde.org/xmlrpc.php";s:13:"last-modified";s:29:"Mon, 27 Apr 2015 20:03:06 GMT";s:10:"connection";s:5:"close";s:12:"content-type";s:34:"application/rss+xml; charset=UTF-8";}s:5:"build";s:14:"20150611172108";}', 'no') ; 
INSERT INTO `gx_options` VALUES (438, '_transient_timeout_feed_mod_bdc5f20c97996c8ac39224fac23b29b0', '1445219125', 'no') ; 
INSERT INTO `gx_options` VALUES (439, '_transient_feed_mod_bdc5f20c97996c8ac39224fac23b29b0', '1445175925', 'no') ; 
INSERT INTO `gx_options` VALUES (440, '_transient_timeout_feed_96c7dc9bec0a68fc131c26d6c304d150', '1445219126', 'no') ; 
INSERT INTO `gx_options` VALUES (441, '_transient_feed_96c7dc9bec0a68fc131c26d6c304d150', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:2:"

";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:4:"0.92";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:37:"
	
	
	
	
	
	

	

	
	
	
	
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"Planet WordPress » Deutschsprachiger Channel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:22:"http://planet.wpde.org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:103:"Der Planet listet Inhalte ausgewählter Blogs auf, die regelmäßig Beiträge zu WordPress publizieren.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 17 Oct 2015 14:02:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"docs";a:1:{i:0;a:5:{s:4:"data";s:34:"http://backend.userland.com/rss092";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"de-DE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress: deutschsprachige Meetups";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.perun.net/2015/10/14/wordpress-deutschsprachige-meetups/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"Neu: Unser E-Book zu WooCommerce – Onlineshop mit WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://marketpress.de/2015/woocommerce-ebook/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress News #148 / Attacken auf XML-RPC Schnittstelle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/148/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress: Angaben im Header und Footer einfügen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.perun.net/2015/10/08/wordpress-angaben-im-header-und-footer-einfuegen/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress News #147 / Start in den Backup-Oktober";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/147/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress News #146 / Child Themes aktuell halten";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/146/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"WordPress News #145 / WordCamp Switzerland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/145/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WordPress 4.3: Handbuch für Administratoren";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://www.perun.net/2015/09/17/wordpress-4-3-handbuch-fuer-administratoren/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordCamp Berlin 2015";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://www.perun.net/2015/09/14/wordcamp-berlin-2015/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress 4.3.1 Sicherheits- und Wartungs-Release veröffentlicht";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"https://de.wordpress.org/2015/09/15/wordpress-4-3-1-sicherheits-und-wartungs-release-veroeffentlicht/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:8;s:7:"headers";a:10:{s:4:"date";s:29:"Sun, 18 Oct 2015 13:45:26 GMT";s:6:"server";s:6:"Apache";s:4:"vary";s:26:"Accept-Encoding,User-Agent";s:12:"x-powered-by";s:14:"PHP/5.5.21-pl0";s:10:"x-pingback";s:33:"http://planet.wpde.org/xmlrpc.php";s:13:"last-modified";s:29:"Sat, 17 Oct 2015 14:02:09 GMT";s:4:"etag";s:34:""af85beb6e5affc72af93845288f17e72"";s:14:"content-length";s:4:"2475";s:10:"connection";s:5:"close";s:12:"content-type";s:34:"application/rss+xml; charset=UTF-8";}s:5:"build";s:14:"20150611172108";}', 'no') ; 
INSERT INTO `gx_options` VALUES (442, '_transient_timeout_feed_mod_96c7dc9bec0a68fc131c26d6c304d150', '1445219126', 'no') ; 
INSERT INTO `gx_options` VALUES (443, '_transient_feed_mod_96c7dc9bec0a68fc131c26d6c304d150', '1445175926', 'no') ; 
INSERT INTO `gx_options` VALUES (444, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1445219128', 'no') ; 
INSERT INTO `gx_options` VALUES (445, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:117:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"WordPress Plugins » View: Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:34:"WordPress Plugins » View: Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 18 Oct 2015 13:27:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:30:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29832@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"The Wordfence WordPress security plugin provides free enterprise-class WordPress security, protecting your website from hacks and malware.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"753@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Advanced Custom Fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/advanced-custom-fields/#post-25254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Mar 2011 04:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"25254@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:68:"Customise WordPress with powerful, professional and intuitive fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"elliotcondon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Really Simple CAPTCHA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/really-simple-captcha/#post-9542";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2009 02:17:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"9542@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"18101@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"12073@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2141@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Hello Dolly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/hello-dolly/#post-5790";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2008 22:11:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"5790@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-PageNavi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wp-pagenavi/#post-363";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 23:17:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"363@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"Adds a more advanced paging navigation interface.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Lester Chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Yoast SEO";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8321@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:114:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"132@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Arne Brachhold";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Google Analytics by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2316@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:124:"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29860@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2082@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Regenerate Thumbnails";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/regenerate-thumbnails/#post-6743";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 23 Aug 2008 14:38:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"6743@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Allows you to regenerate your thumbnails after changing the thumbnail sizes.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:25:"Alex Mills (Viper007Bond)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"1169@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 13 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"23862@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:28:"Your WordPress, Streamlined.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2572@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"15@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Duplicate Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/duplicate-post/#post-2646";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Dec 2007 17:40:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2646@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:22:"Clone posts and pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Lopo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Disable Comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wordpress.org/plugins/disable-comments/#post-26907";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 May 2011 04:42:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26907@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:134:"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Samir Shah";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WP Multibyte Patch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wp-multibyte-patch/#post-28395";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Jul 2011 12:22:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"28395@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Multibyte functionality enhancement for the WordPress Japanese package.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"plugin-master";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Black Studio TinyMCE Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Nov 2011 15:06:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"31973@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"The visual editor widget for Wordpress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marco Chiesi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"21738@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Page Builder by SiteOrigin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/siteorigin-panels/#post-51888";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 10:36:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"51888@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:111:"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Greg Priday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"50539@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:127:"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Meta Slider";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/ml-slider/#post-49521";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Feb 2013 16:56:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"49521@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Matcha Labs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"Duplicator";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/duplicator/#post-26607";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 16 May 2011 12:15:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26607@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:88:"Duplicate, clone, backup, move and transfer an entire site from one location to another.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Cory Lamle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"UpdraftPlus Backup and Restoration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/updraftplus/#post-38058";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 May 2012 15:14:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"38058@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"David Anderson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"https://wordpress.org/plugins/wpclef/#post-47509";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Dec 2012 01:25:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"47509@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"Modern two-factor that people love to use: strong authentication without passwords or tokens; single sign on/off; magical user experience.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Dave Ross";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"https://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:12:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 18 Oct 2015 13:45:27 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:25:"strict-transport-security";s:11:"max-age=360";s:7:"expires";s:29:"Sun, 18 Oct 2015 14:02:03 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Sun, 18 Oct 2015 13:27:03 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20150611172108";}', 'no') ; 
INSERT INTO `gx_options` VALUES (446, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1445219128', 'no') ; 
INSERT INTO `gx_options` VALUES (447, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1445175928', 'no') ; 
INSERT INTO `gx_options` VALUES (448, '_transient_timeout_dash_b44ed4b9d5450ba0f7c6bd32b0ce0350', '1445219128', 'no') ; 
INSERT INTO `gx_options` VALUES (449, '_transient_dash_b44ed4b9d5450ba0f7c6bd32b0ce0350', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://blog.wpde.org/2015/04/27/wordpress-4-2-1-security-release-veroeffentlicht.html\'>WordPress 4.2.1 Security-Release veröffentlicht</a> <span class="rss-date">27. April 2015</span><div class="rssSummary">WordPress 4.2.1 wurde soeben veröffentlicht – diese Version behebt kritische Sicherheitslücken, wir empfehlen dringend alle älteren Versionen umgehend zu aktualisieren. Das Sicherheitsproblem wurde dem Release-Team erst einige Stunden zuvor mitgeteilt, das Team hat sich entschlossen sofort zu handeln und eine Security-Release zu veröffentlichen. Sofern die Hintergrund-Aktualisierung nicht deaktiviert wurde, wird die Version automatisch eingespielt. Weitere [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://www.perun.net/2015/10/14/wordpress-deutschsprachige-meetups/\'>WordPress: deutschsprachige Meetups</a></li><li><a class=\'rsswidget\' href=\'https://marketpress.de/2015/woocommerce-ebook/\'>Neu: Unser E-Book zu WooCommerce – Onlineshop mit WordPress</a></li><li><a class=\'rsswidget\' href=\'https://wpletter.de/archive/148/\'>WordPress News #148 / Attacken auf XML-RPC Schnittstelle</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Beliebtes Plugin:</span> <a href=\'https://wordpress.org/plugins/google-analytics-dashboard-for-wp/\' class=\'dashboard-news-plugin-link\'>Google Analytics Dashboard for WP</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=google-analytics-dashboard-for-wp&amp;_wpnonce=4295d4686b&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Google Analytics Dashboard for WP\'>Installation</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `gx_options` VALUES (450, 'theme_mods_zerif-lite', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1445176105;s:4:"data";a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:15:"sidebar-aboutus";N;s:16:"sidebar-ourfocus";a:4:{i:0;s:17:"ctup-ads-widget-1";i:1;s:17:"ctup-ads-widget-2";i:2;s:17:"ctup-ads-widget-3";i:3;s:17:"ctup-ads-widget-4";}s:20:"sidebar-testimonials";a:3:{i:0;s:21:"zerif_testim-widget-1";i:1;s:21:"zerif_testim-widget-2";i:2;s:21:"zerif_testim-widget-3";}s:15:"sidebar-ourteam";a:4:{i:0;s:19:"zerif_team-widget-1";i:1;s:19:"zerif_team-widget-2";i:2;s:19:"zerif_team-widget-3";i:3;s:19:"zerif_team-widget-4";}}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (452, 'theme_mods_twentysixteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1445176346;s:4:"data";a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";N;s:9:"sidebar-3";a:0:{}s:18:"orphaned_widgets_1";a:0:{}s:18:"orphaned_widgets_2";a:0:{}}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (458, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (460, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:65:"https://downloads.wordpress.org/release/de_CH/wordpress-4.3.1.zip";s:6:"locale";s:5:"de_CH";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:65:"https://downloads.wordpress.org/release/de_CH/wordpress-4.3.1.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1447610821;s:15:"version_checked";s:5:"4.3.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (461, 'wdev-frash', 'a:3:{s:7:"plugins";a:1:{s:23:"wp-smushit/wp-smush.php";i:1445176578;}s:5:"queue";a:2:{s:32:"7de3619981caadc55f30a002bfb299f6";a:3:{s:6:"plugin";s:23:"wp-smushit/wp-smush.php";s:4:"type";s:5:"email";s:7:"show_at";i:1445176578;}s:32:"fc50097023d0d34c5a66f6cddcf77694";a:3:{s:6:"plugin";s:23:"wp-smushit/wp-smush.php";s:4:"type";s:4:"rate";s:7:"show_at";i:1445781378;}}s:4:"done";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (464, 'rewrite_rules', 'a:164:{s:40:"(?:event)/([^/]+)/(\\d{4}-\\d{2}-\\d{2})/?$";s:56:"index.php?tribe_events=$matches[1]&eventDate=$matches[2]";s:28:"(?:event)/([^/]+)/(?:all)/?$";s:74:"index.php?tribe_events=$matches[1]&post_type=tribe_events&eventDisplay=all";s:45:"(?:event)/([^/]+)/(\\d{4}-\\d{2}-\\d{2})/ical/?$";s:63:"index.php?tribe_events=$matches[1]&eventDate=$matches[2]&ical=1";s:25:"(?:event)/([^/]+)/ical/?$";s:56:"index.php?ical=1&name=$matches[1]&post_type=tribe_events";s:28:"(?:events)/(?:page)/(\\d+)/?$";s:68:"index.php?post_type=tribe_events&eventDisplay=list&paged=$matches[1]";s:38:"(?:events)/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?post_type=tribe_events&eventDisplay=list&feed=$matches[1]";s:23:"(?:events)/(?:month)/?$";s:51:"index.php?post_type=tribe_events&eventDisplay=month";s:37:"(?:events)/(?:list)/(?:page)/(\\d+)/?$";s:68:"index.php?post_type=tribe_events&eventDisplay=list&paged=$matches[1]";s:22:"(?:events)/(?:list)/?$";s:50:"index.php?post_type=tribe_events&eventDisplay=list";s:23:"(?:events)/(?:today)/?$";s:49:"index.php?post_type=tribe_events&eventDisplay=day";s:27:"(?:events)/(\\d{4}-\\d{2})/?$";s:73:"index.php?post_type=tribe_events&eventDisplay=month&eventDate=$matches[1]";s:33:"(?:events)/(\\d{4}-\\d{2}-\\d{2})/?$";s:71:"index.php?post_type=tribe_events&eventDisplay=day&eventDate=$matches[1]";s:13:"(?:events)/?$";s:53:"index.php?post_type=tribe_events&eventDisplay=default";s:18:"(?:events)/ical/?$";s:39:"index.php?post_type=tribe_events&ical=1";s:38:"(?:events)/(\\d{4}-\\d{2}-\\d{2})/ical/?$";s:78:"index.php?post_type=tribe_events&ical=1&eventDisplay=day&eventDate=$matches[1]";s:60:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:page)/(\\d+)/?$";s:97:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list&paged=$matches[2]";s:55:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:month)/?$";s:80:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=month";s:69:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:list)/(?:page)/(\\d+)/?$";s:97:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list&paged=$matches[2]";s:54:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:list)/?$";s:79:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list";s:55:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:today)/?$";s:78:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=day";s:73:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(?:day)/(\\d{4}-\\d{2}-\\d{2})/?$";s:100:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=day&eventDate=$matches[2]";s:59:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(\\d{4}-\\d{2})/?$";s:102:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=month&eventDate=$matches[2]";s:65:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/(\\d{4}-\\d{2}-\\d{2})/?$";s:100:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=day&eventDate=$matches[2]";s:50:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/feed/?$";s:89:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list&feed=rss2";s:50:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/ical/?$";s:68:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&ical=1";s:75:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:78:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&feed=$matches[2]";s:45:"(?:events)/(?:category)/(?:[^/]+/)*([^/]+)/?$";s:79:"index.php?post_type=tribe_events&tribe_events_cat=$matches[1]&eventDisplay=list";s:44:"(?:events)/(?:tag)/([^/]+)/(?:page)/(\\d+)/?$";s:84:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list&paged=$matches[2]";s:39:"(?:events)/(?:tag)/([^/]+)/(?:month)/?$";s:67:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=month";s:53:"(?:events)/(?:tag)/([^/]+)/(?:list)/(?:page)/(\\d+)/?$";s:84:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list&paged=$matches[2]";s:38:"(?:events)/(?:tag)/([^/]+)/(?:list)/?$";s:66:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list";s:39:"(?:events)/(?:tag)/([^/]+)/(?:today)/?$";s:65:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=day";s:57:"(?:events)/(?:tag)/([^/]+)/(?:day)/(\\d{4}-\\d{2}-\\d{2})/?$";s:87:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=day&eventDate=$matches[2]";s:43:"(?:events)/(?:tag)/([^/]+)/(\\d{4}-\\d{2})/?$";s:89:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=month&eventDate=$matches[2]";s:49:"(?:events)/(?:tag)/([^/]+)/(\\d{4}-\\d{2}-\\d{2})/?$";s:87:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=day&eventDate=$matches[2]";s:34:"(?:events)/(?:tag)/([^/]+)/feed/?$";s:76:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list&feed=rss2";s:34:"(?:events)/(?:tag)/([^/]+)/ical/?$";s:55:"index.php?post_type=tribe_events&tag=$matches[1]&ical=1";s:59:"(?:events)/(?:tag)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:65:"index.php?post_type=tribe_events&tag=$matches[1]&feed=$matches[2]";s:29:"(?:events)/(?:tag)/([^/]+)/?$";s:66:"index.php?post_type=tribe_events&tag=$matches[1]&eventDisplay=list";s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:8:"event/?$";s:32:"index.php?post_type=tribe_events";s:38:"event/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=tribe_events&feed=$matches[1]";s:33:"event/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=tribe_events&feed=$matches[1]";s:25:"event/page/([0-9]{1,})/?$";s:50:"index.php?post_type=tribe_events&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:33:"event/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"event/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"event/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"event/([^/]+)/trackback/?$";s:39:"index.php?tribe_events=$matches[1]&tb=1";s:46:"event/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?tribe_events=$matches[1]&feed=$matches[2]";s:41:"event/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?tribe_events=$matches[1]&feed=$matches[2]";s:34:"event/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?tribe_events=$matches[1]&paged=$matches[2]";s:41:"event/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?tribe_events=$matches[1]&cpage=$matches[2]";s:26:"event/([^/]+)(/[0-9]+)?/?$";s:51:"index.php?tribe_events=$matches[1]&page=$matches[2]";s:22:"event/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"event/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"event/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"venue/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"venue/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"venue/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"venue/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"venue/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"venue/([^/]+)/trackback/?$";s:38:"index.php?tribe_venue=$matches[1]&tb=1";s:34:"venue/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?tribe_venue=$matches[1]&paged=$matches[2]";s:41:"venue/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?tribe_venue=$matches[1]&cpage=$matches[2]";s:26:"venue/([^/]+)(/[0-9]+)?/?$";s:50:"index.php?tribe_venue=$matches[1]&page=$matches[2]";s:22:"venue/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"venue/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"venue/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"venue/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"venue/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"organizer/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"organizer/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"organizer/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"organizer/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"organizer/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"organizer/([^/]+)/trackback/?$";s:42:"index.php?tribe_organizer=$matches[1]&tb=1";s:38:"organizer/([^/]+)/page/?([0-9]{1,})/?$";s:55:"index.php?tribe_organizer=$matches[1]&paged=$matches[2]";s:45:"organizer/([^/]+)/comment-page-([0-9]{1,})/?$";s:55:"index.php?tribe_organizer=$matches[1]&cpage=$matches[2]";s:30:"organizer/([^/]+)(/[0-9]+)?/?$";s:54:"index.php?tribe_organizer=$matches[1]&page=$matches[2]";s:26:"organizer/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"organizer/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"organizer/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"organizer/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"organizer/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:54:"events/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?tribe_events_cat=$matches[1]&feed=$matches[2]";s:49:"events/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?tribe_events_cat=$matches[1]&feed=$matches[2]";s:42:"events/category/(.+?)/page/?([0-9]{1,})/?$";s:56:"index.php?tribe_events_cat=$matches[1]&paged=$matches[2]";s:24:"events/category/(.+?)/?$";s:38:"index.php?tribe_events_cat=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (469, 'theme_mods_twentyfourteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1445182954;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";N;s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (471, '_transient_twentyfourteen_category_count', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (472, 'theme_mods_vantage', 'a:3:{i:0;b:0;s:17:"version_activated";s:5:"1.4.4";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1445184376;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"sidebar-footer";N;s:14:"sidebar-header";a:0:{}}}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (474, 'siteorigin_panels_initial_version', '2.2', 'no') ; 
INSERT INTO `gx_options` VALUES (475, 'siteorigin_panels_settings', 'a:0:{}', 'yes') ; 
INSERT INTO `gx_options` VALUES (477, 'widget_circleicon-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (478, 'widget_siteorigin-panels-builder', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (479, 'widget_siteorigin-panels-post-content', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (480, 'widget_siteorigin-panels-postloop', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (481, 'widget_headline-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (482, 'widget_vantage-social-media', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `gx_options` VALUES (483, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1447610840;s:7:"checked";a:4:{s:8:"gobrenix";s:3:"1.0";s:13:"twentyfifteen";s:3:"1.3";s:14:"twentyfourteen";s:3:"1.5";s:7:"vantage";s:5:"1.4.4";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `gx_options` VALUES (484, '_transient_twentyfifteen_categories', '1', 'yes') ; 
INSERT INTO `gx_options` VALUES (485, '_transient_doing_cron', '1447610812.5839068889617919921875', 'yes') ; 
INSERT INTO `gx_options` VALUES (487, '_site_transient_timeout_theme_roots', '1447612615', 'yes') ; 
INSERT INTO `gx_options` VALUES (488, '_site_transient_theme_roots', 'a:4:{s:8:"gobrenix";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:7:"vantage";s:7:"/themes";}', 'yes') ; 
INSERT INTO `gx_options` VALUES (489, '_transient_timeout_rn_last_notification_480f7b6', '1447718819', 'no') ; 
INSERT INTO `gx_options` VALUES (490, '_transient_rn_last_notification_480f7b6', 'O:8:"stdClass":1:{s:5:"error";s:7:"nothing";}', 'no') ; 
INSERT INTO `gx_options` VALUES (491, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1447610833;s:8:"response";a:5:{s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.3.3";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.3.3.zip";}s:39:"siteorigin-panels/siteorigin-panels.php";O:8:"stdClass":6:{s:2:"id";s:5:"40030";s:4:"slug";s:17:"siteorigin-panels";s:6:"plugin";s:39:"siteorigin-panels/siteorigin-panels.php";s:11:"new_version";s:5:"2.2.1";s:3:"url";s:48:"https://wordpress.org/plugins/siteorigin-panels/";s:7:"package";s:66:"https://downloads.wordpress.org/plugin/siteorigin-panels.2.2.1.zip";}s:43:"the-events-calendar/the-events-calendar.php";O:8:"stdClass":6:{s:2:"id";s:5:"11861";s:4:"slug";s:19:"the-events-calendar";s:6:"plugin";s:43:"the-events-calendar/the-events-calendar.php";s:11:"new_version";s:6:"3.12.6";s:3:"url";s:50:"https://wordpress.org/plugins/the-events-calendar/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/the-events-calendar.3.12.6.zip";}s:25:"wp-members/wp-members.php";O:8:"stdClass":6:{s:2:"id";s:5:"10426";s:4:"slug";s:10:"wp-members";s:6:"plugin";s:25:"wp-members/wp-members.php";s:11:"new_version";s:7:"3.0.7.2";s:3:"url";s:41:"https://wordpress.org/plugins/wp-members/";s:7:"package";s:53:"https://downloads.wordpress.org/plugin/wp-members.zip";}s:23:"wp-smushit/wp-smush.php";O:8:"stdClass":6:{s:2:"id";s:4:"5534";s:4:"slug";s:10:"wp-smushit";s:6:"plugin";s:23:"wp-smushit/wp-smush.php";s:11:"new_version";s:5:"2.1.2";s:3:"url";s:41:"https://wordpress.org/plugins/wp-smushit/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/wp-smushit.2.1.2.zip";}}s:12:"translations";a:0:{}s:9:"no_update";a:10:{s:43:"admin-color-schemes/admin-color-schemes.php";O:8:"stdClass":6:{s:2:"id";s:5:"45554";s:4:"slug";s:19:"admin-color-schemes";s:6:"plugin";s:43:"admin-color-schemes/admin-color-schemes.php";s:11:"new_version";s:3:"2.1";s:3:"url";s:50:"https://wordpress.org/plugins/admin-color-schemes/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/admin-color-schemes.zip";}s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.5";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.5.zip";}s:42:"bwp-google-xml-sitemaps/bwp-simple-gxs.php";O:8:"stdClass":6:{s:2:"id";s:5:"21948";s:4:"slug";s:23:"bwp-google-xml-sitemaps";s:6:"plugin";s:42:"bwp-google-xml-sitemaps/bwp-simple-gxs.php";s:11:"new_version";s:5:"1.3.1";s:3:"url";s:54:"https://wordpress.org/plugins/bwp-google-xml-sitemaps/";s:7:"package";s:66:"https://downloads.wordpress.org/plugin/bwp-google-xml-sitemaps.zip";}s:37:"login-customizer/login-customizer.php";O:8:"stdClass":6:{s:2:"id";s:5:"55995";s:4:"slug";s:16:"login-customizer";s:6:"plugin";s:37:"login-customizer/login-customizer.php";s:11:"new_version";s:5:"1.0.5";s:3:"url";s:47:"https://wordpress.org/plugins/login-customizer/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/login-customizer.zip";}s:43:"floating-social-bar/floating-social-bar.php";O:8:"stdClass":6:{s:2:"id";s:5:"42494";s:4:"slug";s:19:"floating-social-bar";s:6:"plugin";s:43:"floating-social-bar/floating-social-bar.php";s:11:"new_version";s:5:"1.1.7";s:3:"url";s:50:"https://wordpress.org/plugins/floating-social-bar/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/floating-social-bar.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:32:"login-lockdown/loginlockdown.php";O:8:"stdClass":6:{s:2:"id";s:4:"3760";s:4:"slug";s:14:"login-lockdown";s:6:"plugin";s:32:"login-lockdown/loginlockdown.php";s:11:"new_version";s:6:"v1.6.1";s:3:"url";s:45:"https://wordpress.org/plugins/login-lockdown/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/login-lockdown.1.6.1.zip";}s:25:"sucuri-scanner/sucuri.php";O:8:"stdClass":6:{s:2:"id";s:5:"27199";s:4:"slug";s:14:"sucuri-scanner";s:6:"plugin";s:25:"sucuri-scanner/sucuri.php";s:11:"new_version";s:6:"1.7.13";s:3:"url";s:45:"https://wordpress.org/plugins/sucuri-scanner/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/sucuri-scanner.1.7.13.zip";}s:33:"w3-total-cache/w3-total-cache.php";O:8:"stdClass":7:{s:2:"id";s:4:"9376";s:4:"slug";s:14:"w3-total-cache";s:6:"plugin";s:33:"w3-total-cache/w3-total-cache.php";s:11:"new_version";s:7:"0.9.4.1";s:3:"url";s:45:"https://wordpress.org/plugins/w3-total-cache/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/w3-total-cache.0.9.4.1.zip";s:14:"upgrade_notice";s:140:"Thanks for using W3 Total Cache! This release includes important security updates designed to contribute to a secure WordPress installation.";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":6:{s:2:"id";s:4:"5899";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:5:"2.3.5";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/wordpress-seo.2.3.5.zip";}}}', 'yes') ;
#
# End of data contents of table gx_options
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `gx_postmeta`
#

DROP TABLE IF EXISTS `gx_postmeta`;


#
# Table structure of table `gx_postmeta`
#

CREATE TABLE `gx_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_postmeta (97 records)
#
 
INSERT INTO `gx_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `gx_postmeta` VALUES (2, 4, '_wp_attached_file', '2015/06/10968747_852590338115812_1938437724_o-1.jpg') ; 
INSERT INTO `gx_postmeta` VALUES (3, 4, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:752;s:4:"file";s:51:"2015/06/10968747_852590338115812_1938437724_o-1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:51:"10968747_852590338115812_1938437724_o-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:51:"10968747_852590338115812_1938437724_o-1-300x110.jpg";s:5:"width";i:300;s:6:"height";i:110;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:52:"10968747_852590338115812_1938437724_o-1-1024x376.jpg";s:5:"width";i:1024;s:6:"height";i:376;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `gx_postmeta` VALUES (4, 4, '_wp_attachment_image_alt', 'Gobrenix Schabe') ; 
INSERT INTO `gx_postmeta` VALUES (5, 1, '_edit_lock', '1434055975:1') ; 
INSERT INTO `gx_postmeta` VALUES (6, 5, '_menu_item_type', 'custom') ; 
INSERT INTO `gx_postmeta` VALUES (7, 5, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `gx_postmeta` VALUES (8, 5, '_menu_item_object_id', '5') ; 
INSERT INTO `gx_postmeta` VALUES (9, 5, '_menu_item_object', 'custom') ; 
INSERT INTO `gx_postmeta` VALUES (10, 5, '_menu_item_target', '') ; 
INSERT INTO `gx_postmeta` VALUES (11, 5, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `gx_postmeta` VALUES (12, 5, '_menu_item_xfn', '') ; 
INSERT INTO `gx_postmeta` VALUES (13, 5, '_menu_item_url', 'http://localhost:88/gobrenix.com/') ; 
INSERT INTO `gx_postmeta` VALUES (15, 6, '_menu_item_type', 'post_type') ; 
INSERT INTO `gx_postmeta` VALUES (16, 6, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `gx_postmeta` VALUES (17, 6, '_menu_item_object_id', '2') ; 
INSERT INTO `gx_postmeta` VALUES (18, 6, '_menu_item_object', 'page') ; 
INSERT INTO `gx_postmeta` VALUES (19, 6, '_menu_item_target', '') ; 
INSERT INTO `gx_postmeta` VALUES (20, 6, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `gx_postmeta` VALUES (21, 6, '_menu_item_xfn', '') ; 
INSERT INTO `gx_postmeta` VALUES (22, 6, '_menu_item_url', '') ; 
INSERT INTO `gx_postmeta` VALUES (24, 2, '_edit_lock', '1434062714:1') ; 
INSERT INTO `gx_postmeta` VALUES (25, 2, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (26, 2, '_yoast_wpseo_focuskw', 'gobrenix,artists,psr,dj,deejay,prog,goa,psy,psytrance,psychadelic,artist') ; 
INSERT INTO `gx_postmeta` VALUES (27, 2, '_yoast_wpseo_title', 'Gobrenix - Artists & Deejays') ; 
INSERT INTO `gx_postmeta` VALUES (28, 2, '_yoast_wpseo_linkdex', '23') ; 
INSERT INTO `gx_postmeta` VALUES (29, 9, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (30, 9, '_edit_lock', '1434066509:1') ; 
INSERT INTO `gx_postmeta` VALUES (31, 9, '_wp_page_template', 'templates/artist.php') ; 
INSERT INTO `gx_postmeta` VALUES (32, 9, '_yoast_wpseo_focuskw', 'si-moon') ; 
INSERT INTO `gx_postmeta` VALUES (33, 9, '_yoast_wpseo_linkdex', '84') ; 
INSERT INTO `gx_postmeta` VALUES (42, 14, '_EventOrigin', 'events-calendar') ; 
INSERT INTO `gx_postmeta` VALUES (43, 14, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (44, 14, '_edit_lock', '1434063533:1') ; 
INSERT INTO `gx_postmeta` VALUES (45, 14, '_EventShowMapLink', '1') ; 
INSERT INTO `gx_postmeta` VALUES (46, 14, '_EventShowMap', '1') ; 
INSERT INTO `gx_postmeta` VALUES (47, 15, '_OrganizerOrigin', 'events-calendar') ; 
INSERT INTO `gx_postmeta` VALUES (48, 15, '_yoast_wpseo_focuskw', 'test') ; 
INSERT INTO `gx_postmeta` VALUES (49, 15, '_OrganizerOrganizer', 'Sandro Gossweiler') ; 
INSERT INTO `gx_postmeta` VALUES (50, 15, '_OrganizerPhone', '') ; 
INSERT INTO `gx_postmeta` VALUES (51, 15, '_OrganizerWebsite', '') ; 
INSERT INTO `gx_postmeta` VALUES (52, 15, '_OrganizerEmail', '') ; 
INSERT INTO `gx_postmeta` VALUES (53, 16, '_VenueOrigin', 'events-calendar') ; 
INSERT INTO `gx_postmeta` VALUES (54, 16, '_yoast_wpseo_focuskw', 'test') ; 
INSERT INTO `gx_postmeta` VALUES (55, 16, '_EventShowMapLink', '1') ; 
INSERT INTO `gx_postmeta` VALUES (56, 16, '_EventShowMap', '1') ; 
INSERT INTO `gx_postmeta` VALUES (57, 16, '_VenueVenue', 'Gobrenix Studios') ; 
INSERT INTO `gx_postmeta` VALUES (58, 16, '_VenueAddress', 'Poststrasse') ; 
INSERT INTO `gx_postmeta` VALUES (59, 16, '_VenueCity', 'Widnau') ; 
INSERT INTO `gx_postmeta` VALUES (60, 16, '_VenueCountry', 'Switzerland') ; 
INSERT INTO `gx_postmeta` VALUES (61, 16, '_VenueProvince', 'St. Gallen') ; 
INSERT INTO `gx_postmeta` VALUES (62, 16, '_VenueState', '') ; 
INSERT INTO `gx_postmeta` VALUES (63, 16, '_VenueZip', '9443') ; 
INSERT INTO `gx_postmeta` VALUES (64, 16, '_VenuePhone', '') ; 
INSERT INTO `gx_postmeta` VALUES (65, 16, '_VenueURL', '') ; 
INSERT INTO `gx_postmeta` VALUES (66, 16, '_VenueStateProvince', 'St. Gallen') ; 
INSERT INTO `gx_postmeta` VALUES (67, 14, '_EventStartDate', '2015-06-20 17:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (68, 14, '_EventEndDate', '2015-06-20 22:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (69, 14, '_EventDuration', '18000') ; 
INSERT INTO `gx_postmeta` VALUES (70, 14, '_EventVenueID', '16') ; 
INSERT INTO `gx_postmeta` VALUES (71, 14, '_EventCurrencySymbol', 'CHF') ; 
INSERT INTO `gx_postmeta` VALUES (72, 14, '_EventCurrencyPosition', 'suffix') ; 
INSERT INTO `gx_postmeta` VALUES (73, 14, '_EventCost', '10') ; 
INSERT INTO `gx_postmeta` VALUES (74, 14, '_EventURL', '') ; 
INSERT INTO `gx_postmeta` VALUES (75, 14, '_EventOrganizerID', '15') ; 
INSERT INTO `gx_postmeta` VALUES (76, 14, '_yoast_wpseo_focuskw', 'test') ; 
INSERT INTO `gx_postmeta` VALUES (77, 14, '_yoast_wpseo_linkdex', '37') ; 
INSERT INTO `gx_postmeta` VALUES (78, 18, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (79, 18, '_edit_lock', '1434066041:1') ; 
INSERT INTO `gx_postmeta` VALUES (80, 18, '_wp_page_template', 'default') ; 
INSERT INTO `gx_postmeta` VALUES (81, 18, '_yoast_wpseo_focuskw', 'links') ; 
INSERT INTO `gx_postmeta` VALUES (82, 18, '_yoast_wpseo_title', 'Gobrenix - Links & References') ; 
INSERT INTO `gx_postmeta` VALUES (83, 18, '_yoast_wpseo_metadesc', 'Some links with references and many more about and from Gobrenix Records directly on their homepage.') ; 
INSERT INTO `gx_postmeta` VALUES (84, 18, '_yoast_wpseo_linkdex', '51') ; 
INSERT INTO `gx_postmeta` VALUES (85, 23, '_wp_attached_file', '2015/06/simoon.jpg') ; 
INSERT INTO `gx_postmeta` VALUES (86, 23, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:7:{s:7:"percent";d:7.0345684812183133516327870893292129039764404296875;s:5:"bytes";i:14375;s:11:"size_before";i:204348;s:10:"size_after";i:189973;s:4:"time";d:0.1600000000000000033306690738754696212708950042724609375;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;}s:5:"sizes";a:3:{s:9:"thumbnail";O:8:"stdClass":5:{s:7:"percent";d:8.25;s:5:"bytes";i:894;s:11:"size_before";i:10840;s:10:"size_after";i:9946;s:4:"time";d:0.0200000000000000004163336342344337026588618755340576171875;}s:6:"medium";O:8:"stdClass":5:{s:7:"percent";d:8.300000000000000710542735760100185871124267578125;s:5:"bytes";i:2154;s:11:"size_before";i:25954;s:10:"size_after";i:23800;s:4:"time";d:0.01000000000000000020816681711721685132943093776702880859375;}s:5:"large";O:8:"stdClass":5:{s:7:"percent";d:6.7599999999999997868371792719699442386627197265625;s:5:"bytes";i:11327;s:11:"size_before";i:167554;s:10:"size_after";i:156227;s:4:"time";d:0.13000000000000000444089209850062616169452667236328125;}}}') ; 
INSERT INTO `gx_postmeta` VALUES (87, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1066;s:4:"file";s:18:"2015/06/simoon.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"simoon-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"simoon-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"simoon-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:15:"Michael Winkler";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:44:"MICWINC • http://facebook.com/micwincphoto";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `gx_postmeta` VALUES (88, 23, '_wp_attachment_image_alt', 'Si-Moon live in Innsbruck') ; 
INSERT INTO `gx_postmeta` VALUES (89, 9, '_thumbnail_id', '23') ; 
INSERT INTO `gx_postmeta` VALUES (90, 26, '_EventOrigin', 'events-calendar') ; 
INSERT INTO `gx_postmeta` VALUES (91, 26, '_edit_last', '1') ; 
INSERT INTO `gx_postmeta` VALUES (92, 26, '_edit_lock', '1441906996:1') ; 
INSERT INTO `gx_postmeta` VALUES (93, 26, '_EventShowMapLink', '1') ; 
INSERT INTO `gx_postmeta` VALUES (94, 26, '_EventShowMap', '1') ; 
INSERT INTO `gx_postmeta` VALUES (95, 26, '_EventStartDate', '2015-09-10 08:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (96, 26, '_EventEndDate', '2015-09-10 17:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (97, 26, '_EventStartDateUTC', '2015-09-10 06:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (98, 26, '_EventEndDateUTC', '2015-09-10 15:00:00') ; 
INSERT INTO `gx_postmeta` VALUES (99, 26, '_EventDuration', '32400') ; 
INSERT INTO `gx_postmeta` VALUES (100, 26, '_EventVenueID', '0') ; 
INSERT INTO `gx_postmeta` VALUES (101, 26, '_EventCurrencySymbol', '') ; 
INSERT INTO `gx_postmeta` VALUES (102, 26, '_EventCurrencyPosition', 'suffix') ; 
INSERT INTO `gx_postmeta` VALUES (103, 26, '_EventCost', '') ; 
INSERT INTO `gx_postmeta` VALUES (104, 26, '_EventURL', '') ; 
INSERT INTO `gx_postmeta` VALUES (105, 26, '_EventOrganizerID', '0') ; 
INSERT INTO `gx_postmeta` VALUES (106, 26, '_EventTimezone', 'Europe/Zurich') ; 
INSERT INTO `gx_postmeta` VALUES (107, 26, '_EventTimezoneAbbr', 'CEST') ;
#
# End of data contents of table gx_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------


#
# Delete any existing table `gx_posts`
#

DROP TABLE IF EXISTS `gx_posts`;


#
# Table structure of table `gx_posts`
#

CREATE TABLE `gx_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_posts (20 records)
#
 
INSERT INTO `gx_posts` VALUES (1, 1, '2015-06-11 19:30:32', '2015-06-11 17:30:32', 'Willkommen zur deutschen Version von WordPress. Dies ist der erste Beitrag. Sie können ihn bearbeiten oder löschen. Um Spam zu vermeiden, gehen Sie doch gleich mal in den Pluginbereich und aktivieren die entsprechenden Plugins.', 'Hallo Welt!', '', 'publish', 'open', 'open', '', 'hallo-welt', '', '', '2015-06-11 19:30:32', '2015-06-11 17:30:32', '', 0, 'http://localhost:88/gobrenix.com/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `gx_posts` VALUES (2, 1, '2015-06-11 19:30:32', '2015-06-11 17:30:32', 'Infos über die Artisten kommen später hierhin :)

[list_children]', 'Artists', '', 'publish', 'open', 'open', '', 'artists', '', '', '2015-06-12 00:18:29', '2015-06-11 22:18:29', '', 0, 'http://localhost:88/gobrenix.com/?page_id=2', 0, 'page', '', 1) ; 
INSERT INTO `gx_posts` VALUES (4, 1, '2015-06-11 21:43:49', '2015-06-11 19:43:49', 'Gobrenix Schabe', 'Gobrenix Schabe', '', 'inherit', 'open', 'open', '', '10968747_852590338115812_1938437724_o-1', '', '', '2015-06-11 21:43:58', '2015-06-11 19:43:58', '', 0, 'http://localhost:88/gobrenix.com/wp-content/uploads/2015/06/10968747_852590338115812_1938437724_o-1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `gx_posts` VALUES (5, 1, '2015-06-11 23:27:15', '2015-06-11 21:27:15', '', 'Home', '', 'publish', 'open', 'open', '', 'startseite', '', '', '2015-06-12 01:53:04', '2015-06-11 23:53:04', '', 0, 'http://localhost:88/gobrenix.com/?p=5', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `gx_posts` VALUES (6, 1, '2015-06-11 23:27:16', '2015-06-11 21:27:16', ' ', '', '', 'publish', 'open', 'open', '', '6', '', '', '2015-06-12 01:53:04', '2015-06-11 23:53:04', '', 0, 'http://localhost:88/gobrenix.com/?p=6', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `gx_posts` VALUES (7, 1, '2015-06-12 00:01:09', '2015-06-11 22:01:09', 'Dies ist ein Beispiel einer statischen Seite. Sie können sie bearbeiten und beispielsweise Infos über Sie oder das Weblog eingeben, damit die Leser wissen, woher Sie kommen und was Sie machen. Sie können entweder beliebig viele Hauptseiten (wie diese hier) oder Unterseiten, die sich in der Hierachiestruktur den Hauptseiten unterordnen, anlegen. Sie können sie auch alle innerhalb von WordPress ändern und verwalten. Als stolzer Besitzer eines neuen WordPress-Blogs, sollten Sie zur Übersichtsseite, dem <a href="http://localhost:88/gobrenix.com/wp-admin/">Dashboard</a> gehen, diese Seite löschen und damit loslegen, eigene Inhalte zu erstellen. Viel Spass!', 'Artists', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-06-12 00:01:09', '2015-06-11 22:01:09', '', 2, 'http://localhost:88/gobrenix.com/2015/06/12/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (8, 1, '2015-06-12 00:01:39', '2015-06-11 22:01:39', 'Infos über die Artisten kommen später hierhin :)', 'Artists', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-06-12 00:01:39', '2015-06-11 22:01:39', '', 2, 'http://localhost:88/gobrenix.com/2015/06/12/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (9, 1, '2015-06-12 00:04:52', '2015-06-11 22:04:52', 'Simon Schneider alias Si-Moon was born on the 15.07.1992 in Swiss. At his first psytrance party in 2008 as he recognized that the powerfull bass wich controled his heartbeat and give him the full boody goose pumps he get addicted to the bass
Since this moment he know what was to do: He need to become a DJ, becouse as a DJ you can control hundert of peoples with your heartbeat and drag them into your powerfull spell of you own crazy fantasies. The People can come with you through your own wonderful fantasy world, where time and matter is no issue, where just you and the music is, to the maximum escalation of your body and mind.

One year ago Si-Moon played his first live act . After this he became quite popular in Swiss and he was booked out every weekend several times. And the curve does not weaken, it rises steeply. Now he plays every weekend in the biggest clubs of switzerland.
The Labehead from PSR, Necmi, heard his liveset and took him directly to the PSR familiy. This was the best was Si-Moon could passing. Becouse this is the label with the same kind uf music.
PSR Music will make a new music era, an music revolution! Now is Simon working very hard on his first ep: "Lets get Dirty" This EP will be out soon. The soundstyle from Si-Moon is indescribably. Its a new kind of Music. Its somethink like aggressive progreesiv fullon with one piece of dubstep elements. He call it by himself "dirty.prog!" He surprised the visitors all the time with new and powerful basslines, and blast them away with the power of his music. When Si-Moon plays at a party, no one will stand around, all are dancing in the spell of his music.', 'Si-Moon', '', 'publish', 'open', 'open', '', 'si-moon', '', '', '2015-06-12 01:49:43', '2015-06-11 23:49:43', '', 2, 'http://localhost:88/gobrenix.com/?page_id=9', 0, 'page', '', 0) ; 
INSERT INTO `gx_posts` VALUES (10, 1, '2015-06-12 00:04:52', '2015-06-11 22:04:52', 'Infos über de Simoooon', 'Si-Moon', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2015-06-12 00:04:52', '2015-06-11 22:04:52', '', 9, 'http://localhost:88/gobrenix.com/2015/06/12/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (11, 1, '2015-06-12 00:18:29', '2015-06-11 22:18:29', 'Infos über die Artisten kommen später hierhin :)

[list_children]', 'Artists', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-06-12 00:18:29', '2015-06-11 22:18:29', '', 2, 'http://localhost:88/gobrenix.com/2015/06/12/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (14, 1, '2015-06-12 01:01:11', '2015-06-11 23:01:11', 'Irgend en inhalt &amp; so ...', 'Test entry', '', 'publish', 'open', 'open', '', 'test-entry', '', '', '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 0, 'http://localhost:88/gobrenix.com/?post_type=tribe_events&#038;p=14', 0, 'tribe_events', '', 0) ; 
INSERT INTO `gx_posts` VALUES (15, 1, '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 'Sandro Gossweiler', '', 'publish', 'open', 'open', '', 'sandro-gossweiler', '', '', '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 0, 'http://localhost:88/gobrenix.com/?post_type=tribe_organizer&#038;p=15', 0, 'tribe_organizer', '', 0) ; 
INSERT INTO `gx_posts` VALUES (16, 1, '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 'Gobrenix Studios', '', 'publish', 'open', 'open', '', 'gobrenix-studios', '', '', '2015-06-12 01:01:11', '2015-06-11 23:01:11', '', 0, 'http://localhost:88/gobrenix.com/?post_type=tribe_venue&#038;p=16', 0, 'tribe_venue', '', 0) ; 
INSERT INTO `gx_posts` VALUES (18, 1, '2015-06-12 01:40:16', '2015-06-11 23:40:16', 'Irgendwelchi links links links kömmed do ane - links', 'Links', '', 'publish', 'open', 'open', '', 'links', '', '', '2015-06-12 01:40:16', '2015-06-11 23:40:16', '', 0, 'http://localhost:88/gobrenix.com/?page_id=18', 0, 'page', '', 0) ; 
INSERT INTO `gx_posts` VALUES (19, 1, '2015-06-12 01:40:16', '2015-06-11 23:40:16', 'Irgendwelchi links links links kömmed do ane - links', 'Links', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2015-06-12 01:40:16', '2015-06-11 23:40:16', '', 18, 'http://localhost:88/gobrenix.com/2015/06/12/18-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (21, 1, '2015-06-12 01:44:20', '2015-06-11 23:44:20', 'Simon Schneider alias Si-Moon was born on the 15.07.1992 in Swiss. At his first psytrance party in 2008 as he recognized that the powerfull bass wich controled his heartbeat and give him the full boody goose pumps he get addicted to the bass
Since this moment he know what was to do: He need to become a DJ, becouse as a DJ you can control hundert of peoples with your heartbeat and drag them into your powerfull spell of you own crazy fantasies. The People can come with you through your own wonderful fantasy world, where time and matter is no issue, where just you and the music is, to the maximum escalation of your body and mind. One year ago si -moon played his first live act . After this he became quite popular in Swiss and he was booked out every weekend several times. And the curve does not weaken, it rises steeply. Now he plays every weekend in the biggest clubs of switzerland.
The Labehead from PSR, Necmi, heard his liveset and took him directly to the PSR familiy. This was the best was Si-Moon could passing. Becouse this is the label with the same kind uf music.
PSR Music will make a new music era, an music revolution! Now is Simon working very hard on his first ep: "Lets get Dirty" This EP will be out soon. The soundstyle from Si-Moon is indescribably. Its a new kind of Music. Its somethink like aggressive progreesiv fullon with one piece of dubstep elements. He call it by himself "dirty.prog!" He surprised the visitors all the time with new and powerful basslines, and blast them away with the power of his music. When Si-Moon plays at a party, no one will stand around, all are dancing in the spell of his music.', 'Si-Moon', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2015-06-12 01:44:20', '2015-06-11 23:44:20', '', 9, 'http://localhost:88/gobrenix.com/2015/06/12/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (22, 1, '2015-06-12 01:48:12', '2015-06-11 23:48:12', 'Simon Schneider alias Si-Moon was born on the 15.07.1992 in Swiss. At his first psytrance party in 2008 as he recognized that the powerfull bass wich controled his heartbeat and give him the full boody goose pumps he get addicted to the bass
Since this moment he know what was to do: He need to become a DJ, becouse as a DJ you can control hundert of peoples with your heartbeat and drag them into your powerfull spell of you own crazy fantasies. The People can come with you through your own wonderful fantasy world, where time and matter is no issue, where just you and the music is, to the maximum escalation of your body and mind.

One year ago Si-Moon played his first live act . After this he became quite popular in Swiss and he was booked out every weekend several times. And the curve does not weaken, it rises steeply. Now he plays every weekend in the biggest clubs of switzerland.
The Labehead from PSR, Necmi, heard his liveset and took him directly to the PSR familiy. This was the best was Si-Moon could passing. Becouse this is the label with the same kind uf music.
PSR Music will make a new music era, an music revolution! Now is Simon working very hard on his first ep: "Lets get Dirty" This EP will be out soon. The soundstyle from Si-Moon is indescribably. Its a new kind of Music. Its somethink like aggressive progreesiv fullon with one piece of dubstep elements. He call it by himself "dirty.prog!" He surprised the visitors all the time with new and powerful basslines, and blast them away with the power of his music. When Si-Moon plays at a party, no one will stand around, all are dancing in the spell of his music.', 'Si-Moon', '', 'inherit', 'open', 'open', '', '9-autosave-v1', '', '', '2015-06-12 01:48:12', '2015-06-11 23:48:12', '', 9, 'http://localhost:88/gobrenix.com/2015/06/12/9-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (23, 1, '2015-06-12 01:49:03', '2015-06-11 23:49:03', 'Si-Moon live in Innsbruck', 'Si-Moon live in Innsbruck', 'Si-Moon live in Innsbruck', 'inherit', 'open', 'open', '', 'simoon', '', '', '2015-06-12 01:49:38', '2015-06-11 23:49:38', '', 9, 'http://localhost:88/gobrenix.com/wp-content/uploads/2015/06/simoon.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `gx_posts` VALUES (24, 1, '2015-06-12 01:49:43', '2015-06-11 23:49:43', 'Simon Schneider alias Si-Moon was born on the 15.07.1992 in Swiss. At his first psytrance party in 2008 as he recognized that the powerfull bass wich controled his heartbeat and give him the full boody goose pumps he get addicted to the bass
Since this moment he know what was to do: He need to become a DJ, becouse as a DJ you can control hundert of peoples with your heartbeat and drag them into your powerfull spell of you own crazy fantasies. The People can come with you through your own wonderful fantasy world, where time and matter is no issue, where just you and the music is, to the maximum escalation of your body and mind.

One year ago Si-Moon played his first live act . After this he became quite popular in Swiss and he was booked out every weekend several times. And the curve does not weaken, it rises steeply. Now he plays every weekend in the biggest clubs of switzerland.
The Labehead from PSR, Necmi, heard his liveset and took him directly to the PSR familiy. This was the best was Si-Moon could passing. Becouse this is the label with the same kind uf music.
PSR Music will make a new music era, an music revolution! Now is Simon working very hard on his first ep: "Lets get Dirty" This EP will be out soon. The soundstyle from Si-Moon is indescribably. Its a new kind of Music. Its somethink like aggressive progreesiv fullon with one piece of dubstep elements. He call it by himself "dirty.prog!" He surprised the visitors all the time with new and powerful basslines, and blast them away with the power of his music. When Si-Moon plays at a party, no one will stand around, all are dancing in the spell of his music.', 'Si-Moon', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2015-06-12 01:49:43', '2015-06-11 23:49:43', '', 9, 'http://localhost:88/gobrenix.com/2015/06/12/9-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `gx_posts` VALUES (26, 1, '2015-09-10 19:45:35', '2015-09-10 17:45:35', 'With an example description', 'Example Event', '', 'publish', 'open', 'closed', '', 'example-event', '', '', '2015-09-10 19:45:35', '2015-09-10 17:45:35', '', 0, 'http://localhost:88/gobrenix.com/?post_type=tribe_events&#038;p=26', 0, 'tribe_events', '', 0) ;
#
# End of data contents of table gx_posts
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `gx_term_relationships`
#

DROP TABLE IF EXISTS `gx_term_relationships`;


#
# Table structure of table `gx_term_relationships`
#

CREATE TABLE `gx_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_term_relationships (11 records)
#
 
INSERT INTO `gx_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 3, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 4, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 5, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 6, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 7, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (14, 8, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (26, 3, 0) ; 
INSERT INTO `gx_term_relationships` VALUES (26, 4, 0) ;
#
# End of data contents of table gx_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `gx_term_taxonomy`
#

DROP TABLE IF EXISTS `gx_term_taxonomy`;


#
# Table structure of table `gx_term_taxonomy`
#

CREATE TABLE `gx_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_term_taxonomy (8 records)
#
 
INSERT INTO `gx_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ; 
INSERT INTO `gx_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 2) ; 
INSERT INTO `gx_term_taxonomy` VALUES (3, 3, 'tribe_events_cat', '', 0, 2) ; 
INSERT INTO `gx_term_taxonomy` VALUES (4, 4, 'tribe_events_cat', '', 3, 2) ; 
INSERT INTO `gx_term_taxonomy` VALUES (5, 5, 'tribe_events_cat', '', 3, 1) ; 
INSERT INTO `gx_term_taxonomy` VALUES (6, 6, 'tribe_events_cat', '', 3, 1) ; 
INSERT INTO `gx_term_taxonomy` VALUES (7, 7, 'tribe_events_cat', '', 0, 1) ; 
INSERT INTO `gx_term_taxonomy` VALUES (8, 8, 'tribe_events_cat', '', 7, 1) ;
#
# End of data contents of table gx_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_terms`
# --------------------------------------------------------


#
# Delete any existing table `gx_terms`
#

DROP TABLE IF EXISTS `gx_terms`;


#
# Table structure of table `gx_terms`
#

CREATE TABLE `gx_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_terms (8 records)
#
 
INSERT INTO `gx_terms` VALUES (1, 'Allgemein', 'allgemein', 0) ; 
INSERT INTO `gx_terms` VALUES (2, 'Main Menu', 'main-menu', 0) ; 
INSERT INTO `gx_terms` VALUES (3, 'events', 'events', 0) ; 
INSERT INTO `gx_terms` VALUES (4, 'goa', 'goa', 0) ; 
INSERT INTO `gx_terms` VALUES (5, 'concert', 'concert', 0) ; 
INSERT INTO `gx_terms` VALUES (6, 'crew', 'crew', 0) ; 
INSERT INTO `gx_terms` VALUES (7, 'other', 'other', 0) ; 
INSERT INTO `gx_terms` VALUES (8, 'meeting', 'meeting', 0) ;
#
# End of data contents of table gx_terms
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `gx_usermeta`
#

DROP TABLE IF EXISTS `gx_usermeta`;


#
# Table structure of table `gx_usermeta`
#

CREATE TABLE `gx_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_usermeta (28 records)
#
 
INSERT INTO `gx_usermeta` VALUES (1, 1, 'nickname', 'admin') ; 
INSERT INTO `gx_usermeta` VALUES (2, 1, 'first_name', '') ; 
INSERT INTO `gx_usermeta` VALUES (3, 1, 'last_name', '') ; 
INSERT INTO `gx_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `gx_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `gx_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `gx_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `gx_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `gx_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `gx_usermeta` VALUES (10, 1, 'gx_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `gx_usermeta` VALUES (11, 1, 'gx_user_level', '10') ; 
INSERT INTO `gx_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw,logincustsecurity') ; 
INSERT INTO `gx_usermeta` VALUES (13, 1, 'show_welcome_panel', '0') ; 
INSERT INTO `gx_usermeta` VALUES (15, 1, 'gx_dashboard_quick_press_last_post_id', '27') ; 
INSERT INTO `gx_usermeta` VALUES (17, 1, 'wpseo_ignore_tour', '1') ; 
INSERT INTO `gx_usermeta` VALUES (18, 1, 'wpseo_seen_about_version', '2.3.5') ; 
INSERT INTO `gx_usermeta` VALUES (19, 1, 'gx_user-settings', 'libraryContent=browse&mfold=o&post_dfw=off') ; 
INSERT INTO `gx_usermeta` VALUES (20, 1, 'gx_user-settings-time', '1434060065') ; 
INSERT INTO `gx_usermeta` VALUES (21, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `gx_usermeta` VALUES (22, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `gx_usermeta` VALUES (24, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `gx_usermeta` VALUES (25, 1, 'tribe_setDefaultNavMenuBoxes', '1') ; 
INSERT INTO `gx_usermeta` VALUES (26, 1, 'session_tokens', 'a:1:{s:64:"285aee6c244c8cf6120d98831b8249c7c6c16e57087662e5b9573abccab7e2fc";a:4:{s:10:"expiration";i:1445347796;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36";s:5:"login";i:1445174996;}}') ; 
INSERT INTO `gx_usermeta` VALUES (27, 1, 'closedpostboxes_dashboard', 'a:0:{}') ; 
INSERT INTO `gx_usermeta` VALUES (28, 1, 'metaboxhidden_dashboard', 'a:2:{i:0;s:22:"tribe_dashboard_widget";i:1;s:21:"dashboard_custom_feed";}') ; 
INSERT INTO `gx_usermeta` VALUES (29, 1, 'wpseo_dismissed_gsc_notice', '1') ; 
INSERT INTO `gx_usermeta` VALUES (30, 1, '_yoast_wpseo_profile_updated', '1445184377') ; 
INSERT INTO `gx_usermeta` VALUES (31, 1, 'so_panels_directory_enabled', '1') ;
#
# End of data contents of table gx_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:88/gobrenix.com MySQL database backup
#
# Generated: Sunday 15. November 2015 18:07 UTC
# Hostname: localhost
# Database: `gx_gobrenix_com`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_lockdowns`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_login_fails`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `gx_users`
# --------------------------------------------------------


#
# Delete any existing table `gx_users`
#

DROP TABLE IF EXISTS `gx_users`;


#
# Table structure of table `gx_users`
#

CREATE TABLE `gx_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table gx_users (1 records)
#
 
INSERT INTO `gx_users` VALUES (1, 'admin', '$P$B8qzwkL9tjirmZ6nspS.cVNRXLyF3P1', 'admin', 'gobrenix@gmail.com', '', '2015-06-11 17:30:32', '', 0, 'admin') ;
#
# End of data contents of table gx_users
# --------------------------------------------------------

